/* IE11 ES5. All requests are same-origin XMLHttpRequest. */
(function () {
  'use strict';
  var cfg = window.APF_CONFIG, sessionId = null, busy = false;
  var md = window.markdownit ? window.markdownit({html:false,linkify:false,breaks:true}) : null;
  if (md) { md.disable('image'); }
  function el(id) { return document.getElementById(id); }
  function empty(node) { while (node.firstChild) { node.removeChild(node.firstChild); } }
  function show(node, visible) { node.style.display = visible ? '' : 'none'; }
  function status(message, state) {
    el('status').querySelector('.status-text').textContent = message;
    el('status').querySelector('.status-dot').className = 'status-dot ' + (state || '');
  }
  function controls(value) {
    busy=value;
    var ids=['reset','reset-mobile','upload','files','attach','attach-path','path-submit','path-input'];
    for(var i=0;i<ids.length;i++){el(ids[i]).disabled=value;}
    el('send').disabled=value;
  }
  function render(node,text){
    if(md){node.innerHTML=md.render(text);}else{node.textContent=text;}
  }
  function bottom(){el('scroll').scrollTop=el('scroll').scrollHeight;}
  function follows(){var s=el('scroll');return s.scrollHeight-s.scrollTop-s.clientHeight<150;}
  function bubble(role,text){
    show(el('welcome'),false);
    var article=document.createElement('article'),body=document.createElement('div'),label;
    article.className=role;body.className='answer';
    if(role==='assistant'){label=document.createElement('div');label.className='label';label.textContent='APF Assistant';article.appendChild(label);render(body,text||'');}
    else{body.textContent=text;}
    article.appendChild(body);el('messages').appendChild(article);bottom();return {article:article,body:body};
  }
  function url(template){return template.replace('{session}',encodeURIComponent(sessionId));}
  function request(method,path,data,callback){
    var xhr=new XMLHttpRequest();xhr.open(method,path,true);xhr.timeout=600000;
    if(method==='GET'){xhr.setRequestHeader('Cache-Control','no-cache');}
    xhr.onload=function(){
      var result;
      try{result=JSON.parse(xhr.responseText);}catch(e){callback(new Error('服务器未返回 JSON，请检查 API 路径。'));return;}
      if(xhr.status<200 || xhr.status>=300){
        var detail=result.detail;
        callback(new Error(typeof detail==='string'?detail:(detail && detail.message)||('HTTP '+xhr.status)));return;
      }
      callback(null,result);
    };
    xhr.onerror=function(){callback(new Error('网络连接失败，请检查服务。'));};
    xhr.ontimeout=function(){callback(new Error('请求超时，请检查模型或代理服务。'));};
    xhr.send(data||null);
  }
  function done(view,data,text){
    text=typeof data.answer==='string'?data.answer:text;
    render(view.body,text);var copy=document.createElement('button');copy.className='copy';copy.textContent='复制回答';
    copy.onclick=function(){
      try{if(window.clipboardData && window.clipboardData.setData('Text',text)){copy.textContent='已复制';return;}}catch(e){}
      copy.textContent='请选中文本复制';
    };
    view.article.appendChild(copy);
    if(data.patch_plan){var title=document.createElement('div'),pre=document.createElement('pre');title.className='patch-title';title.textContent='修改建议（尚未应用）';pre.textContent=JSON.stringify(data.patch_plan,null,2);view.article.appendChild(title);view.article.appendChild(pre);}
    status('回答完成，可以继续提问','ready');controls(false);refreshReports();
  }
  el('attach').onclick=function(){el('files').click();};
  el('files').onchange=function(){
    var files=el('files').files,names=[];
    for(var i=0;i<files.length;i++){names.push(files[i].name);}
    el('selection').textContent=names.join('、');el('upload').removeAttribute('hidden');show(el('upload'),files.length>0);
  };
  el('upload').onclick=function(){
    var files=el('files').files,form=new FormData(),names=[],i;
    if(busy||!files.length){return;}
    for(i=0;i<files.length;i++){
      if(!/\.report$/i.test(files[i].name)){status('请选择 .report 文件','error');return;}
      form.append('reports',files[i]);names.push(files[i].name);
    }
    if(sessionId){form.append('session_id',sessionId);}
    controls(true);status('正在上传并解析文件…','loading');
    request('POST',cfg.uploadUrl,form,function(error,data){
      if(error){status(error.message,'error');controls(false);return;}
      var isNew=!sessionId;sessionId=data.session_id;
      if(isNew){empty(el('messages'));show(el('welcome'),true);}
      empty(el('file-list'));
      names=[];
      for(var k=0;k<data.reports.length;k++){names.push(data.reports[k].file_name+' ['+data.reports[k].report_id+']');}
      for(var j=0;j<names.length;j++){var f=document.createElement('div');f.className='file';f.textContent=names[j];el('file-list').appendChild(f);}
      el('file-count').textContent=String(names.length);el('selection').textContent=names.length+' 份 report';
      show(el('upload'),false);el('files').value='';status('文件已就绪，可以开始提问','ready');controls(false);
    });
  };
  function send(){
    var question=el('question').value.replace(/^\s+|\s+$/g,'');
    if(busy||!question){return;}
    if(!sessionId){
      controls(true);status('正在初始化文档问答…','loading');
      request('POST','/api/apf/session',new FormData(),function(error,data){
        controls(false);
        if(error){status(error.message,'error');return;}
        sessionId=data.session_id;send();
      });
      return;
    }
    controls(true);bubble('user',question);el('question').value='';var view=bubble('assistant',''),text='',terminal=false;
    function fail(error){
      if(terminal){return;}terminal=true;render(view.body,text);
      var warning=document.createElement('p');warning.className='error';warning.textContent='回答未完成：'+error.message;view.article.appendChild(warning);
      status(error.message,'error');controls(false);el('question').value=question;
    }
    var form=new FormData();form.append('question',question);status('正在分析并检索文档…','loading');
    if(cfg.transport==='json'){
      request('POST',url(cfg.chatUrl),form,function(error,data){if(error){fail(error);return;}terminal=true;done(view,data,'');bottom();});return;
    }
    request('POST',url(cfg.streamStartUrl),form,function(error,data){
      if(error){fail(error);return;}
      var cursor=0,pollUrl='/api/apf/'+encodeURIComponent(sessionId)+'/chat/stream/'+encodeURIComponent(data.job_id);
      function poll(){
        request('GET',pollUrl+'?after='+cursor+'&_='+new Date().getTime(),null,function(err,packet){
          if(err){fail(err);return;}
          var follow=follows(),events=packet.events||[],i,entry;
          for(i=0;i<events.length;i++){
            entry=events[i];
            if(entry.event==='status'){status(entry.data.message,'loading');}
            if(entry.event==='delta'){text+=entry.data.text;}
            if(entry.event==='error'){fail(new Error(entry.data.message));return;}
            if(entry.event==='done'){terminal=true;done(view,entry.data,text);}
          }
          if(!terminal){render(view.body,text);}
          if(follow){bottom();}
          cursor=packet.next;
          if(terminal){return;}
          if(packet.finished){fail(new Error('回答结束但缺少完成事件'));return;}
          window.setTimeout(poll,cfg.pollInterval||500);
        });
      }
      poll();
    });
  }
  el('composer').onsubmit=function(event){event.preventDefault();send();};
  var composing=false;
  el('question').addEventListener('compositionstart',function(){composing=true;});
  el('question').addEventListener('compositionend',function(){composing=false;});
  el('question').onkeydown=function(event){if(event.keyCode===13&&!event.shiftKey&&!composing){event.preventDefault();send();}};
  el('reset').onclick=function(){sessionId=null;empty(el('messages'));empty(el('file-list'));show(el('welcome'),true);el('file-count').textContent='0';el('question').value='';el('files').value='';el('selection').textContent='';show(el('upload'),false);status('可直接进行文档问答，也可上传 report');controls(false);};
  el('reset-mobile').onclick=function(){el('reset').click();};
  var suggestions=document.querySelectorAll('[data-q]');
  for(var i=0;i<suggestions.length;i++){suggestions[i].onclick=function(){el('question').value=this.getAttribute('data-q');el('question').focus();};}
  function renderReports(reports){
    empty(el('file-list'));
    for(var j=0;j<reports.length;j++){
      var item=document.createElement('div');item.className='file';
      item.textContent=reports[j].file_name+' ['+reports[j].report_id+']';el('file-list').appendChild(item);
    }
    el('file-count').textContent=String(reports.length);
  }
  function refreshReports(){
    var sid=sessionId;if(!sid){return;}
    request('GET','/api/apf/session/'+encodeURIComponent(sid)+'/reports?_='+new Date().getTime(),null,function(error,data){
      if(!error && sid===sessionId){renderReports(data.reports);}
    });
  }
  var pathButton=document.createElement('button');pathButton.id='attach-path';pathButton.type='button';pathButton.className='upload-button';pathButton.textContent='加载路径';
  el('attach').parentNode.appendChild(pathButton);

  // Path hints mirror report_workspace.py. Update these if server configuration changes.
  var reportRoot='/APF/apfhome/models/WorkStreamClassic/Reports';
  var example='c/DEBUG/c/DEBUG/d/DispatchScreen/QVR_TFXPlus_Output_F68_9_100_Yilin.report';
  var panel=document.createElement('div');
  panel.style.cssText='display:none;clear:both;margin:12px 0;padding:14px;border:1px solid #ddd;border-radius:10px;background:#fafafa;color:#333;text-align:left;line-height:1.6;';
  el('composer').parentNode.insertBefore(panel,el('composer').nextSibling);
  var label=document.createElement('label');label.htmlFor='path-input';label.textContent='从 Windows server 加载 report';
  panel.appendChild(label);
  var pathInput=document.createElement('input');pathInput.id='path-input';pathInput.type='text';
  pathInput.style.cssText='display:block;box-sizing:border-box;width:100%;margin:8px 0;padding:10px;border:1px solid #ccc;border-radius:6px;background:white;color:#222;';
  pathInput.placeholder='填写 c/.../文件.report 或 D:/.../文件.report';
  panel.appendChild(pathInput);
  function button(text,handler){
    var b=document.createElement('button');b.type='button';b.textContent=text;
    b.style.cssText='margin:4px 8px 4px 0;padding:6px 12px;border:1px solid #ccc;border-radius:5px;background:white;color:#333;cursor:pointer;';
    b.onclick=handler;return b;
  }
  var submitPath=button('确认加载',loadPath);submitPath.id='path-submit';panel.appendChild(submitPath);
  panel.appendChild(button('收起',function(){panel.style.display='none';pathButton.setAttribute('aria-expanded','false');pathButton.focus();}));
  var hint=document.createElement('p');
  hint.textContent='填写 f68pap423n26 服务器 D$ 共享内的路径，不是本机路径。以下示例可复制后修改文件名；绝对路径也必须位于 Reports 根目录内。';
  panel.appendChild(hint);
  function exampleRow(title,value){
    var row=document.createElement('div'),caption=document.createElement('div'),box=document.createElement('input');
    caption.textContent=title;row.appendChild(caption);
    box.type='text';box.readOnly=true;box.value=value;box.setAttribute('aria-label',title);
    box.style.cssText='box-sizing:border-box;width:100%;padding:7px;border:1px solid #ddd;background:white;color:#444;font-family:Consolas,monospace;';
    box.onclick=function(){box.select();};row.appendChild(box);
    row.appendChild(button('复制示例',function(){
      var copied=false;box.focus();box.select();
      try{if(window.clipboardData){copied=window.clipboardData.setData('Text',value);}}catch(e){}
      if(!copied){try{copied=document.execCommand('copy');}catch(e){}}
      copyStatus.textContent=copied?'已复制，可粘贴后修改路径。':'已选中，请按 Ctrl+C 复制。';
    }));
    row.appendChild(button('填入输入框',function(){if(!busy){pathInput.value=value;pathInput.focus();}}));
    panel.appendChild(row);
  }
  exampleRow('相对路径：从 Reports 根目录开始',example);
  exampleRow('Windows 绝对路径','D:'+reportRoot+'/'+example);
  exampleRow('UNC 路径',String.fromCharCode(92,92)+'f68pap423n26'+String.fromCharCode(92)+'D$'+(reportRoot+'/'+example).split('/').join(String.fromCharCode(92)));
  var copyStatus=document.createElement('div');copyStatus.setAttribute('role','status');panel.appendChild(copyStatus);
  var note=document.createElement('p');
  note.textContent='根目录：D:'+reportRoot+'。此加载入口不指定父 report，因此普通相对路径也从根目录解析；Macro 自动加载时才会使用已知父文件目录。';
  panel.appendChild(note);
  pathButton.setAttribute('aria-expanded','false');
  pathButton.onclick=function(){
    if(busy){return;}
    var open=panel.style.display==='none';
    panel.style.display=open?'block':'none';pathButton.setAttribute('aria-expanded',open?'true':'false');
    if(open){pathInput.focus();panel.scrollIntoView(false);}
  };
  pathInput.onkeydown=function(event){if(event.keyCode===13){event.preventDefault();loadPath();}};
  function loadPath(){
    if(busy){return;}
    var path=pathInput.value.trim();
    if(!path){copyStatus.textContent='请先填写 report 路径。';pathInput.focus();return;}
    controls(true);status('正在加载 report…','loading');
    function attachNow(){
      var form=new FormData();form.append('report_path',path);
      request('POST','/api/apf/session/'+encodeURIComponent(sessionId)+'/attach',form,function(error,data){
        controls(false);
        if(error){status(error.message,'error');return;}
        renderReports(data.reports);status('已加载 report，可继续提问','ready');
      });
    }
    if(sessionId){attachNow();}
    else{request('POST','/api/apf/session',new FormData(),function(error,data){
      if(error){controls(false);status(error.message,'error');return;}
      sessionId=data.session_id;attachNow();
    });}
  };
  status('可直接进行文档问答，也可上传 report');controls(false);
  if(document.documentMode && document.documentMode<11){status('当前为旧文档模式，请按 F12 将 Document mode 设为 11。','error');}
}());
