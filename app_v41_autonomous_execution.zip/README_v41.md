# App V4.1 Autonomous Execution

基于 app_v3_history_optimized.zip。替换 app/，保留 .env、数据库配置、SQLite knowledge DB 和 SQL templates。不新增依赖，不新增 schema 校验；保留原 SQL Guard、只读事务及白名单。

## 配置（可选）
```dotenv
MAX_AGENT_STEPS=24
MAX_RETRIEVAL_STEPS=10
MAX_QUERY_STEPS=5
MAX_QUERY_RETRIES=3
MAX_FINAL_REJECTIONS=3
MAX_SQL_CHARS=100000
HISTORY_MAX_CHARS=60000
```
MAX_QUERY_STEPS 默认继承旧 MAX_STEPS。MAX_QUERY_RETRIES 实际为允许失败的执行次数（含首次失败），不是每条 SQL 的重试次数。MAX_AGENT_STEPS 为普通决策次数，另保留一次最终总结。Final rejection 达上限后，无证据时禁止终止动作，但模型仍可能违反指令；总决策预算保证退出。预算不能保证 DB 成功。默认任务需要查询，纯解释可用 `仅解释：`、`只解释：` 或 `explain only:` 前缀。

## 执行
等待旧 workflow 完成，停止旧 worker，替换 app/，启动 `python -m app.worker`。不要混用旧 worker 或重放旧版本未完成 workflow。CLI 不变：`python -m app.cli ask "Calculate dispatch indicators for the past 7 days"`。

模型根据完整 example 判断匹配；完全匹配使用 execute_template，按 datasource + template_id 从 SQLite 读取原 SQL，沿用 execute_sql；部分匹配修改 SQL，不匹配重新生成。原 12000 字符限制会挡住用户提供的 13410 字节模板，现改为可配置。模板仍须通过原 guard，Oracle 权限和超时限制不变。未自动改写业务口径。失败 SQL 和错误进入 history。

返回保留 answer/steps，新增 status、evidence_steps、remaining_budget。COMPLETED/PARTIAL/FAILED/NEEDS_INPUT 为未来集成接口；不实现 session 或审核流程。Gate 检查真实成功查询步骤引用及模型 complete 声明，不是业务语义验证器；空结果也是成功查询，模型必须如实解释。模板匹配及证据相关性由模型判断。审计 steps 保留完整工具记录；模板成功记录 ID，失败记录 SQL。无结果时不会伪造数据。

测试：python -m unittest discover -s tests -v。真实 Temporal/Oracle/LiteLLM 未联调；本地缺 temporalio，测试覆盖纯策略和 history，不覆盖实际 Activity。原 SQL guard 的其他限制未修改。
