import os
from dotenv import load_dotenv
load_dotenv()

def env(name, default=None):
    value = os.getenv(name, default)
    if value is None:
        raise RuntimeError(f'Missing environment variable: {name}')
    return value

TEMPORAL_ADDRESS = env('TEMPORAL_ADDRESS', 'f68-dev-101.mfg.hynix-dl.com:7233')
TEMPORAL_NAMESPACE = env('TEMPORAL_NAMESPACE', 'default')
TASK_QUEUE = env('TEMPORAL_TASK_QUEUE', 'fab-sql-agent')
MAX_STEPS = int(env('MAX_STEPS', '5'))
MAX_ROWS = int(env('MAX_ROWS', '50'))
SQL_TIMEOUT_MS = int(env('SQL_TIMEOUT_MS', '30000'))
ALLOWED_TABLES = {s.strip().upper() for s in env('ALLOWED_TABLES', '').split(',') if s.strip()}
ORACLE_SCHEMA = env('ORACLE_SCHEMA', '').upper()
KNOWLEDGE_DIR = env('KNOWLEDGE_DIR', 'knowledge')
# MAX_STEPS remains a legacy default for query attempts.
MAX_QUERY_STEPS = max(1, int(env('MAX_QUERY_STEPS', str(MAX_STEPS))))
MAX_RETRIEVAL_STEPS = max(1, int(env('MAX_RETRIEVAL_STEPS', '10')))
MAX_QUERY_RETRIES = max(1, int(env('MAX_QUERY_RETRIES', '3')))
MAX_FINAL_REJECTIONS = max(1, int(env('MAX_FINAL_REJECTIONS', '3')))
MAX_AGENT_STEPS = max(1, int(env('MAX_AGENT_STEPS', '24')))
