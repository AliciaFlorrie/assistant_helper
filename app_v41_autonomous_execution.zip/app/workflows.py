from datetime import timedelta
from temporalio import workflow
from temporalio.common import RetryPolicy
with workflow.unsafe.imports_passed_through():
    from .activities import load_schema, knowledge_action, model_step, run_query, run_template
    from .config import MAX_QUERY_STEPS, MAX_RETRIEVAL_STEPS, MAX_QUERY_RETRIES, MAX_FINAL_REJECTIONS, MAX_AGENT_STEPS
    from .execution_policy import Budget, RETRIEVAL, EXECUTION, evidence, gate, signature


def error_text(exc):
    messages=[]
    for _ in range(8):
        if exc is None: break
        messages.append(str(exc))
        exc=getattr(exc,'cause',None) or getattr(exc,'__cause__',None)
    return ' | '.join(messages)[:4000]

@workflow.defn
class SQLAgentWorkflow:
    @workflow.run
    async def run(self,question:str)->dict:
        history=[]
        budget=Budget(MAX_RETRIEVAL_STEPS,MAX_QUERY_STEPS,MAX_QUERY_RETRIES,MAX_FINAL_REJECTIONS,MAX_AGENT_STEPS)
        # Data execution is the default contract of this CLI. Explicit explanation-only requests are exempt.
        requires_query=not question.strip().lower().startswith(('explain only:', '仅解释：','只解释：'))
        attempted=set()
        def finish(status,answer):
            return {'answer':answer,'steps':history,'status':status,'evidence_steps':evidence(history),'remaining_budget':vars(budget).copy()}
        async def call(fn,payload):
            return await workflow.execute_activity(fn,payload,start_to_close_timeout=timedelta(seconds=300),retry_policy=RetryPolicy(maximum_attempts=1))
        try:
            directory=await workflow.execute_activity(load_schema,start_to_close_timeout=timedelta(seconds=300),retry_policy=RetryPolicy(maximum_attempts=1))
        except Exception as exc:
            return finish('FAILED',error_text(exc))
        # Reserve one synthesis decision even when normal decision budget is exhausted.
        for turn in range(MAX_AGENT_STEPS+1):
            must_finish=turn==MAX_AGENT_STEPS or (budget.queries<=0 or budget.retries<=0)
            allowed=['final','failed'] if must_finish else budget.allowed(history)
            if not must_finish: budget.decisions-=1
            if not must_finish and requires_query and budget.rejections<=0:
                allowed=[a for a in allowed if a not in ('final','failed','ask_user')] if not evidence(history) else allowed
            policy={'allowed_actions':allowed,'remaining_budget':vars(budget).copy(),'requires_query':requires_query,'successful_evidence_steps':evidence(history)}
            try:
                decision=await call(model_step,{'question':question,'catalog':directory,'history':history,'max_steps_reached':must_finish,'policy':policy})
            except Exception as exc:
                history.append({'action':'system_feedback','arguments':{},'error':error_text(exc)})
                if must_finish: break
                continue
            a=decision['action']
            if a in ('final','failed','ask_user'):
                rejection=gate(decision,history,requires_query)
                if a!='final' and not must_finish and requires_query and budget.queries>0 and budget.retries>0:
                    rejection='Do not stop or ask optional questions. Attempt a relevant query using template defaults. If essential inputs are missing, explain the specific blocker.'
                if a not in allowed: rejection='Action not allowed by remaining budget.'
                if not rejection:
                    status={'final':'COMPLETED','failed':'PARTIAL' if evidence(history) else 'FAILED','ask_user':'NEEDS_INPUT'}[a]
                    return finish(status,decision['answer'])
                history.append({'action':'system_feedback','arguments':{'rejected_action':a},'result':rejection})
                budget.rejections=max(0,budget.rejections-1)
                if must_finish: break
                continue
            if must_finish: break
            if a not in allowed:
                history.append({'action':'system_feedback','arguments':{'rejected_action':a},'result':'Budget exhausted for this action; use allowed actions.'})
                continue
            item={'action':a,'arguments':{k:v for k,v in decision.items() if k!='action'}}
            if a in EXECUTION:
                sig=signature(decision)
                if sig in attempted:
                    history.append({'action':'system_feedback','arguments':{'rejected_action':a},'result':'Identical execution already attempted. Use existing evidence or correct SQL.'})
                    continue
                attempted.add(sig); budget.queries-=1
            else: budget.retrieval-=1
            try:
                if a=='query':
                    item['result']=await call(run_query,{k:decision[k] for k in ('datasource','sql','params')})
                elif a=='execute_template':
                    response=await call(run_template,{k:decision[k] for k in ('datasource','template_id','params')})
                    # Preserve failed SQL for repair, avoid duplicating successful template text in context.
                    if 'error' in response:
                        item['arguments']['sql']=response['sql']; item['error']=response['error']
                    else: item['result']=response['result']
                else: item['result']=await call(knowledge_action,decision)
            except Exception as exc: item['error']=error_text(exc)
            if a in EXECUTION and (item.get('error') or (isinstance(item.get('result'),dict) and item['result'].get('error'))): budget.retries-=1
            history.append(item)
        return finish('PARTIAL' if evidence(history) else 'FAILED','Execution ended without a fully supported answer. Inspect steps for query evidence, errors and remaining budget.')
