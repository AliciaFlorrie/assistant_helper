# Optional XMLMD5 compatibility patch

替换原项目 apf_parser/parser.py，重启服务后重新加载之前失败的 report。
无需更改 API、SMB 下载、report_workspace.py 或 SQLite 模块。

## 本次文件的实际问题
get_DMOQD_Macro_VF_7_4.report 没有 XMLMD5 字段。
旧代码在读取 XML 前就抛出 Valid XMLMD5 field not found。
XMLBlocks.XML 本身可以解析，根节点仍是 blocks，包含 240 个 block、283 条连接；
其中 MacroParameter 和 MacroExport 各一个，因此包含可供父 report 调用的 Macro 输入输出结构。
缺少 XMLMD5 不能推断为所有 Macro 文件的固定特征，也无法仅据此确定保存版本或导出来源。

## 统一处理
有校验和：仍按原算法验证，保留原有不匹配诊断。
没有校验和：解析 XML、生成 IR/SQLite，增加 XML_MD5_MISSING warning。
校验和字段存在但格式错误：继续拒绝。
XML 语法错误：继续拒绝。

IR metadata：
- xml_md5_status：valid / mismatch / missing
- xml_md5_valid：true / false / null
- xml_md5_expected：缺失时 null
- xml_md5_actual：仍计算实际内容的 MD5

若自定义前端/业务代码用 if not xml_md5_valid 判断失败，需要区分 null（未验证）与 false（不匹配）。
这不是 XSD 校验，也不保证业务逻辑正确或 APF 引擎一定能执行。

## 修改导出边界
本补丁统一的是读取、分析和查询，不改原始 report，也不凭空补写 XMLMD5。
原 report_editor.py 的修改导出仍要求已有 XMLMD5 字段；对这种无校验和文件，
它会拒绝导出修改结果（Could not update XMLMD5），不会静默生成未经验证的格式。
无校验和文件的写回需要单独确认 APF Formatter 对该格式的保存约定。

## 已执行验证
- 上传的 Macro report：240 blocks / 283 connections，missing warning，SQLite 成功。
- 原 RPT_LOT_PREDICTION_TUNER report：402 blocks / 440 connections，MD5 valid，SQLite 成功。
- 标签不匹配：拒绝。
- 有 XMLMD5 字段但值无效：拒绝。
未连接内网 APF Formatter 进行打开或执行验证。
