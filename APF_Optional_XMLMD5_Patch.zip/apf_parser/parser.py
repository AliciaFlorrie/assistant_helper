from __future__ import annotations

import hashlib
import re
from collections import Counter, defaultdict, deque
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any
from xml.etree import ElementTree as ET

from .ir import APFIR, Block, Connection
from .xml_reader import parse_block, parse_position
from .validators import validate_graph, validate_block_semantics


class APFParseError(Exception):
    pass


def read_quoted_field(
    text: str,
    field_name: str,
    start: int = 0,
) -> str:
    """
    Read a field from the outer APF serialized text:

        FieldName: "..."

    Supports multi-line strings and escape sequences such as
    \", \\, \\n, \\r, and \\t.
    """
    pattern = re.compile(
        rf"(?m)^\s*{re.escape(field_name)}\s*:\s*\""
    )
    match = pattern.search(text, start)

    if not match:
        raise APFParseError(
            f"Field not found: {field_name}"
        )

    index = match.end()
    result: list[str] = []

    escape_mapping = {
        '"': '"',
        "\\": "\\",
        "n": "\n",
        "r": "\r",
        "t": "\t",
    }

    while index < len(text):
        char = text[index]

        if char == '"':
            return "".join(result)

        if char == "\\":
            index += 1

            if index >= len(text):
                raise APFParseError(
                    f"{field_name} string ends with a trailing backslash"
                )

            escaped = text[index]

            # Handle known escape sequences.
            # Preserve unknown escapes to avoid corrupting
            # Windows paths or APF-specific expressions.
            if escaped in escape_mapping:
                result.append(escape_mapping[escaped])
            else:
                result.append("\\")
                result.append(escaped)
        else:
            result.append(char)

        index += 1

    raise APFParseError(
        f"{field_name} string is not properly terminated"
    )


def read_optional_quoted_field(
    text: str,
    field_name: str,
) -> str | None:
    try:
        return read_quoted_field(text, field_name)
    except APFParseError:
        return None


def parse_report(path: str | Path) -> APFIR:
    path = Path(path)
    raw_bytes = path.read_bytes()

    try:
        report_text = raw_bytes.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise APFParseError(
            "The .report file is not valid UTF-8 text"
        ) from exc

    xml_md5_match = re.search(
        r'XMLMD5\s*:\s*"([0-9a-fA-F]{32})"',
        report_text,
    )

    # Some APF exports contain XMLBlocks without a checksum field.
    # An absent checksum is unverifiable, not invalid XML or a successful check.
    if not xml_md5_match and re.search(r"(?m)^\s*XMLMD5\s*:", report_text):
        raise APFParseError("Malformed XMLMD5 field; expected 32 hexadecimal characters")
    expected_md5 = xml_md5_match.group(1).lower() if xml_md5_match else None

    xml_blocks_start = report_text.find("XMLBlocks:")
    if xml_blocks_start < 0:
        raise APFParseError(
            "XMLBlocks section not found"
        )

    xml_text = read_quoted_field(
        report_text,
        "XML",
        start=xml_blocks_start,
    )

    actual_md5 = hashlib.md5(
        xml_text.encode("utf-8")
    ).hexdigest()

    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError as exc:
        raise APFParseError(
            f"Failed to parse XMLBlocks.XML: {exc}"
        ) from exc

    if root.tag != "blocks":
        raise APFParseError(
            f"Expected root element 'blocks', got '{root.tag}'"
        )

    blocks: dict[str, Block] = {}
    connections: list[Connection] = []

    objects = root.findall("./objects/object")

    for obj in objects:
        block = parse_block(obj)

        if block.name in blocks:
            raise APFParseError(
                f"Duplicate block name: {block.name}"
            )

        blocks[block.name] = block

        # Connections are stored in the downstream object.
        # The 'block' attribute refers to the upstream block.
        for conn in obj.findall("./connections/connection"):
            source = conn.get("block")

            if not source:
                raise APFParseError(
                    f"{block.name} contains a connection without a block attribute"
                )

            try:
                ordinal = int(conn.get("ordinal", "0"))
            except ValueError as exc:
                raise APFParseError(
                    f"Invalid ordinal value in block {block.name}"
                ) from exc

            connections.append(
                Connection(
                    source=source,
                    target=block.name,
                    ordinal=ordinal,
                )
            )

    ir = APFIR(
        metadata={
            "source_file": path.name,
            "source_sha256": hashlib.sha256(
                raw_bytes
            ).hexdigest(),
            "formatter_version":
                read_optional_quoted_field(
                    report_text,
                    "FormatterVersion",
                ),
            "formatter_arch":
                read_optional_quoted_field(
                    report_text,
                    "FormatterArch",
                ),
            "preferred_target":
                read_optional_quoted_field(
                    report_text,
                    "PreferredTarget",
                ),
            "xml_md5_expected": expected_md5,
            "xml_md5_actual": actual_md5,
            "xml_md5_valid": (expected_md5 == actual_md5) if expected_md5 is not None else None,
            "xml_md5_status": ("missing" if expected_md5 is None else
                               "valid" if expected_md5 == actual_md5 else "mismatch"),
        },
        blocks=blocks,
        connections=connections,
    )

    if expected_md5 is None:
        ir.diagnostics.append({
            "level": "warning",
            "code": "XML_MD5_MISSING",
            "message": "XMLMD5 is absent; XML was parsed but checksum verification is unavailable.",
        })
    elif not ir.metadata["xml_md5_valid"]:
        ir.diagnostics.append({
            "level": "error",
            "code": "XML_MD5_MISMATCH",
            "message": (
                f"XML MD5 mismatch: expected={expected_md5}, "
                f"actual={actual_md5}"
            ),
        })

    ir.diagnostics.extend(validate_block_semantics(ir))
    ir.diagnostics.extend(validate_graph(ir))

    return ir