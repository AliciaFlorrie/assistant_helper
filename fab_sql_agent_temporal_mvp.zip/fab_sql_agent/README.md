# Fab-Copilot Oracle SQL Agent (Temporal MVP)

This is a **read-only, bounded, multi-step SQL reasoning prototype**. It does not include the scheduled monitoring/notification service yet. It executes a user question as one Temporal Workflow, with repeated Qwen reasoning and Oracle SQL activities.

## Requirements
- Python 3.11+
- Reachable Temporal Server and namespace, with permission to run Workflows
- Reachable LiteLLM OpenAI-compatible endpoint serving Qwen
- Oracle **SELECT-only** account with grants limited to approved tables/views; ideally approved views with sensitive columns removed
- Network policies restricting database access to the worker

## Setup
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Edit .env: Temporal, LiteLLM, Oracle and allowed tables
python -m app.cli schema
```

## Start
Terminal 1:
```bash
python -m app.worker
```
Terminal 2:
```bash
python -m app.cli ask 'What is the current status of entity EQP_001?'
```
Use Temporal Web UI to inspect workflow steps and failures.

## Pipeline
1. `load_schema`: retrieve authorized Oracle table/column catalog.
2. `model_step`: ask Qwen for one parameterized SELECT or final answer.
3. `run_query`: parse SQL with sqlglot, check table allowlist and read-only AST, execute Oracle with bind parameters and row cap.
4. Repeat with prior query results/errors up to MAX_STEPS; return final answer and SQL evidence.

## Important limitations and security controls
- This is a development MVP, **not approved for unattended production MES access**. A SQL AST allowlist cannot fully prevent expensive queries, inference, sensitive function calls or Oracle-specific SQL tricks. Enforce Oracle read-only grants, approved views, resource manager, query timeouts and network isolation at the database level.
- The current AST guard allows SELECT expressions and may permit built-in functions; production should additionally allowlist SQL functions, prohibit database links and validate column references against the schema catalog. Use query-plan/cost controls and an approval gate for high-risk SQL.
- Do not give the model access to credentials. Do not put sensitive MES data into prompts or Temporal histories without reviewing retention, payload encryption and access controls. Query results are passed into Temporal Activity results and model prompts.
- `ALL_TAB_COLUMNS` may expose metadata beyond actual granted objects; the configured allowlist filters the returned catalog.
- LLM JSON mode must be supported by the configured model/endpoint; if unsupported, adapt `response_format` in `app/agent.py`.
- Tool execution is a **server-controlled activity**; the LLM proposes JSON actions and does not call Oracle directly.
- For production use, add a durable audit store, user authorization, schema descriptions and approved join paths, row-level restrictions, result redaction, idempotency, prompt-injection defenses, evaluation tests and observability.
- A separate Temporal Schedule can later invoke a monitoring workflow every 5 minutes, but scheduled monitoring is not included in this archive.
