import os
from dotenv import load_dotenv
load_dotenv()

def env(name, default=None):
    value = os.getenv(name, default)
    if value is None:
        raise RuntimeError(f'Missing environment variable: {name}')
    return value

TEMPORAL_ADDRESS = env('TEMPORAL_ADDRESS', 'localhost:7233')
TEMPORAL_NAMESPACE = env('TEMPORAL_NAMESPACE', 'default')
TASK_QUEUE = env('TEMPORAL_TASK_QUEUE', 'fab-sql-agent')
MAX_STEPS = int(env('MAX_STEPS', '5'))
MAX_ROWS = int(env('MAX_ROWS', '50'))
SQL_TIMEOUT_MS = int(env('SQL_TIMEOUT_MS', '30000'))
ALLOWED_TABLES = {s.strip().upper() for s in env('ALLOWED_TABLES', '').split(',') if s.strip()}
ORACLE_SCHEMA = env('ORACLE_SCHEMA', '').upper()
