from datetime import timedelta
from temporalio import workflow
from temporalio.common import RetryPolicy

with workflow.unsafe.imports_passed_through():
    from .activities import load_schema, model_step, run_query
    from .config import MAX_STEPS

@workflow.defn
class SQLAgentWorkflow:
    @workflow.run
    async def run(self, question: str) -> dict:
        catalog = await workflow.execute_activity(
            load_schema, start_to_close_timeout=timedelta(seconds=45),
            retry_policy=RetryPolicy(maximum_attempts=2))
        history = []
        for step in range(MAX_STEPS + 1):
            decision = await workflow.execute_activity(
                model_step, {'question':question, 'catalog':catalog,
                             'history':history, 'max_steps_reached':step == MAX_STEPS},
                start_to_close_timeout=timedelta(seconds=120),
                retry_policy=RetryPolicy(maximum_attempts=2))
            if decision['action'] == 'final':
                return {'answer':decision['answer'], 'steps':history}
            query = {'sql':decision['sql'], 'params':decision['params'],
                     'reason':decision['reason']}
            try:
                result = await workflow.execute_activity(
                    run_query, {'sql':query['sql'],'params':query['params']},
                    start_to_close_timeout=timedelta(seconds=50),
                    retry_policy=RetryPolicy(maximum_attempts=1))
                query['result'] = result
            except Exception as exc:
                query['error'] = str(exc)[:600]
            history.append(query)
        return {'answer':'Maximum query steps reached without a final answer.', 'steps':history}
