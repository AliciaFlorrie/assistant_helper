import argparse
import asyncio
import json
import uuid
from temporalio.client import Client
from . import config
from .workflows import SQLAgentWorkflow
from .oracle_tools import schema_catalog

async def ask(question):
    client = await Client.connect(config.TEMPORAL_ADDRESS, namespace=config.TEMPORAL_NAMESPACE)
    result = await client.execute_workflow(
        SQLAgentWorkflow.run, question, id='sql-agent-' + str(uuid.uuid4()),
        task_queue=config.TASK_QUEUE)
    print(json.dumps(result, ensure_ascii=False, indent=2, default=str))

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=['ask', 'schema'])
    parser.add_argument('question', nargs='?')
    args = parser.parse_args()
    if args.command == 'schema':
        print(json.dumps(schema_catalog(), ensure_ascii=False, indent=2))
    elif not args.question:
        parser.error('ask requires a question')
    else:
        asyncio.run(ask(args.question))
