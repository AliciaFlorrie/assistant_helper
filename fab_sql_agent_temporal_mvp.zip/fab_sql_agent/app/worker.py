import asyncio
from temporalio.client import Client
from temporalio.worker import Worker
from . import config
from .workflows import SQLAgentWorkflow
from .activities import load_schema, model_step, run_query

async def main():
    client = await Client.connect(config.TEMPORAL_ADDRESS, namespace=config.TEMPORAL_NAMESPACE)
    worker = Worker(client, task_queue=config.TASK_QUEUE,
                    workflows=[SQLAgentWorkflow],
                    activities=[load_schema, model_step, run_query])
    print(f'Worker listening on {config.TASK_QUEUE}')
    await worker.run()

if __name__ == '__main__':
    asyncio.run(main())
