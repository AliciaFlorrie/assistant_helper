"""Oracle read-only schema catalog and query executor.
Use a database account with SELECT grants only on approved objects.
"""
import re
import time
from contextlib import contextmanager
import oracledb
from sqlglot import parse, exp
from . import config

IDENTIFIER = re.compile(r'^[A-Z][A-Z0-9_$#]*$')

def connection():
    return oracledb.connect(
        user=config.env('ORACLE_USER'),
        password=config.env('ORACLE_PASSWORD'),
        dsn=config.env('ORACLE_DSN'),
    )

@contextmanager
def readonly_connection():
    conn = connection()
    try:
        conn.call_timeout = config.SQL_TIMEOUT_MS
        with conn.cursor() as cursor:
            cursor.execute('SET TRANSACTION READ ONLY')
        yield conn
    finally:
        conn.close()

def schema_catalog():
    if not config.ALLOWED_TABLES:
        raise RuntimeError('ALLOWED_TABLES must explicitly list permitted tables')
    if not IDENTIFIER.fullmatch(config.ORACLE_SCHEMA):
        raise RuntimeError('ORACLE_SCHEMA must be an explicit valid Oracle schema')
    with readonly_connection() as conn:
        with conn.cursor() as cur:
            cur.execute('''SELECT table_name, column_name, data_type, nullable
                           FROM all_tab_columns
                           WHERE owner = :owner
                           ORDER BY table_name, column_id''',
                        {'owner': config.ORACLE_SCHEMA})
            result = {}
            for table, col, dtype, nullable in cur:
                if table.upper() in config.ALLOWED_TABLES:
                    result.setdefault(table.upper(), []).append({
                        'name': col, 'type': dtype, 'nullable': nullable == 'Y'})
            return result

def validate_sql(sql: str, params: dict):
    if not isinstance(sql, str) or len(sql) > 12000:
        raise ValueError('SQL must be a string under 12000 characters')
    if not isinstance(params, dict):
        raise ValueError('bind parameters must be an object')
    statements = parse(sql, read='oracle')
    if len(statements) != 1 or statements[0] is None:
        raise ValueError('Exactly one SQL statement is allowed')
    ast = statements[0]
    if not isinstance(ast, (exp.Select, exp.Union, exp.Intersect, exp.Except)):
        raise ValueError('Only SELECT queries are permitted')
    if any(isinstance(n, (exp.Insert, exp.Update, exp.Delete, exp.Create,
                          exp.Drop, exp.Alter, exp.Command, exp.Merge,
                          exp.Transaction, exp.Into)) for n in ast.walk()):
        raise ValueError('Mutating SQL is prohibited')
    if any(isinstance(n, exp.Star) for n in ast.find_all(exp.Star)):
        raise ValueError('SELECT * is prohibited; list columns explicitly')
    ctes = {cte.alias.upper() for cte in ast.find_all(exp.CTE) if cte.alias}
    used = set()
    for table in ast.find_all(exp.Table):
        name = table.name.upper()
        if name in ctes:
            continue
        owner = table.db.upper() if table.db else config.ORACLE_SCHEMA
        if owner != config.ORACLE_SCHEMA or name not in config.ALLOWED_TABLES:
            raise ValueError(f'Unauthorized table: {owner}.{name}')
        used.add(name)
    if not used:
        raise ValueError('Query must reference an authorized table')
    # Only named :bind placeholders; block numeric positional bind names.
    for name in params:
        if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*', name):
            raise ValueError(f'Invalid bind name: {name}')
        if not isinstance(params[name], (str, int, float, bool, type(None))):
            raise ValueError('Only scalar bind values are supported')
    placeholders = {n.name for n in ast.find_all(exp.Placeholder) if n.name}
    if placeholders != set(params):
        raise ValueError(f'Bind mismatch: expected {sorted(placeholders)}, got {sorted(params)}')
    # AST checks are defense-in-depth, not a substitute for DB grants.
    return sql

def execute_sql(sql: str, params: dict):
    validate_sql(sql, params)
    started = time.monotonic()
    with readonly_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(sql, params)
            names = [d[0].lower() for d in cur.description]
            rows = cur.fetchmany(config.MAX_ROWS + 1)
            truncated = len(rows) > config.MAX_ROWS
            rows = rows[:config.MAX_ROWS]
            def clean(v):
                if v is None or isinstance(v, (str, int, float, bool)):
                    return v
                return str(v)[:300]
            return {'columns': names,
                    'rows': [dict(zip(names, [clean(v) for v in row])) for row in rows],
                    'truncated': truncated,
                    'elapsed_ms': round((time.monotonic() - started) * 1000)}
