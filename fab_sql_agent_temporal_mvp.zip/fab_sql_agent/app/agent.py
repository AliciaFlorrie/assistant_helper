import json
from openai import OpenAI
from . import config

SYSTEM = '''You are a read-only Oracle database assistant for semiconductor manufacturing.
Use ONLY the provided schema. Never invent table names, columns, joins or facts.
Use named Oracle bind variables (e.g. :entity_id) for user values.
Do not use SELECT *; list columns. Prefer narrow, selective queries.
Only propose one SELECT query per step. Do not call PL/SQL or database functions.
Use previous results to decide the next step. If sufficient, finish with evidence.
If schema is insufficient, say so instead of guessing.
Return ONLY a JSON object with one of these shapes:
{"action":"query","reason":"...","sql":"SELECT ...","params":{"entity_id":"..."}}
{"action":"final","answer":"..."}
Do not include markdown fences.
'''

def decide(question, catalog, history, max_steps_reached=False):
    client = OpenAI(base_url=config.env('LITELLM_BASE_URL'),
                    api_key=config.env('LITELLM_API_KEY'))
    context = {'question': question, 'schema': catalog, 'history': history,
               'queries_remaining': 0 if max_steps_reached else config.MAX_STEPS-len(history)}
    msg = SYSTEM + ('\nYou MUST return action=final now.' if max_steps_reached else '')
    completion = client.chat.completions.create(
        model=config.env('LITELLM_MODEL'),
        messages=[{'role':'system','content':msg},
                  {'role':'user','content':json.dumps(context, ensure_ascii=False, default=str)}],
        temperature=0, response_format={'type':'json_object'}, timeout=90)
    content = completion.choices[0].message.content
    data = json.loads(content)
    if data.get('action') == 'query' and not max_steps_reached:
        if not isinstance(data.get('sql'), str) or not isinstance(data.get('params'), dict):
            raise ValueError('Invalid query decision')
        return {'action':'query','sql':data['sql'],'params':data['params'],
                'reason':str(data.get('reason',''))[:500]}
    if data.get('action') == 'final' and isinstance(data.get('answer'), str):
        return {'action':'final','answer':data['answer']}
    raise ValueError('Invalid model decision')
