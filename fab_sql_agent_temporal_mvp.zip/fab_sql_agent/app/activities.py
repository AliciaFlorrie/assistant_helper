from temporalio import activity
from .oracle_tools import schema_catalog, execute_sql
from .agent import decide

@activity.defn
async def load_schema():
    import asyncio
    return await asyncio.to_thread(schema_catalog)

@activity.defn
async def model_step(payload: dict):
    import asyncio
    return await asyncio.to_thread(decide, payload['question'], payload['catalog'],
                                   payload['history'], payload['max_steps_reached'])

@activity.defn
async def run_query(payload: dict):
    import asyncio
    return await asyncio.to_thread(execute_sql, payload['sql'], payload['params'])
