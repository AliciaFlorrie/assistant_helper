import pytest
from app import config
from app.oracle_tools import validate_sql

def setup_module():
    config.ORACLE_SCHEMA = 'FAB_READONLY'
    config.ALLOWED_TABLES = {'ENTITY_STATUS'}

def test_good():
    assert validate_sql('SELECT STATUS FROM ENTITY_STATUS WHERE ENTITY_ID = :entity_id',
                        {'entity_id':'EQP_001'})

def test_write_rejected():
    with pytest.raises(ValueError):
        validate_sql('DELETE FROM ENTITY_STATUS', {})

def test_unapproved_table():
    with pytest.raises(ValueError):
        validate_sql('SELECT X FROM SECRET_TABLE', {})

def test_multi_statement():
    with pytest.raises(Exception):
        validate_sql('SELECT STATUS FROM ENTITY_STATUS; DELETE FROM ENTITY_STATUS', {})
