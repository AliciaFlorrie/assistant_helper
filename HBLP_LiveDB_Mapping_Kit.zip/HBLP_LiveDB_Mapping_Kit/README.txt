HBLP 外部数据映射工具包
======================

目标：将原 package 的外部输入映射到 APF 可访问的 LiveDB；保留原计算、过滤、窗口与排序规则。
本包不是已完成的 HBLP rule，也不连接数据库，不新增业务校验。
已按你的说明采用 HBLP_LOT_TOOL_STATUS 作为 HBLP_LOT_TOOL_STATUS_V 的基础表。
“外部”按你的定义排除 HBLP_ 开头的对象，不是指另一个数据库。

先打开 mapping_guide.html：包括全部直接读取对象的用途、字段证据、优先级、候选映射与人工步骤。
用 Excel 打开 inventory/field_mapping.csv：逐字段填写 LiveDB对象、字段或表达式、关联路径及键、一对多取值规则、单位及时间口径、确认状态。
再看 manual_supplement.csv：本次人工补充的无别名字段、星号传播字段和待确认项，不能遗漏。
inventory/report_candidates.csv 是现有 report 中实际出现的对象/字段/lookup表达式；仅为候选证据，不代表与原字段语义等价。
inventory/source_inventory.csv 是源对象索引；inventory/sql_evidence.json 保留关联、过滤、聚合所在 SELECT 的原文和行号。
行号对应本次 HBLP.json（文件内容实际为 PL/SQL）。没有附带源文件副本。

重新提取（Python 3.9+，只用标准库，无需安装包）：
  python extract_hblp_sources.py --package "HBLP.json" --reports "reports目录" --out "mapping_new"

可以省略 --reports。请每次使用新的 --out 目录，以免覆盖人工填写结果。
脚本自动输出不包含本次手工注释：manual_supplement.csv 与 mapping_guide.html 是针对已提供版本的人工审阅成果，SQL改版后需要复核。
脚本分析静态 SELECT 的作用域与别名；不完整展开未限定字段、星号、CTE、视图、同义词或动态SQL，不能宣称覆盖所有间接依赖。范围见 extraction_limits.txt。

推荐最短工作方式：
1. 在现有 report 的 LiveDB 数据浏览器中先定位 WIP_LOT；对照 field_mapping.csv 的 MC_1_F_LOT 行。
2. 对缺失字段沿 row_id、flowplan_route_row_id、route_oper_row_id 查关联对象，保留 APF 原 lookup 的复合键和 namespace。
3. 给每类对象导出小样本：一个普通 lot、一个 rework/重复经过同一 operation 的 lot、一个在机台运行的 lot。这里只用于核对映射，不在业务 rule 中新增校验节点。
4. 历史事件按 LOT+OPERATION+PREVOUT_DATE，并在原逻辑需要处保留 ENTITY+RUNID/LOTRUNID；不要只按 LotID 取最新值。
5. 找不到时填写“LiveDB未找到”，不要填常量、空值或直接用当前值顶替历史值。必要时由数据维护方将等价历史/模型数据同步到 APF 可见对象，再继续迁移。
6. 将填好的两份CSV及必要的对象字段截图/小样本发回，即可据此接入rule。

实现建议：建立若干输入适配模块，把 LiveDB字段/关联结果投影成原SQL字段名称，再连接原HBLP计算步骤。以后替换ETA时，只替换计算模块，保持最终LP_predictions_DSS输出契约。
不要将所有表join成一张大表：事件、MOQ、wafer、路线都是不同粒度；先按原SQL聚合/筛选，再关联，以免把一条lot预测复制成多条。
本次没有更改业务规则，也没有添加 wip_validate 或 inputstate 检查。

边界：
- HBLP_表、视图、MV按要求未列入外部源映射，但其模型参数、统计结果等仍是原算法依赖；排除清单不等于可删除。
- 本次只统计package直接读取对象，未取得各视图/MV定义，无法确认它们背后的全部物理表。
- MC_1_F_FACILITY只见于%TYPE变量声明，不当作实际读取源。
- F_NTSC_ENTITYHIST等出现在WELL_PROGRESS.DATA_TYPE的字符串条件中，不是该函数直接查询的表。
- MC_1_F_EXTRACTMETRICS既用于读取完成时间，也由SP$LOG_METRICS写日志；字段清单聚焦读取依赖。
- SP$PM_OVERDUE在SP$MAIN中被注释，只能确认本入口未执行，不能断言没有其他任务调用。

验证：脚本已对提供的package与6个report执行；提取27个外部读取对象、217条“限定字段×使用过程”记录、53个来源引用证据、149条去重report候选记录。217不是完整字段总数；额外字段与疑点见manual_supplement.csv。
已用小型SQL样例核对别名遮蔽、相关子查询、逗号join、小写表名、注释排除。未连接LiveDB，未验证最终rule运行结果。
