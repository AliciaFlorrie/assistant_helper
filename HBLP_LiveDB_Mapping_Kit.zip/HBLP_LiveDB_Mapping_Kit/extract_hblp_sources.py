#!/usr/bin/env python3
"""Offline Oracle package dependency worksheet. Python 3.9+, standard library only.
Static aid, not a SQL compiler: no DB connection or business logic modification.
"""
import argparse, bisect, csv, html, json, re
from pathlib import Path
from urllib.parse import unquote

LEX = re.compile(r"--[^\n]*|/\*[\s\S]*?\*/|'(?:''|[^'])*'|[A-Za-z_][\w$#]*|\d+(?:\.\d+)?|[^\s]", re.M)
WORD = re.compile(r'^[A-Z_][\w$#]*$')
STOP = set('WHERE GROUP ORDER HAVING UNION MINUS INTERSECT CONNECT START MODEL FETCH FOR RETURNING INTO SET JOIN LEFT RIGHT FULL INNER OUTER CROSS ON USING SELECT FROM AS AND OR'.split())

def write_csv(path, rows, columns):
    with path.open('w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=columns); w.writeheader(); w.writerows(rows)

def extract(sql):
    lines = sql.splitlines(); starts = [0]
    for m in re.finditer('\n', sql): starts.append(m.end())
    ts=[]; depth=0
    for m in LEX.finditer(sql):
        value=m.group()
        if value.startswith(('--','/*')): continue
        if value==')': depth-=1
        ts.append((value.upper() if not value.startswith("'") else value,m.start(),depth))
        if value=='(': depth+=1
    proc=[(m.start(),m.group(1).upper()) for m in re.finditer(r'(?im)^\s*(?:PROCEDURE|FUNCTION)\s+([\w$]+)',sql)]
    def procedure(pos):
        return next((n for p,n in reversed(proc) if p<=pos),'PACKAGE')
    def line(i): return bisect.bisect_right(starts,ts[i][1])
    scopes=[]
    for i,t in enumerate(ts):
        if t[0]!='SELECT': continue
        end=i+1
        while end<len(ts):
            v,p,d=ts[end]
            if d<t[2] or (d==t[2] and v in (';','UNION','MINUS','INTERSECT')): break
            end+=1
        scopes.append({'start':i,'end':end,'depth':t[2],'aliases':{},'tables':[]})
    refs=[]
    for s in scopes:
        i=s['start']+1; in_from=False; expect=False
        while i<s['end']:
            v,_,d=ts[i]
            if d!=s['depth']: i+=1; continue
            if v=='FROM': in_from=True; expect=True; i+=1; continue
            if v=='JOIN': expect=True; i+=1; continue
            if v in ('WHERE','GROUP','ORDER','HAVING','CONNECT','START'): in_from=False; expect=False
            if v==',' and in_from: expect=True; i+=1; continue
            if expect:
                expect=False
                if v=='(':
                    j=i+1
                    while j<s['end'] and not (ts[j][0]==')' and ts[j][2]==d): j+=1
                    if j+1<s['end'] and WORD.match(ts[j+1][0]) and ts[j+1][0] not in STOP:
                        s['aliases'][ts[j+1][0]]=None
                    i=j+1; continue
                if WORD.match(v):
                    name=v; j=i+1
                    while j+1<s['end'] and ts[j][0]=='.': name+='.'+ts[j+1][0]; j+=2
                    if j<s['end'] and ts[j][0]=='AS': j+=1
                    alias=name.split('.')[-1]
                    if j<s['end'] and WORD.match(ts[j][0]) and ts[j][0] not in STOP: alias=ts[j][0]; j+=1
                    # CTE names are recorded to shadow outer aliases, but not external sources.
                    external=(name.startswith(('MC_','MS_','XETA.','F68_PROD_1.')))
                    s['aliases'][alias]=name if external else None
                    if external:
                        ref={'table':name,'alias':alias,'procedure':procedure(ts[i][1]),'line':line(i),'scope':s,'token':i}
                        refs.append(ref); s['tables'].append(name)
                    i=j; continue
            i+=1
    fields={}; wild=[]
    for i in range(len(ts)-2):
        a=ts[i][0]; col=ts[i+2][0]
        if ts[i+1][0]!='.' or not WORD.match(a) or not (WORD.match(col) or col=='*'): continue
        owners=sorted((s for s in scopes if s['start']<=i<s['end']),key=lambda s:s['start'],reverse=True)
        for s in owners:
            if a not in s['aliases']: continue
            table=s['aliases'][a]
            if table:
                key=(table,col,procedure(ts[i][1]))
                fields.setdefault(key,[]).append(line(i))
            break
    rows=[]
    for (table,col,procname), nums in sorted(fields.items()):
        nums=sorted(set(nums))
        rows.append({'原对象':table,'原字段':col,'使用过程':procname,'证据类型':'星号展开，需核对' if col=='*' else '限定字段直接引用',
                     'SQL行号':';'.join(map(str,nums)), 'SQL片段':' | '.join(lines[n-1].strip() for n in nums[:4]),
                     'LiveDB对象':'','LiveDB字段或表达式':'','关联路径及键':'','一对多取值规则':'','单位及时间口径':'','确认状态':'待确认'})
    evidence=[]
    for r in refs:
        s=r['scope']; a=ts[s['start']][1]; b=ts[s['end']][1] if s['end']<len(ts) else len(sql)
        evidence.append({'table':r['table'],'alias':r['alias'],'procedure':r['procedure'],'line':r['line'],
                         'select_start_line':line(s['start']),'sql':sql[a:b]})
    return rows,evidence

def scan_reports(folder):
    rows=[]
    for p in sorted(Path(folder).rglob('*.report')):
        txt=html.unescape(unquote(p.read_text(encoding='utf-8-sig',errors='replace')))
        # Lookup syntax evidence only: report declarations are not LiveDB metadata.
        for m in re.finditer(r'\b([A-Z][A-Z0-9_]+)\s*\{([^{}]{0,500})\}\s*\.\s*([A-Za-z_]\w*)',txt):
            rows.append({'report':p.name,'对象候选':m.group(1),'字段候选':m.group(3),'lookup键表达式':m.group(2),'性质':'report表达式证据，需确认LiveDB可访问性'})
        # Database blocks hold folder plus expressions using __FOLDER__.
        import xml.etree.ElementTree as ET
        raw=p.read_text(encoding='utf-8-sig',errors='replace')
        try:
            body=raw[raw.index('<blocks>'):raw.index('</blocks>')+9].replace('\\"','"')
            root=ET.fromstring(body)
            for obj in root.findall('.//objects/object'):
                for persist in obj.findall('.//persistence'):
                    folders=persist.findall('./folder/expression')
                    folder=unquote(folders[0].get('expr','')) if folders else ''
                    for exp in persist.findall('./columns/expression'):
                        expression=unquote(exp.get('expr',''))
                        if folder and '__FOLDER__.' in expression:
                            rows.append({'report':p.name,'对象候选':folder,'字段候选':expression.replace('__FOLDER__.',''),'lookup键表达式':'Database block','性质':'report数据库列配置，需确认语义'})
        except (ValueError,ET.ParseError): pass
    return [dict(t) for t in {tuple(r.items()) for r in rows}]

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--package',required=True); ap.add_argument('--reports'); ap.add_argument('--out',default='hblp_mapping_output')
    a=ap.parse_args(); out=Path(a.out); out.mkdir(parents=True,exist_ok=True)
    sql=Path(a.package).read_text(encoding='utf-8-sig')
    if not re.search(r'\b(?:CREATE|PACKAGE|PROCEDURE)\b',sql,re.I): raise SystemExit('需要纯文本PL/SQL（本次HBLP.json实为PL/SQL）；不自动解析任意JSON结构。')
    rows,evidence=extract(sql)
    cols=['原对象','原字段','使用过程','证据类型','SQL行号','SQL片段','LiveDB对象','LiveDB字段或表达式','关联路径及键','一对多取值规则','单位及时间口径','确认状态']
    write_csv(out/'field_mapping.csv',rows,cols)
    sources=[]
    for t in sorted({e['table'] for e in evidence}):
        es=[e for e in evidence if e['table']==t]; fs=sorted({r['原字段'] for r in rows if r['原对象']==t})
        sources.append({'原对象':t,'使用过程':';'.join(sorted({e['procedure'] for e in es})),'引用行号':';'.join(str(e['line']) for e in es),'限定字段（非完整schema）':';'.join(fs),'LiveDB对应对象':'','备注':'SP$PM_OVERDUE在MAIN中未启用' if all(e['procedure']=='SP$PM_OVERDUE' for e in es) else ''})
    write_csv(out/'source_inventory.csv',sources,['原对象','使用过程','引用行号','限定字段（非完整schema）','LiveDB对应对象','备注'])
    (out/'sql_evidence.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2),encoding='utf-8')
    if a.reports:
        rs=scan_reports(a.reports)
        write_csv(out/'report_candidates.csv',sorted(rs,key=lambda r:(r['对象候选'],r['字段候选'],r['report'])),['report','对象候选','字段候选','lookup键表达式','性质'])
    (out/'extraction_limits.txt').write_text('本工具只提取SELECT中直接FROM/JOIN的MC_、MS_、XETA.、F68_PROD_1.来源，排除HBLP_对象。\n不展开视图/同义词/动态SQL，不是通用SQL解析器。限定字段使用SELECT作用域解析；未限定字段、CTE/子查询星号传播需结合sql_evidence.json人工补充。\n源表清单不把%TYPE声明当读表；不含INSERT日志写入字段。词法不支持Oracle q引号及带引号标识符。\nCSV含待填写列。重复运行请用新的--out目录，避免覆盖人工填写。\n',encoding='utf-8')
    print(json.dumps({'source_tables':len(sources),'qualified_field_procedure_rows':len(rows),'select_evidence':len(evidence)},ensure_ascii=False))

if __name__=='__main__': main()
