# V4.3 bounded query fallback

Based on app_v41_stability_patch.zip. Replace app after draining old workflows. No database migration or new dependencies.

Environment defaults:
```
QUERY_WALL_TIMEOUT_SECONDS=120
ENABLE_TIMEOUT_FALLBACK=true
MAX_TIMEOUT_FALLBACKS=1
QUERY_CALL_TIMEOUT_MS=300000
SQL_ACTIVITY_TIMEOUT_SECONDS=360
MAX_MODEL_FAILURES=2
```
Driver call timeout is capped by wall timeout. A watchdog requests connection.cancel(); fallback is allowed only when watchdog cancellation returns and Oracle reports ORA-01013, after connection cleanup. Other timeout types stop conservatively. This is best effort, not a guaranteed hard server deadline; connection establishment, cancellation and cleanup can still block. Temporal activity timeout is at least wall timeout + 60s. No automatic activity retries. Fallback uses existing query budget and is always PARTIAL or FAILED; no full result claim. Model chooses bounded subset; no independent semantic equivalence verifier. Template search adds lexical SQL content scoring, not embeddings. Template defaults are inferred by model. Existing templates unchanged.

Tests: existing unit tests and compileall; real Oracle cancellation, Temporal and LLM integration not tested. Test with a deliberately slow read-only query in a nonproduction environment before enabling fallback in production. Set ENABLE_TIMEOUT_FALLBACK=false to disable. DBA should inspect actual plan for 229 and validate any rewritten metric against original on a bounded window.
