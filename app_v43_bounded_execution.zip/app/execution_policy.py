"""Pure, deterministic execution policy; no I/O inside workflow."""
from dataclasses import dataclass
import json

RETRIEVAL = {'search_datasources','search_tables','get_table_schema','find_join_paths','search_examples'}
EXECUTION = {'query','execute_template'}

@dataclass
class Budget:
    retrieval: int
    queries: int
    retries: int
    rejections: int
    decisions: int
    def allowed(self, history):
        actions = {'final','failed','ask_user'}
        if self.retrieval > 0: actions |= RETRIEVAL
        if self.queries > 0 and self.retries > 0: actions |= EXECUTION
        return sorted(actions)


def evidence(history):
    return [i+1 for i,x in enumerate(history) if x['action'] in EXECUTION and not x.get('error') and isinstance(x.get('result'),dict) and isinstance(x['result'].get('rows'),list) and not x['result'].get('error')]


def gate(decision, history, requires_query):
    if decision['action'] != 'final': return None
    if not requires_query: return None
    ids = decision.get('evidence_steps', [])
    if not ids or not set(ids).issubset(set(evidence(history))):
        return 'Actual data required: execute a relevant SQL or template and cite successful evidence_steps before final.'
    if decision.get('complete') is not True:
        return 'Task not complete: execute remaining relevant queries or report partial failure when budget is exhausted.'
    return None


def signature(d):
    return json.dumps({k:d.get(k) for k in ('action','datasource','sql','template_id','params')},sort_keys=True,default=str)
