from datetime import timedelta
from temporalio import workflow
from temporalio.exceptions import CancelledError
import asyncio
from temporalio.common import RetryPolicy
with workflow.unsafe.imports_passed_through():
    from .activities import load_schema, knowledge_action, model_step, run_query, run_template
    from .config import MAX_QUERY_STEPS, MAX_RETRIEVAL_STEPS, MAX_QUERY_RETRIES, MAX_FINAL_REJECTIONS, MAX_AGENT_STEPS, MODEL_ACTIVITY_TIMEOUT_SECONDS, SQL_ACTIVITY_TIMEOUT_SECONDS, MAX_MODEL_FAILURES, ENABLE_TIMEOUT_FALLBACK, MAX_TIMEOUT_FALLBACKS, QUERY_WALL_TIMEOUT_SECONDS
    from .execution_policy import Budget, RETRIEVAL, EXECUTION, evidence, gate, signature


def error_text(exc):
    messages=[]
    for _ in range(8):
        if exc is None: break
        messages.append(str(exc))
        exc=getattr(exc,'cause',None) or getattr(exc,'__cause__',None)
    return ' | '.join(messages)[:4000]

@workflow.defn
class SQLAgentWorkflow:
    @workflow.run
    async def run(self,question:str)->dict:
        history=[]
        budget=Budget(MAX_RETRIEVAL_STEPS,MAX_QUERY_STEPS,MAX_QUERY_RETRIES,MAX_FINAL_REJECTIONS,MAX_AGENT_STEPS)
        # Data execution is the default contract of this CLI. Explicit explanation-only requests are exempt.
        requires_query=not question.strip().lower().startswith(('explain only:', '仅解释：','只解释：'))
        attempted=set()
        model_failures=0
        partial_fallback=False
        fallback_count=0
        def finish(status,answer):
            if partial_fallback:
                status='PARTIAL' if evidence(history) else 'FAILED'
                answer='Full requested result was not completed. Any fallback results are partial and must not be interpreted as full-window indicators.\n'+answer
            return {'answer':answer,'steps':history,'status':status,'evidence_steps':evidence(history),'remaining_budget':vars(budget).copy()}
        async def call(fn,payload):
            return await workflow.execute_activity(fn,payload,start_to_close_timeout=timedelta(seconds=MODEL_ACTIVITY_TIMEOUT_SECONDS if fn==model_step else max(SQL_ACTIVITY_TIMEOUT_SECONDS, QUERY_WALL_TIMEOUT_SECONDS+60) if fn in (run_query,run_template) else 60),retry_policy=RetryPolicy(maximum_attempts=1))
        try:
            directory=await workflow.execute_activity(load_schema,start_to_close_timeout=timedelta(seconds=300),retry_policy=RetryPolicy(maximum_attempts=1))
        except Exception as exc:
            return finish('FAILED',error_text(exc))
        # Reserve one synthesis decision even when normal decision budget is exhausted.
        for turn in range(MAX_AGENT_STEPS+1):
            must_finish=turn==MAX_AGENT_STEPS or (budget.queries<=0 or budget.retries<=0)
            allowed=['final','failed'] if must_finish else budget.allowed(history)
            if partial_fallback:
                allowed=['failed'] if fallback_count>=MAX_TIMEOUT_FALLBACKS or must_finish else ['query','failed']
            if not must_finish: budget.decisions-=1
            if not partial_fallback and not must_finish and requires_query and budget.rejections<=0:
                allowed=[a for a in allowed if a not in ('final','failed','ask_user')] if not evidence(history) else allowed
            policy={'allowed_actions':allowed,'remaining_budget':vars(budget).copy(),'requires_query':requires_query,'partial_fallback':partial_fallback,'successful_evidence_steps':evidence(history)}
            try:
                decision=await call(model_step,{'question':question,'catalog':directory,'history':history,'max_steps_reached':must_finish,'policy':policy})
            except (CancelledError, asyncio.CancelledError):
                raise
            except Exception as exc:
                model_failures+=1
                history.append({'action':'system_feedback','arguments':{},'error':error_text(exc)})
                if must_finish or model_failures>=MAX_MODEL_FAILURES: break
                continue
            if decision.get("action")=="model_error":
                model_failures+=1
                history.append({"action":"system_feedback","arguments":{},"error":decision["kind"]+": "+decision["error"]})
                if must_finish or model_failures>=MAX_MODEL_FAILURES or decision["kind"] in ("gateway_timeout","model_timeout"): break
                continue
            model_failures=0
            a=decision['action']
            if a in ('final','failed','ask_user'):
                rejection=gate(decision,history,requires_query)
                if not partial_fallback and a!='final' and not must_finish and requires_query and budget.queries>0 and budget.retries>0:
                    rejection='Do not stop or ask optional questions. Attempt a relevant query using template defaults. If essential inputs are missing, explain the specific blocker.'
                if a not in allowed: rejection='Action not allowed by remaining budget.'
                if not rejection:
                    status={'final':'COMPLETED','failed':'PARTIAL' if evidence(history) else 'FAILED','ask_user':'NEEDS_INPUT'}[a]
                    return finish(status,decision['answer'])
                history.append({'action':'system_feedback','arguments':{'rejected_action':a},'result':rejection})
                budget.rejections=max(0,budget.rejections-1)
                if must_finish: break
                continue
            if must_finish: break
            if a not in allowed:
                history.append({'action':'system_feedback','arguments':{'rejected_action':a},'result':'Budget exhausted for this action; use allowed actions.'})
                continue
            item={'action':a,'arguments':{k:v for k,v in decision.items() if k!='action'}}
            if a in EXECUTION:
                sig=signature(decision)
                if sig in attempted:
                    history.append({'action':'system_feedback','arguments':{'rejected_action':a},'result':'Identical execution already attempted. Use existing evidence or correct SQL.'})
                    continue
                attempted.add(sig); budget.queries-=1
                if partial_fallback: fallback_count+=1
            else: budget.retrieval-=1
            try:
                if a=='query':
                    item['result']=await call(run_query,{k:decision[k] for k in ('datasource','sql','params')})
                elif a=='execute_template':
                    response=await call(run_template,{k:decision[k] for k in ('datasource','template_id','params')})
                    # Preserve failed SQL for repair, avoid duplicating successful template text in context.
                    if 'error' in response:
                        item['arguments']['sql']=response['sql']; item['error']=response['error']
                    else: item['result']=response['result']
                else: item['result']=await call(knowledge_action,decision)
            except (CancelledError, asyncio.CancelledError):
                raise
            except Exception as exc: item['error']=error_text(exc)
            if isinstance(item.get('result'),dict) and item['result'].get('error'):
                item['error']=item['result']['error']
            if a in EXECUTION and (item.get('error') or (isinstance(item.get('result'),dict) and item['result'].get('error'))): budget.retries-=1
            history.append(item)
            # A timed-out exact template is not evidence of invalid SQL. Do not launch
            # another expensive scan while the original server call may still be running.
            if a in EXECUTION and any(t in item.get('error','').lower() for t in ('timed out','timeout','query_cancel_confirmed','dpi-1067','dpi-1080','ora-01013','ora-03156')):
                if ENABLE_TIMEOUT_FALLBACK and not partial_fallback and MAX_TIMEOUT_FALLBACKS>0 and budget.queries>0 and budget.retries>0 and isinstance(item.get('result'),dict) and item['result'].get('cancel_confirmed') is True:
                    partial_fallback=True
                    history.append({'action':'system_feedback','arguments':{},'result':'Original query cancelled. Attempt one bounded partial query; disclose actual time range, metrics and omitted logic. Never claim full completion.'})
                    continue
                return finish('PARTIAL' if evidence(history) else 'FAILED', 'Database execution timed out. No automatic rewrite or repeat was issued; check Oracle execution and timeout settings.')
        return finish('PARTIAL' if evidence(history) else 'FAILED','Execution ended without a fully supported answer. Last error: '+next((x['error'] for x in reversed(history) if x.get('error')), 'execution budget exhausted'))
