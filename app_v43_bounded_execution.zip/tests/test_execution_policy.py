import unittest
from app.execution_policy import Budget, gate, evidence, signature
from app.history import compact_history

class PolicyTest(unittest.TestCase):
    def test_premature_final(self):
        self.assertIsNotNone(gate({'action':'final','complete':True,'evidence_steps':[]},[],True))
    def test_evidence(self):
        h=[{'action':'execute_template','result':{'rows':[]}}, {'action':'query','error':'ORA'}]
        self.assertEqual(evidence(h),[1])
        self.assertIsNone(gate({'action':'final','complete':True,'evidence_steps':[1]},h,True))
        self.assertIsNotNone(gate({'action':'final','complete':True,'evidence_steps':[2]},h,True))
        self.assertIsNotNone(gate({'action':'final','complete':False,'evidence_steps':[1]},h,True))
    def test_budget(self):
        b=Budget(0,2,1,2,3)
        self.assertIn('execute_template',b.allowed([]))
        self.assertNotIn('search_tables',b.allowed([]))
        b.retries=0
        self.assertNotIn('query',b.allowed([]))
    def test_template_error_history(self):
        h=[{'action':'get_table_schema','result':{'columns':[{'name':'A'}]}},{'action':'execute_template','arguments':{'sql':'SELECT A FROM T'},'error':'ORA'}]
        self.assertIn('Omitted',compact_history(h)[0]['result'])
        self.assertEqual(compact_history(h)[1],h[1])
    def test_duplicate(self):
        d={'action':'query','sql':'SELECT A FROM T','params':{},'datasource':'x'}
        self.assertEqual(signature(d),signature(dict(d,reason='different')))
