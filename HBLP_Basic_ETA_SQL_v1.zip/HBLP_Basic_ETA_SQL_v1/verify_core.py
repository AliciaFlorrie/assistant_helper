"""Offline arithmetic/window checks; does not compile Oracle source adapters."""
import sqlite3
from pathlib import Path
sql=Path(__file__).with_name('01_hblp_basic_reference.sql').read_text(encoding='utf-8')
core=sql[sql.index('step_duration AS ('):]
# Oracle numeric division is fractional; SQLite integer operands require REAL.
core=core.replace('/ 1440', '/ 1440.0')
db=sqlite3.connect(':memory:')
db.create_function('GREATEST',2,lambda a,b: None if a is None or b is None else max(a,b))
db.executescript('''
CREATE TABLE lot_input(facility,lot_id,as_of_time,entered_oper_time,current_remaining_min);
CREATE TABLE step_input(facility,lot_id,operation,operation_version,route,flowplan,flow_context,step_seq,queue_min,process_min);
''')
def run(elapsed=20,override=None,missing=False):
 db.execute('DELETE FROM lot_input'); db.execute('DELETE FROM step_input')
 db.execute('INSERT INTO lot_input VALUES(?,?,?,?,?)',('F','L',100,100-elapsed/1440,override))
 for i,(op,q,p) in enumerate([('A',10,30),('B',10,None if missing else 40),('C',5,25),('A',8,22)],1):
  db.execute('INSERT INTO step_input VALUES(?,?,?,?,?,?,?,?,?,?)',('F','L',op,1,'R','FP',f'C{i}',i,q,p))
 return db.execute('WITH '+core).fetchall()
def offsets(rows): return [r[-1] for r in rows]
def approx(got,exp):
 assert len(got)==len(exp)
 for a,b in zip(got,exp):
  assert (a is None and b is None) or (a is not None and b is not None and abs(a-b)<1e-7),(got,exp)
approx(offsets(run()),[20,70,100])
approx(offsets(run(elapsed=60)),[0,50,80])
approx(offsets(run(override=17)),[17,67,97])
approx(offsets(run(override=0)),[0,50,80])
approx(offsets(run(missing=True)),[20,None,None])
assert [r[2] for r in run()]==['B','C','A']
assert [r[7] for r in run()]==[2,3,4]
print('PASS: arrival before target processing; overdue current step; model override; zero override; unknown-duration propagation; repeated operation visit.')
print('Not tested: Oracle compilation, LiveDB adapters, source uniqueness, production equivalence.')
