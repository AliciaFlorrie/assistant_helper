-- HBLP基础版：正常流程 + POU计划时间 + _S2剩余时间 + 累计ETA
-- Oracle参考SQL。只读SELECT，无TRUNCATE/INSERT/COMMIT。
-- 用途：解释并转译为APF rule；APF不能连原库时，不可直接执行此文件。
-- 需要绑定 :lot_id（先用一个正常流程lot调通）、:facility。
-- :as_of_time 为Oracle DATE；NULL表示使用SYSDATE。各日期采用同一时区。
-- 这是有意简化的版本，不等价于完整HBLP或DSS导出。
-- 仅3个物理来源：MC_1_F_LOT、MC_1_F_FLOWPLANROUTEOPER、MS_1_F_PROCESS_OPER_UDF。
-- POU在(PROCESS, OPERATION, WHAT_IF#=1)下必须提供唯一计划记录。
-- 若原表不唯一，按业务找真实键；这里不擅自MAX或取任意一行。
WITH
params AS (
    SELECT COALESCE(CAST(:as_of_time AS DATE), SYSDATE) AS as_of_time FROM dual
),
/* 01. 当前lot。PROCESS保留原package的SUBSTR(DOTPROCESS,1,4)。
   保留原Active/非hold/非terminated/正数量范围；仅抽取正常FLOW_CONTEXT路径。
   为调通单lot而移除HOTLOT/OWNER/LOT_PRIORITY配置名单，不声称覆盖原目标集合。
   不把MOVEIN_DATE当成DATE_ENTERED_OPERATION。
*/
lot_input AS (
    SELECT l.facility, l.lot AS lot_id,
           l.operation AS current_operation,
           l.flowplan, l.flowplan_version, l.flow_context,
           SUBSTR(l.dotprocess, 1, 4) AS process,
           CAST(l.date_entered_operation AS DATE) AS entered_oper_time,
           p.as_of_time,
           CAST(NULL AS NUMBER) AS current_remaining_min
    FROM MC_1_F_LOT l CROSS JOIN params p
    WHERE l.lot = :lot_id AND l.facility = :facility
      AND l.terminated = 'N' AND l.src_erase_date IS NULL
      AND l.lot_state = 'Active' AND l.onhold = 'N' AND l.wafer_qty > 0
      AND l.flowplan IS NOT NULL AND l.flow_context NOT LIKE '%,%'
),
/* 02. 定位当前流程上下文；本参考版只展开正常流程。
   不通过operation名称寻找第一行，避免重复工序定位错误。
   明确facility/flowplan/version用于限定上下文，是本版显式关联约定。
*/
current_position AS (
    SELECT l.*, c.plan_sequence AS current_plan_sequence
    FROM lot_input l
    JOIN MC_1_F_FLOWPLANROUTEOPER c
      ON c.facility = l.facility
     AND c.flowplan = l.flowplan AND c.flowplan_version = l.flowplan_version
     AND c.flow_context = l.flow_context
     AND c.src_erase_date IS NULL
),
flow_steps AS (
    SELECT l.facility, l.lot_id, l.process,
           f.operation, f.operation_version, f.route, f.flowplan, f.flow_context,
           ROW_NUMBER() OVER (
               PARTITION BY l.facility, l.lot_id ORDER BY f.plan_sequence
           ) AS step_seq
    FROM current_position l
    JOIN MC_1_F_FLOWPLANROUTEOPER f
      ON f.facility = l.facility
     AND f.flowplan = l.flowplan AND f.flowplan_version = l.flowplan_version
     AND f.plan_sequence >= l.current_plan_sequence
     AND f.src_erase_date IS NULL
),
/* 03. 仅保留原POU fallback作为首版计划时间来源。
   原SQL直接以天使用POU时间，本版统一乘1440转换为分钟。
   CT已经包含QT：PT=CT-QT，不能再把CT与QT相加。
   缺失计划时间不擅自填固定常量；对应后续ETA为NULL。
*/
step_input AS (
    SELECT f.facility, f.lot_id, f.operation, f.operation_version,
           f.route, f.flowplan, f.flow_context, f.step_seq,
           t.plan_queue_time * 1440 AS queue_min,
           (t.plan_cycle_time - t.plan_queue_time) * 1440 AS process_min
    FROM flow_steps f
    LEFT JOIN MS_1_F_PROCESS_OPER_UDF t
      ON t.process = f.process AND t.operation = f.operation AND t.what_if# = 1
),
/* 04. 每一行表示一个lot的一次工序访问，不以operation去重。
   step_seq=1必须为当前访问，后续按实际执行顺序；同一operation可重复。
   current_remaining_min是可替换接口：NULL时采用原_S2简化算法。
   这里NULL表示“未接入模型”，不是数据库缺值补0。
*/
step_duration AS (
    SELECT s.*, l.as_of_time, l.entered_oper_time,
           CASE WHEN s.step_seq = 1 THEN
                    COALESCE(l.current_remaining_min,
                        GREATEST(s.queue_min + s.process_min
                            - (l.as_of_time - l.entered_oper_time) * 1440, 0))
                ELSE s.queue_min + s.process_min
           END AS effective_duration_min
    FROM step_input s
    JOIN lot_input l ON l.facility = s.facility AND l.lot_id = s.lot_id
),
/* 05. 只累计目标站之前的耗时；目标站自己的QT/PT不计入其到达时间。
   当前站用剩余时间，之后的站用完整QT+PT。
   显式ROWS窗口；输入需保证每个lot的step_seq唯一。
*/
arrival_offset AS (
    SELECT d.*,
           SUM(effective_duration_min) OVER (
               PARTITION BY facility, lot_id ORDER BY step_seq
               ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING
           ) AS prior_duration_min,
           SUM(CASE WHEN effective_duration_min IS NULL THEN 1 ELSE 0 END) OVER (
               PARTITION BY facility, lot_id ORDER BY step_seq
               ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING
           ) AS prior_unknown_count
    FROM step_duration d
),
/* Oracle SUM会忽略NULL；若前序耗时未知，则ETA应未知，不能默认为0。
   这是计算空值传播，不增加校验流程，也不丢弃该lot。
*/
eta_result AS (
    SELECT a.*,
           CASE WHEN step_seq = 1 THEN entered_oper_time
                WHEN prior_unknown_count > 0 THEN CAST(NULL AS DATE)
                ELSE as_of_time + prior_duration_min / 1440
           END AS arrival_eta
    FROM arrival_offset a
)
SELECT facility, lot_id, operation, operation_version,
       route, flowplan, flow_context, step_seq,
       queue_min, process_min, effective_duration_min,
       as_of_time, arrival_eta,
       (arrival_eta - as_of_time) * 1440 AS delta_to_eta_min
FROM eta_result
WHERE step_seq > 1 -- 仅输出未来站；当前站是计算起点
ORDER BY facility, lot_id, step_seq;
