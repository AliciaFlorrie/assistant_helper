-- 可在Oracle直接执行的纯样例；不依赖任何业务表。
-- 时间10:00；当前A于09:40到达，QT=10/PT=30，剩余20分钟。
-- B为10+40分钟，C为5+25分钟。
-- 预期：B=10:20，C=11:10，再次访问A=11:40。
WITH
lot_input AS (
    SELECT 'FAB' AS facility, 'DEMO_LOT' AS lot_id,
           TO_DATE('2026-11-16 10:00:00','YYYY-MM-DD HH24:MI:SS') AS as_of_time,
           TO_DATE('2026-11-16 09:40:00','YYYY-MM-DD HH24:MI:SS') AS entered_oper_time,
           CAST(NULL AS NUMBER) AS current_remaining_min
    FROM dual
),
step_input AS (
    SELECT 'FAB' AS facility, 'DEMO_LOT' AS lot_id, 'A' AS operation,
           1 AS operation_version, 'R1' AS route, 'F1' AS flowplan,
           'CTX1' AS flow_context, 1 AS step_seq, 10 AS queue_min, 30 AS process_min FROM dual
    UNION ALL SELECT 'FAB','DEMO_LOT','B',1,'R1','F1','CTX2',2,10,40 FROM dual
    UNION ALL SELECT 'FAB','DEMO_LOT','C',1,'R1','F1','CTX3',3,5,25 FROM dual
    UNION ALL SELECT 'FAB','DEMO_LOT','A',1,'R1','F1','CTX4',4,8,22 FROM dual
),
/* 04. 每一行表示一个lot的一次工序访问，不以operation去重。
   step_seq=1必须为当前访问，后续按实际执行顺序；同一operation可重复。
   current_remaining_min是可替换接口：NULL时采用原_S2简化算法。
   这里NULL表示“未接入模型”，不是数据库缺值补0。
*/
step_duration AS (
    SELECT s.*, l.as_of_time, l.entered_oper_time,
           CASE WHEN s.step_seq = 1 THEN
                    COALESCE(l.current_remaining_min,
                        GREATEST(s.queue_min + s.process_min
                            - (l.as_of_time - l.entered_oper_time) * 1440, 0))
                ELSE s.queue_min + s.process_min
           END AS effective_duration_min
    FROM step_input s
    JOIN lot_input l ON l.facility = s.facility AND l.lot_id = s.lot_id
),
/* 05. 只累计目标站之前的耗时；目标站自己的QT/PT不计入其到达时间。
   当前站用剩余时间，之后的站用完整QT+PT。
   显式ROWS窗口；输入需保证每个lot的step_seq唯一。
*/
arrival_offset AS (
    SELECT d.*,
           SUM(effective_duration_min) OVER (
               PARTITION BY facility, lot_id ORDER BY step_seq
               ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING
           ) AS prior_duration_min,
           SUM(CASE WHEN effective_duration_min IS NULL THEN 1 ELSE 0 END) OVER (
               PARTITION BY facility, lot_id ORDER BY step_seq
               ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING
           ) AS prior_unknown_count
    FROM step_duration d
),
/* Oracle SUM会忽略NULL；若前序耗时未知，则ETA应未知，不能默认为0。
   这是计算空值传播，不增加校验流程，也不丢弃该lot。
*/
eta_result AS (
    SELECT a.*,
           CASE WHEN step_seq = 1 THEN entered_oper_time
                WHEN prior_unknown_count > 0 THEN CAST(NULL AS DATE)
                ELSE as_of_time + prior_duration_min / 1440
           END AS arrival_eta
    FROM arrival_offset a
)
SELECT facility, lot_id, operation, operation_version,
       route, flowplan, flow_context, step_seq,
       queue_min, process_min, effective_duration_min,
       as_of_time, arrival_eta,
       (arrival_eta - as_of_time) * 1440 AS delta_to_eta_min
FROM eta_result
WHERE step_seq > 1 -- 仅输出未来站；当前站是计算起点
ORDER BY facility, lot_id, step_seq;
