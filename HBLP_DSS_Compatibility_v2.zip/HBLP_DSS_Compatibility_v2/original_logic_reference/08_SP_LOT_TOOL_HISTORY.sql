-- REFERENCE ONLY: exact procedure body excerpt; not a standalone SQL script.
PROCEDURE SP$LOT_TOOL_HISTORY

IS

  c_PROCEDURE_NAME CONSTANT MC_1_F_EXTRACTMETRICS.EXTRACT_NAME%TYPE := 'SP$LOT_TOOL_HISTORY';
  v_StartTime DATE := SYSDATE;
  v_ElapsedTime NUMBER;
  v_RowsAdded    NUMBER := 0;

  c_SnapshotRec HBLP_LOT_TOOL_STATUS%ROWTYPE;
  c_SnapshotRec2 HBLP_LOT_TOOL_STATUS2%ROWTYPE;
  
  -- Production Cursor
  CURSOR curGetLotStatusSnapshot IS
  SELECT FACILITY,  
         LOT,
         PRODUCT,
         ROUTE,
         FLOWPLAN,
         FLOW_CONTEXT,
         ROUTE_BASE_NAME,
         OPERATION,
         OPERATION_VERSION,
         ENTITY,
         OWNER,
         LOT_PRIORITY,
         HOTLOT,
         LOT_STATE,
         PROCESS,
         DOTPROCESS,
         WAFER_QTY,
         DELTA_TO_ETA,
         ETA,
         EXEC_SEQ,
         ENTITYOPER_VALID,
         TOOL_QUALIFICATION,
         TOOL_UP,
         TOOL_BUSY,
         FSUI_PRIORITY,
         VALID_TOOL_FLAG,
         RN,
         LAST_LOAD_DATE AS SNAPSHOT_DATE  
  FROM HBLP_LOT_TOOL_STATUS
  WHERE RN = 1;           

  -- Testing new model Cursor
  CURSOR curGetLotStatusSnapshot2 IS
  SELECT FACILITY,  
         LOT,
         PRODUCT,
         ROUTE,
         FLOWPLAN,
         FLOW_CONTEXT,
         ROUTE_BASE_NAME,
         OPERATION,
         OPERATION_VERSION,
         ENTITY,
         OWNER,
         LOT_PRIORITY,
         HOTLOT,
         LOT_STATE,
         PROCESS,
         DOTPROCESS,
         WAFER_QTY,
         DELTA_TO_ETA,
         ETA,
         EXEC_SEQ,
         ENTITYOPER_VALID,
         TOOL_QUALIFICATION,
         TOOL_UP,
         TOOL_BUSY,
         FSUI_PRIORITY,
         VALID_TOOL_FLAG,
         RN,
         LAST_LOAD_DATE AS SNAPSHOT_DATE  
  FROM HBLP_LOT_TOOL_STATUS2
  WHERE RN = 1;           

  
BEGIN

    -- Start: Production Version of Snapshot History for validation


    SP$LOG_ME(c_PROCEDURE_NAME || ' Begins');

    FOR c_SnapshotRec IN curGetLotStatusSnapshot LOOP

    BEGIN

        -- Attempt to insert the record.
        -- If we get an Duplicate key violation, trap the error and do an update instead
        --
        
        
        INSERT INTO HBLP_LOT_TOOL_HIST
        (FACILITY,
         LOT,
         PRODUCT,
         ROUTE,
         FLOWPLAN,
         FLOW_CONTEXT,
         ROUTE_BASE_NAME,
         OPERATION,
         OPERATION_VERSION,
         ENTITY,
         OWNER,
         LOT_PRIORITY,
         HOTLOT,
         LOT_STATE,
         PROCESS,
         DOTPROCESS,
         WAFER_QTY,
         DELTA_TO_ETA,
         ETA,
         EXEC_SEQ,
         ENTITYOPER_VALID,
         TOOL_QUALIFICATION,
         TOOL_UP,
         TOOL_BUSY,
         FSUI_PRIORITY,
         VALID_TOOL_FLAG,
         RN,
         SNAPSHOT_DATE)
        VALUES
        (
          c_SnapshotRec.FACILITY,  
          c_SnapshotRec.LOT,
          c_SnapshotRec.PRODUCT,
          c_SnapshotRec.ROUTE,
          c_SnapshotRec.FLOWPLAN,
          c_SnapshotRec.FLOW_CONTEXT,
          c_SnapshotRec.ROUTE_BASE_NAME,
          c_SnapshotRec.OPERATION,
          c_SnapshotRec.OPERATION_VERSION,
          c_SnapshotRec.ENTITY,
          c_SnapshotRec.OWNER,
          c_SnapshotRec.LOT_PRIORITY,
          c_SnapshotRec.HOTLOT,
          c_SnapshotRec.LOT_STATE,
          c_SnapshotRec.PROCESS,
          c_SnapshotRec.DOTPROCESS,
          c_SnapshotRec.WAFER_QTY,
          c_SnapshotRec.DELTA_TO_ETA,
          c_SnapshotRec.ETA,
          c_SnapshotRec.EXEC_SEQ,
          c_SnapshotRec.ENTITYOPER_VALID,
          c_SnapshotRec.TOOL_QUALIFICATION,
          c_SnapshotRec.TOOL_UP,
          c_SnapshotRec.TOOL_BUSY,
          c_SnapshotRec.FSUI_PRIORITY,
          c_SnapshotRec.VALID_TOOL_FLAG,
          c_SnapshotRec.RN,
          c_SnapshotRec.SNAPSHOT_DATE  
         );


         v_RowsAdded := v_RowsAdded + 1;

         --
         -- Record already exists so do nothing
         --
         EXCEPTION
             WHEN DUP_VAL_ON_INDEX THEN 
               NULL;

                WHEN OTHERS THEN
                   DECLARE
                     v_ERROR_CODE NUMBER := SQLCODE;
                     v_ERROR_MESSAGE VARCHAR2(300) := SQLERRM;
                     v_COMMENTS VARCHAR2(500);

                   BEGIN

                     v_COMMENTS := v_ERROR_CODE || ' - ' || v_ERROR_MESSAGE;
                     SP$LOG_ME(c_PROCEDURE_NAME || ' - Error Loading Snapshot Data' || v_Comments);
                     SP$LOG_METRICS
                     (
                       p_ExtractName => c_PROCEDURE_NAME,
                       p_ExtractStartDate => v_StartTime,
                       p_ExtractEndDate => SYSDATE,
                       p_RunStartDate => v_StartTime,
                       p_RunEndDate => SYSDATE,
                       p_Status => 'FAILURE',
                       p_Comments => v_Comments
                     );
                 END;


         END; --Duplicate Key Exception
        END LOOP;


      COMMIT;
    -- End: Production Version of Snapshot History for validation


    -- Start: Testing Version of Snapshot History for validation
    FOR c_SnapshotRec2 IN curGetLotStatusSnapshot2 LOOP

    BEGIN

        -- Attempt to insert the record.
        -- If we get an Duplicate key violation, trap the error and do an update instead
        --
        
        
        INSERT INTO HBLP_LOT_TOOL_HIST2
        (FACILITY,
         LOT,
         PRODUCT,
         ROUTE,
         FLOWPLAN,
         FLOW_CONTEXT,
         ROUTE_BASE_NAME,
         OPERATION,
         OPERATION_VERSION,
         ENTITY,
         OWNER,
         LOT_PRIORITY,
         HOTLOT,
         LOT_STATE,
         PROCESS,
         DOTPROCESS,
         WAFER_QTY,
         DELTA_TO_ETA,
         ETA,
         EXEC_SEQ,
         ENTITYOPER_VALID,
         TOOL_QUALIFICATION,
         TOOL_UP,
         TOOL_BUSY,
         FSUI_PRIORITY,
         VALID_TOOL_FLAG,
         RN,
         SNAPSHOT_DATE)
        VALUES
        (
          c_SnapshotRec2.FACILITY,  
          c_SnapshotRec2.LOT,
          c_SnapshotRec2.PRODUCT,
          c_SnapshotRec2.ROUTE,
          c_SnapshotRec2.FLOWPLAN,
          c_SnapshotRec2.FLOW_CONTEXT,
          c_SnapshotRec2.ROUTE_BASE_NAME,
          c_SnapshotRec2.OPERATION,
          c_SnapshotRec2.OPERATION_VERSION,
          c_SnapshotRec2.ENTITY,
          c_SnapshotRec2.OWNER,
          c_SnapshotRec2.LOT_PRIORITY,
          c_SnapshotRec2.HOTLOT,
          c_SnapshotRec2.LOT_STATE,
          c_SnapshotRec2.PROCESS,
          c_SnapshotRec2.DOTPROCESS,
          c_SnapshotRec2.WAFER_QTY,
          c_SnapshotRec2.DELTA_TO_ETA,
          c_SnapshotRec2.ETA,
          c_SnapshotRec2.EXEC_SEQ,
          c_SnapshotRec2.ENTITYOPER_VALID,
          c_SnapshotRec2.TOOL_QUALIFICATION,
          c_SnapshotRec2.TOOL_UP,
          c_SnapshotRec2.TOOL_BUSY,
          c_SnapshotRec2.FSUI_PRIORITY,
          c_SnapshotRec2.VALID_TOOL_FLAG,
          c_SnapshotRec2.RN,
          c_SnapshotRec2.SNAPSHOT_DATE  
         );



         --
         -- Record already exists so do nothing
         --
         EXCEPTION
             WHEN DUP_VAL_ON_INDEX THEN 
               NULL;

                WHEN OTHERS THEN
                   DECLARE
                     v_ERROR_CODE NUMBER := SQLCODE;
                     v_ERROR_MESSAGE VARCHAR2(300) := SQLERRM;
                     v_COMMENTS VARCHAR2(500);

                   BEGIN

                     v_COMMENTS := v_ERROR_CODE || ' - ' || v_ERROR_MESSAGE;
                     SP$LOG_ME(c_PROCEDURE_NAME || ' - Error Loading Snapshot Data' || v_Comments);
                     SP$LOG_METRICS
                     (
                       p_ExtractName => c_PROCEDURE_NAME,
                       p_ExtractStartDate => v_StartTime,
                       p_ExtractEndDate => SYSDATE,
                       p_RunStartDate => v_StartTime,
                       p_RunEndDate => SYSDATE,
                       p_Status => 'FAILURE',
                       p_Comments => v_Comments
                     );
                 END;


         END; --Duplicate Key Exception
        END LOOP;


      COMMIT;  
    -- End: Testing Version of Snapshot History for validation  
      
          
  v_ElapsedTime := ROUND((SYSDATE - v_StartTime) * 24 * 60 *60);

  -- Write to ExtractMetrics
  SP$LOG_METRICS
    (
        p_ExtractName => c_PROCEDURE_NAME,
        p_ExtractStartDate => v_StartTime,
        p_ExtractEndDate => SYSDATE,
        p_RunStartDate => v_StartTime,
        p_RunEndDate => SYSDATE,
        p_RecordsAdded => v_RowsAdded,
        p_Status => 'SUCCESS'
     );

  -- Write to Logfile
   SP$LOG_ME(c_PROCEDURE_NAME || ': Success with ' || TO_CHAR(v_RowsAdded) || ' Rows added in ' || TO_CHAR(v_ElapsedTime) || ' seconds' );

  EXCEPTION
    WHEN OTHERS
    THEN
      DECLARE
         v_ErrorCode NUMBER := SQLCODE;
         v_ErrorMessage VARCHAR2(300) := SQLERRM;
         v_Comments VARCHAR2(500);
      BEGIN

         ROLLBACK;

         v_COMMENTS := SUBSTR(v_ErrorCode || ' - ' || v_ErrorMessage || ' - ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 0, 500);

        SP$LOG_ME(c_PROCEDURE_NAME || ' - Error: '|| v_Comments);
        SP$LOG_METRICS(c_PROCEDURE_NAME, v_StartTime, SYSDATE, v_StartTime, SYSDATE,0 , 0, 'FAILURE', v_Comments);

   END;

END SP$LOT_TOOL_HISTORY;
