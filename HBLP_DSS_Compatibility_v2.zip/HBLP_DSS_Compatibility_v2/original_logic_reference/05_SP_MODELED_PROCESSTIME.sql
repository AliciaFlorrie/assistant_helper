-- REFERENCE ONLY: exact procedure body excerpt; not a standalone SQL script.
PROCEDURE SP$MODELED_PROCESSTIME

IS

  c_PROCEDURE_NAME CONSTANT MC_1_F_EXTRACTMETRICS.EXTRACT_NAME%TYPE := 'SP$MODELED_PROCESSTIME';
  v_RowsAdded NUMBER;
  v_StartTime DATE := SYSDATE;
  v_ElapsedTime NUMBER;
  v_FallbackQueueTime NUMBER; 
  v_FallbackProcessTime NUMBER;
  
BEGIN
        
     v_FallbackQueueTime := FN$GET_META_VALUE('HOTLOT_QUEUE_TIME'); --typically 5 minutes 
     v_FallbackProcessTime := FN$GET_META_VALUE('HOTLOT_CYCLE_TIME') - v_FallbackQueueTime; -- typically 1 hour

    DELETE FROM HBLP_LOT_MODELED_PT;

    INSERT INTO HBLP_LOT_MODELED_PT
      (FACILITY,
       LOT,
       PRODUCT,
       PROCESS,
       OWNER,
       ROUTE,
       WAFERS,
       OPERATION,
       NTSC_ENTITY,
       QUEUED_ENTITY,
       PREVOUT_DATE,
       MOQ_DATE,
       INTRODUCE_TXN_DATE,
       BEGINMOUNT_TXN_DATE,
       ENDMOUNT_TXN_DATE,
       IN_DATE,
       RUN_TXN_DATE,
       FIRST_WAFER_START_TIME,
       LAST_WAFER_END_TIME,
       END_TXN_DATE,
       ABORT_TXN_DATE,
       START_DISMOUNT_TXN_DATE,
       END_DISMOUNT_TXN_DATE,
       OUT_DATE,
       RUNID,
       QUEUEORDER,
       LOTPOSITION,
       LOADPORT_QTY,
       WATERMARK,
       LOCATION,
       LAST_UPDATE_DATE,
       STORED_LOC,
       AVG_INV,
       CURRENT_STEP,
       TIME_IN_CURRENT_STEP,
       RESPONSE_ESTIMATE,
       Q_TO_MNT_ESTIMATE,
       AMHS_ESTIMATE,
       POST_DELIVERY_DELAY,
       RUN_TO_START_ESTIMATE,
       WAFER_PROCESS_ESTIMATE,
       MOVEOUT_DELAY_ESTIMATE,
       RESPONSE_DELAY,
       QUEUE_TO_MOUNT_DELAY,
       AMHS_DELAY,
       POST_DELIVERY_DELAY_TIME,
       RUN_DELAY,
       WAFER_PROCESS_TIME,
       MOVEOUT_DELAY,
       ROUGH_AVG_QT,
       ROUGH_FIT_PT,
       MISSING_DATA,
       QT_INVALID,
       PT_INVALID,
       EFF_RESPONSE_DELAY,
       EFF_QUEUE_TO_MOUNT_DELAY,
       EFF_AMHS_DELAY,
       EFF_POST_DEL_DELAY,
       EFF_RUN_DELAY,
       EFF_PROC_TIME,
       EFF_MOVEOUT_DELAY,
       R0_EST_QT_REMAINING,
       R0_EST_PT_REMAINING,
       R1_EST_QT_REMAINING,
       R1_EST_PT_REMAINING,
       R0_TIME_REMAINING,
       R0A_TIME_REMAINING,
       R1_TIME_REMAINING,
       R2_EST_QT_REMAINING,
       R2_EST_PT_REMAINING,
       R2A_EST_QT_REMAINING,
       R2A_EST_PT_REMAINING,
       R2_TIME_REMAINING,
       R2A_TIME_REMAINING)

    WITH AMHS_STATUS AS
    (SELECT LH2.*
      FROM (SELECT LH.*,
                   MAX(LH.TXNDATE) OVER(PARTITION BY LH.LOT) AS LATEST_TXN
            FROM MC_1_F_MCS_LOTHIST  LH,
                 HBLP_FLOW_CONTEXT_S FC
            WHERE FC.LOT = LH.LOT
            AND EVENTTYPE = 'STRC') LH2
      WHERE LH2.TXNDATE = LH2.LATEST_TXN)
      
      

    SELECT LS7.*,
           R2_EST_QT_REMAINING + R2_EST_PT_REMAINING AS R2_TIME_REMAINING,
           R2A_EST_QT_REMAINING + R2A_EST_PT_REMAINING AS R2A_TIME_REMAINING
    FROM (
    SELECT LS6.*,
           
           -- R0 CALC
          CASE
            WHEN (ROUGH_AVG_QT + ROUGH_FIT_PT - (SYSDATE - PREVOUT_DATE) * 24* 60 ) < 0 THEN 0
            ELSE  ROUGH_AVG_QT + ROUGH_FIT_PT - (SYSDATE - PREVOUT_DATE) * 24* 60
          END AS R0_TIME_REMAINING,

          -- R0A Calc
           R0_EST_QT_REMAINING + R0_EST_PT_REMAINING AS R0A_TIME_REMAINING,

           -- R1 Calc (using R0A estimates if invalid values present)         
           R1_EST_QT_REMAINING + R1_EST_PT_REMAINING AS R1_TIME_REMAINING,
           
           -- R2 Cal
           CASE
             WHEN R1_EST_QT_REMAINING - R0_EST_QT_REMAINING > 150
             -- geometric mean
               THEN R0_EST_QT_REMAINING
             WHEN R0_EST_QT_REMAINING - R1_EST_QT_REMAINING > 150
             -- geometric mean
               THEN R1_EST_QT_REMAINING
             WHEN ABS(R0_EST_QT_REMAINING - R1_EST_QT_REMAINING) / (R0_EST_QT_REMAINING + 1) > 0.1 
               OR ABS(R0_EST_QT_REMAINING - R1_EST_QT_REMAINING) > 90
             -- geometric mean
             THEN (R0_EST_QT_REMAINING + R1_EST_QT_REMAINING)/ 2
             ELSE R1_EST_QT_REMAINING
           END AS R2_EST_QT_REMAINING,
           CASE
             WHEN R1_EST_PT_REMAINING - R0_EST_PT_REMAINING > 150
               -- geometric mean
             THEN R0_EST_PT_REMAINING
             WHEN R0_EST_PT_REMAINING - R1_EST_PT_REMAINING > 150
               -- geometric mean
             THEN R1_EST_PT_REMAINING
             WHEN ABS(R0_EST_PT_REMAINING - R1_EST_PT_REMAINING) / (R0_EST_PT_REMAINING + 1) > 0.1 
               OR ABS(R0_EST_PT_REMAINING - R1_EST_PT_REMAINING) > 90
               -- geometric mean
             THEN (R0_EST_PT_REMAINING + R1_EST_PT_REMAINING)/ 2 
             ELSE R1_EST_PT_REMAINING
           END AS R2_EST_PT_REMAINING,
           
           -- NEW R2 calcs!
           CASE
             -- response calcluations
             WHEN CURRENT_STEP = 'RESPONSE' THEN
               CASE
                 -- use the lesser one if they differe significantly
                  WHEN R1_EST_QT_REMAINING - R0_EST_QT_REMAINING > 150 THEN R0_EST_QT_REMAINING
                  WHEN R0_EST_QT_REMAINING - R1_EST_QT_REMAINING > 150 THEN R1_EST_QT_REMAINING
                  -- if R0 = 0, then use R1 (some R0s run 0 for a long time)
                  WHEN R0_EST_QT_REMAINING = 0 THEN R1_EST_QT_REMAINING
                  -- else use an average of the two
                  ELSE (R0_EST_QT_REMAINING + R1_EST_QT_REMAINING) / 2
               END
               
               -- QUEUE TO MOUNT CALCS
             WHEN CURRENT_STEP = 'QUEUE TO MNT' THEN POWER(ABS((R0_EST_QT_REMAINING + 1) * (R1_EST_QT_REMAINING + 1)),0.5) --R1_EST_QT_REMAINING
             
             -- AMHS_RETRIEVAL CALCS        
             WHEN CURRENT_STEP = 'AMHS_RETRIEVAL' THEN
                CASE
                 -- use R1 if R0 is a flier
                  WHEN R0_EST_QT_REMAINING - R1_EST_QT_REMAINING > 150 THEN R1_EST_QT_REMAINING
                  -- else geometric mean is a winner!
                  ELSE POWER(ABS(R0_EST_QT_REMAINING * R1_EST_QT_REMAINING),0.5)
                END
             WHEN CURRENT_STEP = 'POST_DELIVERY_DELAY' THEN 0
             WHEN CURRENT_STEP = 'RUN TO START' THEN 0
             WHEN CURRENT_STEP = 'WAFER PROCESS' THEN  0 
             WHEN CURRENT_STEP = 'MOVEOUT DELAY' THEN 0
           END AS R2A_EST_QT_REMAINING,   


           CASE
           -- Response regime, longest prediction window  
           
             WHEN CURRENT_STEP = 'RESPONSE' THEN
               -- GENERIC LONG PREDICTION WINDOW
               CASE
                 WHEN (R0_EST_PT_REMAINING = 0 OR R1_EST_PT_REMAINING = 0) THEN 0 
                 WHEN (R1_EST_PT_REMAINING - R0_EST_PT_REMAINING > 150) AND (R0_EST_PT_REMAINING / R1_EST_PT_REMAINING > 0.01) THEN R0_EST_PT_REMAINING
                 WHEN (R0_EST_PT_REMAINING - R1_EST_PT_REMAINING > 150) AND (R1_EST_PT_REMAINING / R0_EST_PT_REMAINING > 0.01) THEN R1_EST_PT_REMAINING
                 WHEN ABS(R0_EST_PT_REMAINING - R1_EST_PT_REMAINING) / (R0_EST_PT_REMAINING + 1) > 0.1 
                      OR ABS(R0_EST_PT_REMAINING - R1_EST_PT_REMAINING) > 90  THEN (R0_EST_PT_REMAINING + R1_EST_PT_REMAINING)/ 2
                 ELSE R1_EST_PT_REMAINING
               END  
             
             -- QUEUE TO MOUNT 
             WHEN CURRENT_STEP = 'QUEUE TO MNT' THEN
               -- GENERIC LONG PREDICTION WINDOW
               CASE
                 WHEN (R0_EST_PT_REMAINING = 0 OR R1_EST_PT_REMAINING = 0) THEN 0 
                 WHEN (R1_EST_PT_REMAINING - R0_EST_PT_REMAINING > 150) AND (R0_EST_PT_REMAINING / R1_EST_PT_REMAINING > 0.01) THEN R0_EST_PT_REMAINING
                 WHEN (R0_EST_PT_REMAINING - R1_EST_PT_REMAINING > 150) AND (R1_EST_PT_REMAINING / R0_EST_PT_REMAINING > 0.01) THEN R1_EST_PT_REMAINING
                 WHEN ABS(R0_EST_PT_REMAINING - R1_EST_PT_REMAINING) / (R0_EST_PT_REMAINING + 1) > 0.1 
                      OR ABS(R0_EST_PT_REMAINING - R1_EST_PT_REMAINING) > 90  THEN (R0_EST_PT_REMAINING + R1_EST_PT_REMAINING)/ 2
                 ELSE R1_EST_PT_REMAINING
               END    
             
             -- AMHS RETRIEVAL
             WHEN CURRENT_STEP = 'AMHS_RETRIEVAL' THEN
               -- GENERIC LONG PREDICTION WINDOW 
               CASE
                 WHEN (R0_EST_PT_REMAINING = 0 OR R1_EST_PT_REMAINING = 0) THEN 0 
                 WHEN (R1_EST_PT_REMAINING - R0_EST_PT_REMAINING > 150) AND (R0_EST_PT_REMAINING / R1_EST_PT_REMAINING > 0.01) THEN R0_EST_PT_REMAINING
                 WHEN (R0_EST_PT_REMAINING - R1_EST_PT_REMAINING > 150) AND (R1_EST_PT_REMAINING / R0_EST_PT_REMAINING > 0.01) THEN R1_EST_PT_REMAINING
                 WHEN ABS(R0_EST_PT_REMAINING - R1_EST_PT_REMAINING) / (R0_EST_PT_REMAINING + 1) > 0.1 
                      OR ABS(R0_EST_PT_REMAINING - R1_EST_PT_REMAINING) > 90  THEN (R0_EST_PT_REMAINING + R1_EST_PT_REMAINING)/ 2
                 ELSE R1_EST_PT_REMAINING
               END   
             
             -- POST DELIVERY DELAY
             WHEN CURRENT_STEP = 'POST_DELIVERY_DELAY' THEN
             -- GENERIC LONG PREDICTION WINDOW 
               CASE
                 WHEN (R0_EST_PT_REMAINING = 0 OR R1_EST_PT_REMAINING = 0) THEN 0 
                 WHEN (R1_EST_PT_REMAINING - R0_EST_PT_REMAINING > 150) AND (R0_EST_PT_REMAINING / R1_EST_PT_REMAINING > 0.01) THEN R0_EST_PT_REMAINING
                 WHEN (R0_EST_PT_REMAINING - R1_EST_PT_REMAINING > 150) AND (R1_EST_PT_REMAINING / R0_EST_PT_REMAINING > 0.01) THEN R1_EST_PT_REMAINING
                 WHEN ABS(R0_EST_PT_REMAINING - R1_EST_PT_REMAINING) / (R0_EST_PT_REMAINING + 1) > 0.1 
                      OR ABS(R0_EST_PT_REMAINING - R1_EST_PT_REMAINING) > 90  THEN (R0_EST_PT_REMAINING + R1_EST_PT_REMAINING)/ 2
                 ELSE R1_EST_PT_REMAINING
               END   
               
             
             -- RUN TO START DELAY
             WHEN CURRENT_STEP = 'RUN TO START' THEN
             -- GENERIC LONG PREDICTION WINDOW 
               CASE
                 WHEN (R0_EST_PT_REMAINING = 0 OR R1_EST_PT_REMAINING = 0) THEN 0 
                 WHEN (R1_EST_PT_REMAINING - R0_EST_PT_REMAINING > 150) AND (R0_EST_PT_REMAINING / R1_EST_PT_REMAINING > 0.1) THEN R0_EST_PT_REMAINING
                 WHEN (R0_EST_PT_REMAINING - R1_EST_PT_REMAINING > 150) AND (R1_EST_PT_REMAINING / R0_EST_PT_REMAINING > 0.1) THEN R1_EST_PT_REMAINING
                 WHEN ABS(R0_EST_PT_REMAINING - R1_EST_PT_REMAINING) / (R0_EST_PT_REMAINING + 1) > 0.1 
                      OR ABS(R0_EST_PT_REMAINING - R1_EST_PT_REMAINING) > 90  THEN (R0_EST_PT_REMAINING + R1_EST_PT_REMAINING)/ 2
                 ELSE R1_EST_PT_REMAINING
               END   

             -- WAFER PROCESS         
             WHEN CURRENT_STEP = 'WAFER PROCESS' THEN  
               -- GENERIC LONG PREDICTION WINDOW 
               CASE
                 WHEN (R0_EST_PT_REMAINING = 0 OR R1_EST_PT_REMAINING = 0) THEN 0 
                 WHEN (R1_EST_PT_REMAINING - R0_EST_PT_REMAINING > 150) AND (R0_EST_PT_REMAINING / R1_EST_PT_REMAINING > 0.05) THEN R0_EST_PT_REMAINING
                 WHEN (R0_EST_PT_REMAINING - R1_EST_PT_REMAINING > 150) AND (R1_EST_PT_REMAINING / R0_EST_PT_REMAINING > 0.05) THEN R1_EST_PT_REMAINING
                 ELSE R1_EST_PT_REMAINING
               END   
             -- MOVEOUT DELAY
             WHEN CURRENT_STEP = 'MOVEOUT DELAY' THEN  R1_EST_PT_REMAINING
           END AS R2A_EST_PT_REMAINING
    FROM (
    SELECT LS5.*,    
           CASE
             WHEN QT_INVALID = 'Y' THEN R0_EST_QT_REMAINING
             ELSE EFF_RESPONSE_DELAY + EFF_QUEUE_TO_MOUNT_DELAY + EFF_AMHS_DELAY 
           END as R1_EST_QT_REMAINING,
             
           CASE
             WHEN PT_INVALID = 'Y' THEN R0_EST_PT_REMAINING
             ELSE EFF_POST_DEL_DELAY + EFF_RUN_DELAY + EFF_PROC_TIME + EFF_MOVEOUT_DELAY
           END as R1_EST_PT_REMAINING
             
    FROM (SELECT LS4.*,
                 -- MISSING DATA COUNT
                 CASE
                   WHEN RESPONSE_DELAY = -100 THEN 1
                   ELSE 0
                 END + CASE
                   WHEN QUEUE_TO_MOUNT_DELAY = -100 THEN 1
                   ELSE 0
                 END + CASE
                   WHEN AMHS_DELAY = -100 THEN 1
                   ELSE 0
                 END + CASE
                   WHEN POST_DELIVERY_DELAY_TIME = -100 THEN 1
                   ELSE 0
                 END + CASE
                   WHEN RUN_DELAY = -100 THEN 1
                   ELSE 0
                 END + CASE
                   WHEN WAFER_PROCESS_TIME = -100 THEN 1
                   ELSE 0
                 END + CASE
                   WHEN MOVEOUT_DELAY = -100 THEN 1
                   ELSE 0
                 END AS MISSING_DATA,
                 -- Identify Invalid REGIONS
                 CASE
                   WHEN RESPONSE_DELAY = -100 OR QUEUE_TO_MOUNT_DELAY = -100 OR AMHS_DELAY = -100 THEN 'Y'
                   ELSE 'N'
                 END AS QT_INVALID,
                 CASE
                   WHEN RUN_DELAY = -100 OR WAFER_PROCESS_TIME = -100 OR MOVEOUT_DELAY = -100 OR
                        POST_DELIVERY_DELAY_TIME = -100 THEN 'Y' 
                   ELSE 'N'
                 END AS PT_INVALID,
                 CASE
                   WHEN RESPONSE_ESTIMATE IS NULL THEN 0
                   WHEN RESPONSE_DELAY < 0 THEN 0
                   WHEN CURRENT_STEP = 'RESPONSE' AND (RESPONSE_DELAY - TIME_IN_CURRENT_STEP) > 0 THEN RESPONSE_DELAY - TIME_IN_CURRENT_STEP
                   WHEN CURRENT_STEP = 'RESPONSE' AND (RESPONSE_DELAY - TIME_IN_CURRENT_STEP) < 0 THEN 0
                   ELSE RESPONSE_DELAY
                 END AS EFF_RESPONSE_DELAY,
                 CASE
                   WHEN Q_TO_MNT_ESTIMATE IS NULL THEN 0
                   WHEN QUEUE_TO_MOUNT_DELAY < 0 THEN 0
                   WHEN CURRENT_STEP = 'QUEUE TO MNT' AND (QUEUE_TO_MOUNT_DELAY - TIME_IN_CURRENT_STEP) > 0 THEN QUEUE_TO_MOUNT_DELAY - TIME_IN_CURRENT_STEP
                   WHEN CURRENT_STEP = 'QUEUE TO MNT' AND (QUEUE_TO_MOUNT_DELAY - TIME_IN_CURRENT_STEP) < 0 THEN 0
                   ELSE QUEUE_TO_MOUNT_DELAY
                 END AS EFF_QUEUE_TO_MOUNT_DELAY,
                 CASE
                   WHEN AMHS_ESTIMATE IS NULL THEN 0
                   WHEN AMHS_DELAY < 0 THEN 0
                   WHEN CURRENT_STEP = 'AMHS_RETRIEVAL' AND (AMHS_DELAY - TIME_IN_CURRENT_STEP) > 0 THEN AMHS_DELAY - TIME_IN_CURRENT_STEP
                   WHEN CURRENT_STEP = 'AMHS_RETRIEVAL' AND (AMHS_DELAY - TIME_IN_CURRENT_STEP) < 0 THEN 0
                   ELSE AMHS_DELAY
                 END AS EFF_AMHS_DELAY,
                 CASE
                   WHEN POST_DELIVERY_DELAY IS NULL THEN 0
                   WHEN POST_DELIVERY_DELAY_TIME < 0 THEN 0
                   WHEN CURRENT_STEP = 'POST_DELIVERY_DELAY' AND (POST_DELIVERY_DELAY_TIME - TIME_IN_CURRENT_STEP) > 0 THEN POST_DELIVERY_DELAY_TIME - TIME_IN_CURRENT_STEP
                   WHEN CURRENT_STEP = 'POST_DELIVERY_DELAY' AND (POST_DELIVERY_DELAY_TIME - TIME_IN_CURRENT_STEP) < 0 THEN 0
                   ELSE POST_DELIVERY_DELAY_TIME
                 END AS EFF_POST_DEL_DELAY,
                 
                 -- RUN DELAY
                 CASE
                   WHEN RUN_TO_START_ESTIMATE IS NULL THEN
                    0
                   WHEN RUN_DELAY < 0 THEN
                    0 
                   WHEN CURRENT_STEP = 'RUN TO START' AND (RUN_DELAY - TIME_IN_CURRENT_STEP) > 0 THEN
                    RUN_DELAY - TIME_IN_CURRENT_STEP
                   WHEN CURRENT_STEP = 'RUN TO START' AND (RUN_DELAY - TIME_IN_CURRENT_STEP) < 0 THEN
                    0
                   WHEN CURRENT_STEP = 'POST_DELIVERY_DELAY' AND (TIME_IN_CURRENT_STEP - POST_DELIVERY_DELAY_TIME) > 0 
                     AND RUN_DELAY - (TIME_IN_CURRENT_STEP - POST_DELIVERY_DELAY_TIME) > 0 THEN RUN_DELAY - (TIME_IN_CURRENT_STEP - POST_DELIVERY_DELAY_TIME)
                   WHEN CURRENT_STEP = 'POST_DELIVERY_DELAY' AND (TIME_IN_CURRENT_STEP - POST_DELIVERY_DELAY_TIME) > 0 
                     AND RUN_DELAY - (TIME_IN_CURRENT_STEP - POST_DELIVERY_DELAY_TIME) < 0 THEN 0
                   
                   ELSE
                    RUN_DELAY
                    
                    
                 END AS EFF_RUN_DELAY,
                 CASE
                   WHEN WAFER_PROCESS_ESTIMATE IS NULL THEN
                    0
                   WHEN WAFER_PROCESS_TIME < 0 THEN 0
                   WHEN CURRENT_STEP = 'WAFER PROCESS' AND (WAFER_PROCESS_TIME - TIME_IN_CURRENT_STEP) > 0 THEN
                    WAFER_PROCESS_TIME - TIME_IN_CURRENT_STEP
                   WHEN CURRENT_STEP = 'WAFER PROCESS' AND (WAFER_PROCESS_TIME - TIME_IN_CURRENT_STEP) < 0 THEN
                    0
                   ELSE
                    WAFER_PROCESS_TIME
                 END AS EFF_PROC_TIME,
                 CASE
                   WHEN MOVEOUT_DELAY_ESTIMATE IS NULL THEN
                    0
                   WHEN MOVEOUT_DELAY < 0 THEN 0
                   WHEN CURRENT_STEP = 'MOVEOUT DELAY' AND (MOVEOUT_DELAY - TIME_IN_CURRENT_STEP) > 0 THEN
                    MOVEOUT_DELAY - TIME_IN_CURRENT_STEP
                   WHEN CURRENT_STEP = 'MOVEOUT DELAY' AND (MOVEOUT_DELAY - TIME_IN_CURRENT_STEP) < 0 THEN
                    0
                   ELSE
                    MOVEOUT_DELAY
                 END AS EFF_MOVEOUT_DELAY,
                 CASE
                 -- if the current time is already to long, will be 0
                   WHEN ROUGH_AVG_QT - (SYSDATE - PREVOUT_DATE) * 24* 60 < 0 THEN
                    0
                   WHEN CURRENT_STEP IN ('RESPONSE', 'QUEUE TO MNT', 'AMHS_RETRIEVAL') THEN
                    ROUGH_AVG_QT - (SYSDATE - PREVOUT_DATE) * 24* 60
                 -- alreayd past the QT portion of the operation
                   ELSE
                    0
                 END AS R0_EST_QT_REMAINING,
                 -- USE RUN as replacement for 'IN_DATE' if null
                 CASE
                   WHEN CURRENT_STEP IN ('POST_DELIVERY_DELAY', 'RUN TO START', 'WAFER PROCESS', 'MOVEOUT DELAY') AND IN_DATE IS NOT NULL AND
                        ROUGH_FIT_PT - (SYSDATE - IN_DATE) * 24* 60 < 0 THEN
                    0
                   WHEN CURRENT_STEP IN ('POST_DELIVERY_DELAY', 'RUN TO START', 'WAFER PROCESS', 'MOVEOUT DELAY') AND IN_DATE IS NOT NULL THEN
                    ROUGH_FIT_PT - (SYSDATE - IN_DATE) * 24 * 60
                   WHEN CURRENT_STEP IN ('POST_DELIVERY_DELAY', 'RUN TO START', 'WAFER PROCESS', 'MOVEOUT DELAY') AND RUN_TXN_DATE IS NOT NULL AND
                        ROUGH_FIT_PT - (SYSDATE - RUN_TXN_DATE)  * 24* 60 < 0 THEN
                    0
                   WHEN CURRENT_STEP IN ('POST_DELIVERY_DELAY', 'RUN TO START', 'WAFER PROCESS', 'MOVEOUT DELAY') AND RUN_TXN_DATE IS NOT NULL THEN
                    ROUGH_FIT_PT - (SYSDATE - RUN_TXN_DATE) * 24* 60
                   ELSE
                    ROUGH_FIT_PT
                 END AS R0_EST_PT_REMAINING
                 
          FROM (SELECT LS3.*
                 FROM (SELECT LS2.*,
                               -- Response Delay
                               -- explicit operation lookup, fails when operation is not in ref table
                               CASE
                                 WHEN D1.OPERATION IS NULL OR D1.DELAY_OVERHEAD IS NULL OR D1.DELAY_PER_UNIT IS NULL THEN
                                  -100
                                 WHEN AVG_INV IS NULL THEN
                                  0
                                 ELSE
                                  D1.DELAY_OVERHEAD + D1.DELAY_PER_UNIT * LS2.AVG_INV
                               END AS RESPONSE_DELAY,
                               -- Queue to mount delay
                               -- tries to match by toolset
                               -- if toolset is not known yet or not in table, then use generic oper lookup
                               CASE
                                 WHEN LS2.QUEUEORDER IS NULL AND D2A.DELAY_OVERHEAD IS NULL THEN
                                  -100
                                 WHEN LS2.QUEUEORDER IS NULL THEN
                                  D2A.DELAY_OVERHEAD
                                 WHEN D2.DELAY_OVERHEAD IS NULL AND D2A.DELAY_OVERHEAD IS NULL THEN
                                  -100
                                 WHEN D2.DELAY_OVERHEAD IS NULL THEN
                                  D2A.DELAY_OVERHEAD
                                 WHEN D2.WATERMARK_TYPE = 'OVER' THEN
                                  D2.DELAY_OVERHEAD + D2.DELAY_PER_UNIT * (LS2.QUEUEORDER - LS2.LOADPORT_QTY)
                                 WHEN D2.WATERMARK_TYPE = 'UNDER' THEN
                                  D2.DELAY_OVERHEAD + D2.DELAY_PER_UNIT * LS2.QUEUEORDER
                                 ELSE
                                  -100
                               END AS QUEUE_TO_MOUNT_DELAY,
                               -- AMHS DELAY
                               -- D3 is op only
                               -- D4 is from stocker to tool, precise match
                               CASE
                                 WHEN (STORED_LOC IS NULL OR QUEUED_ENTITY IS NULL OR D4.AVG_DELIVERY_TIME IS NULL) AND
                                      D3.AVG_DELIVERY_TIME IS NULL THEN
                                  -100
                                 WHEN (STORED_LOC IS NULL OR QUEUED_ENTITY IS NULL OR D4.AVG_DELIVERY_TIME IS NULL) THEN
                                  D3.AVG_DELIVERY_TIME
                                 WHEN D4.AVG_DELIVERY_TIME IS NULL THEN
                                  -100
                                 ELSE
                                  D4.AVG_DELIVERY_TIME
                               END AS AMHS_DELAY,
                               -- POST Delivery Delay Time (from delivery to RUN)
                               -- if cannot find the TOOLSET + OP info, then use just global op average
                               CASE
                                 WHEN D5.DATASOURCE IS NULL AND D5A.DATASOURCE IS NULL THEN
                                  -100
                                 WHEN D5.DATASOURCE IS NULL THEN
                                  D5A.DELAY_OVERHEAD
                                 WHEN D5.DATASOURCE = 'TOOLSET_HIST' THEN
                                  D5.DELAY_OVERHEAD
                                 WHEN D5.DATASOURCE = 'OPERATION_HIST' THEN
                                  D5.DELAY_OVERHEAD
                                 WHEN D5.DATASOURCE = 'OPER LOTPOSITION' THEN
                                  D5.DELAY_OVERHEAD + D5.DELAY_SLOPE * LS2.LOTPOSITION
                                 WHEN D5.DATASOURCE = 'OPER QUEUEORDER' THEN
                                  D5.DELAY_OVERHEAD + D5.DELAY_SLOPE * LS2.QUEUEORDER
                                 ELSE
                                  0
                               END AS POST_DELIVERY_DELAY_TIME,
                               -- Run Delay
                               -- From Run to wafer start
                               -- if no toolset match OR no Queue order, the use op average
                               CASE
                                 WHEN D6.DELAY_PER_UNIT IS NULL AND D6A.DELAY_OVERHEAD IS NULL THEN
                                  -100
                                 WHEN D6.DELAY_PER_UNIT IS NULL THEN
                                  D6A.DELAY_OVERHEAD
                                 WHEN LS2.QUEUEORDER IS NOT NULL THEN
                                  LS2.QUEUEORDER * D6.DELAY_PER_UNIT + D6.DELAY_OVERHEAD
                                 WHEN LS2.QUEUEORDER IS NULL THEN
                                  D6A.DELAY_OVERHEAD
                                 ELSE
                                  0
                               END AS RUN_DELAY,
                               -- Wafer Process Time
                               -- try to use the specific toolset one, if not the use oper avg
                               CASE
                                 WHEN D7.DELAY_PER_UNIT IS NULL AND D7A.DELAY_PER_UNIT IS NULL THEN
                                  -100
                                 WHEN D7.DELAY_PER_UNIT IS NULL THEN
                                  D7A.DELAY_PER_UNIT * LS2.WAFERS + D7A.DELAY_OVERHEAD
                                 ELSE
                                  D7.DELAY_PER_UNIT * LS2.WAFERS + D7.DELAY_OVERHEAD
                               END AS WAFER_PROCESS_TIME,
                               -- Moveout Delay
                               CASE
                                 WHEN D8.AVG_DELAY IS NULL AND D8A.AVG_DELAY IS NULL THEN
                                  -100
                                 WHEN LS2.QUEUED_ENTITY IS NULL AND D8A.AVG_DELAY IS NULL THEN
                                  -100
                                 WHEN LS2.QUEUED_ENTITY IS NULL THEN
                                  D8A.AVG_DELAY
                                 WHEN D8.AVG_DELAY IS NULL THEN
                                  D8A.AVG_DELAY
                                 ELSE
                                  D8.AVG_DELAY
                               END AS MOVEOUT_DELAY,
                               -- Global AVG Values
                               --QT.AVG_QUEUE_TIME_MINS AS ROUGH_AVG_QT,
                               CASE
                                 WHEN QT.AVG_QUEUE_TIME_MINS IS NOT NULL THEN QT.AVG_QUEUE_TIME_MINS
                                 WHEN CT.QTG_DAYS IS NOT NULL THEN CT.QTG_DAYS * 24 * 60
                                 WHEN POU.PLAN_QUEUE_TIME IS NOT NULL THEN POU.PLAN_QUEUE_TIME * 24 * 60 
                                 ELSE v_FallbackQueueTime
                               END AS ROUGH_AVG_QT,
                               
                               --PT.OVERHEAD_TIME * 24 * 60 + PT.TIME_PER_WAFER * LS2.WAFERS * 24 * 60 AS ROUGH_FIT_PT
                               
                               CASE
                                 WHEN (PT.OVERHEAD_TIME * 24 * 60 + PT.TIME_PER_WAFER * LS2.WAFERS * 24 * 60) IS NOT NULL THEN PT.OVERHEAD_TIME * 24 * 60 + PT.TIME_PER_WAFER * LS2.WAFERS * 24 * 60
                                 WHEN CT.PTG_DAYS IS NOT NULL THEN CT.PTG_DAYS * 24 * 60
                                 WHEN (POU.PLAN_CYCLE_TIME - POU.PLAN_QUEUE_TIME) IS NOT NULL THEN (POU.PLAN_CYCLE_TIME - POU.PLAN_QUEUE_TIME) * 24 * 60 
                                 ELSE v_FallbackProcessTime
                               END AS ROUGH_FIT_PT 
                               
                        FROM (SELECT LS.*,
                                      AMHS.LOCATION AS STORED_LOC,
                                      INV.AVG_INV,
                                      CASE
                                        WHEN MOQ_DATE IS NULL AND INTRODUCE_TXN_DATE IS NULL AND BEGINMOUNT_TXN_DATE IS NULL AND
                                             ENDMOUNT_TXN_DATE IS NULL AND IN_DATE IS NULL AND RUN_TXN_DATE IS NULL AND
                                             FIRST_WAFER_START_TIME IS NULL AND LAST_WAFER_END_TIME IS NULL AND
                                             END_TXN_DATE IS NULL AND ABORT_TXN_DATE IS NULL AND START_DISMOUNT_TXN_DATE IS NULL AND
                                             END_DISMOUNT_TXN_DATE IS NULL THEN
                                         'RESPONSE'
                                        WHEN BEGINMOUNT_TXN_DATE IS NULL AND ENDMOUNT_TXN_DATE IS NULL AND IN_DATE IS NULL AND
                                             RUN_TXN_DATE IS NULL AND FIRST_WAFER_START_TIME IS NULL AND
                                             LAST_WAFER_END_TIME IS NULL AND END_TXN_DATE IS NULL AND ABORT_TXN_DATE IS NULL AND
                                             START_DISMOUNT_TXN_DATE IS NULL AND END_DISMOUNT_TXN_DATE IS NULL THEN
                                         'QUEUE TO MNT'
                                        WHEN ENDMOUNT_TXN_DATE IS NULL AND IN_DATE IS NULL AND RUN_TXN_DATE IS NULL AND
                                             FIRST_WAFER_START_TIME IS NULL AND LAST_WAFER_END_TIME IS NULL AND
                                             END_TXN_DATE IS NULL AND ABORT_TXN_DATE IS NULL AND START_DISMOUNT_TXN_DATE IS NULL AND
                                             END_DISMOUNT_TXN_DATE IS NULL THEN
                                         'AMHS_RETRIEVAL'
                                        WHEN RUN_TXN_DATE IS NULL AND FIRST_WAFER_START_TIME IS NULL AND
                                             LAST_WAFER_END_TIME IS NULL AND END_TXN_DATE IS NULL AND ABORT_TXN_DATE IS NULL AND
                                             START_DISMOUNT_TXN_DATE IS NULL AND END_DISMOUNT_TXN_DATE IS NULL THEN
                                         'POST_DELIVERY_DELAY'
                                        WHEN FIRST_WAFER_START_TIME IS NULL AND LAST_WAFER_END_TIME IS NULL AND
                                             END_TXN_DATE IS NULL AND ABORT_TXN_DATE IS NULL AND START_DISMOUNT_TXN_DATE IS NULL AND
                                             END_DISMOUNT_TXN_DATE IS NULL THEN
                                         'RUN TO START'
                                        WHEN LAST_WAFER_END_TIME IS NULL AND END_TXN_DATE IS NULL AND ABORT_TXN_DATE IS NULL AND
                                             START_DISMOUNT_TXN_DATE IS NULL AND END_DISMOUNT_TXN_DATE IS NULL THEN
                                         'WAFER PROCESS'
                                        WHEN END_TXN_DATE IS NULL AND ABORT_TXN_DATE IS NULL AND START_DISMOUNT_TXN_DATE IS NULL AND
                                             END_DISMOUNT_TXN_DATE IS NULL THEN
                                         'MOVEOUT DELAY'
                                      -- fallback is moveout delay
                                        ELSE
                                         'MOVEOUT DELAY'
                                      END AS CURRENT_STEP,
                                      
                                      -- time in current step (need to account for NTSC lag)
                                      CASE
                                        WHEN MOQ_DATE IS NULL AND INTRODUCE_TXN_DATE IS NULL AND BEGINMOUNT_TXN_DATE IS NULL AND
                                             ENDMOUNT_TXN_DATE IS NULL AND IN_DATE IS NULL AND RUN_TXN_DATE IS NULL AND
                                             FIRST_WAFER_START_TIME IS NULL AND LAST_WAFER_END_TIME IS NULL AND
                                             END_TXN_DATE IS NULL AND ABORT_TXN_DATE IS NULL AND START_DISMOUNT_TXN_DATE IS NULL AND
                                             END_DISMOUNT_TXN_DATE IS NULL THEN
                                         (SYSDATE - PREVOUT_DATE) * 24 * 60
                                        WHEN BEGINMOUNT_TXN_DATE IS NULL AND ENDMOUNT_TXN_DATE IS NULL AND IN_DATE IS NULL AND
                                             RUN_TXN_DATE IS NULL AND FIRST_WAFER_START_TIME IS NULL AND
                                             LAST_WAFER_END_TIME IS NULL AND END_TXN_DATE IS NULL AND ABORT_TXN_DATE IS NULL AND
                                             START_DISMOUNT_TXN_DATE IS NULL AND END_DISMOUNT_TXN_DATE IS NULL THEN
                                         (SYSDATE - MOQ_DATE) * 24 * 60
                                        WHEN ENDMOUNT_TXN_DATE IS NULL AND IN_DATE IS NULL AND RUN_TXN_DATE IS NULL AND
                                             FIRST_WAFER_START_TIME IS NULL AND LAST_WAFER_END_TIME IS NULL AND
                                             END_TXN_DATE IS NULL AND ABORT_TXN_DATE IS NULL AND START_DISMOUNT_TXN_DATE IS NULL AND
                                             END_DISMOUNT_TXN_DATE IS NULL THEN
                                         (SYSDATE - BEGINMOUNT_TXN_DATE) * 24 * 60
                                        -- POST_DELIVERY DELAY
                                        -- CASE 1: NO endmount state
                                        WHEN ENDMOUNT_TXN_DATE IS NULL AND RUN_TXN_DATE IS NULL AND FIRST_WAFER_START_TIME IS NULL AND
                                             LAST_WAFER_END_TIME IS NULL AND END_TXN_DATE IS NULL AND ABORT_TXN_DATE IS NULL AND
                                             START_DISMOUNT_TXN_DATE IS NULL AND END_DISMOUNT_TXN_DATE IS NULL THEN
                                         (SYSDATE - IN_DATE) * 24 * 60
                                        
                                        -- CASE 2: ALL preceding states exist
                                        WHEN RUN_TXN_DATE IS NULL AND FIRST_WAFER_START_TIME IS NULL AND
                                             LAST_WAFER_END_TIME IS NULL AND END_TXN_DATE IS NULL AND ABORT_TXN_DATE IS NULL AND
                                             START_DISMOUNT_TXN_DATE IS NULL AND END_DISMOUNT_TXN_DATE IS NULL THEN
                                         (SYSDATE - ENDMOUNT_TXN_DATE) * 24 * 60
                                         
                                        WHEN FIRST_WAFER_START_TIME IS NULL AND LAST_WAFER_END_TIME IS NULL AND
                                             END_TXN_DATE IS NULL AND ABORT_TXN_DATE IS NULL AND START_DISMOUNT_TXN_DATE IS NULL AND
                                             END_DISMOUNT_TXN_DATE IS NULL THEN
                                         (SYSDATE - RUN_TXN_DATE) * 24 * 60
                                        WHEN LAST_WAFER_END_TIME IS NULL AND END_TXN_DATE IS NULL AND ABORT_TXN_DATE IS NULL AND
                                             START_DISMOUNT_TXN_DATE IS NULL AND END_DISMOUNT_TXN_DATE IS NULL THEN
                                         (SYSDATE - FIRST_WAFER_START_TIME) * 24 * 60
                                        WHEN END_TXN_DATE IS NULL AND ABORT_TXN_DATE IS NULL AND START_DISMOUNT_TXN_DATE IS NULL AND
                                             END_DISMOUNT_TXN_DATE IS NULL THEN
                                         (SYSDATE - LAST_WAFER_END_TIME) * 24 * 60
                                      -- fallback is moveout delay
                                        WHEN LAST_WAFER_END_TIME IS NULL THEN (SYSDATE - END_TXN_DATE) * 24 * 60                                          
                                        ELSE
                                         (SYSDATE - LAST_WAFER_END_TIME) * 24 * 60
                                      END AS TIME_IN_CURRENT_STEP,
                                      
                                      CASE
                                        WHEN MOQ_DATE IS NULL AND INTRODUCE_TXN_DATE IS NULL AND BEGINMOUNT_TXN_DATE IS NULL AND
                                             ENDMOUNT_TXN_DATE IS NULL AND IN_DATE IS NULL AND RUN_TXN_DATE IS NULL AND
                                             FIRST_WAFER_START_TIME IS NULL AND LAST_WAFER_END_TIME IS NULL AND
                                             END_TXN_DATE IS NULL AND ABORT_TXN_DATE IS NULL AND START_DISMOUNT_TXN_DATE IS NULL AND
                                             END_DISMOUNT_TXN_DATE IS NULL THEN
                                         'RESPONSE'
                                        ELSE
                                         NULL
                                      END AS RESPONSE_ESTIMATE,
                                      CASE
                                        WHEN BEGINMOUNT_TXN_DATE IS NULL AND ENDMOUNT_TXN_DATE IS NULL AND IN_DATE IS NULL AND
                                             RUN_TXN_DATE IS NULL AND FIRST_WAFER_START_TIME IS NULL AND
                                             LAST_WAFER_END_TIME IS NULL AND END_TXN_DATE IS NULL AND ABORT_TXN_DATE IS NULL AND
                                             START_DISMOUNT_TXN_DATE IS NULL AND END_DISMOUNT_TXN_DATE IS NULL THEN
                                         'QUEUE TO MNT'
                                        ELSE
                                         NULL
                                      END AS Q_TO_MNT_ESTIMATE,
                                      CASE
                                        WHEN ENDMOUNT_TXN_DATE IS NULL AND IN_DATE IS NULL AND RUN_TXN_DATE IS NULL AND
                                             FIRST_WAFER_START_TIME IS NULL AND LAST_WAFER_END_TIME IS NULL AND
                                             END_TXN_DATE IS NULL AND ABORT_TXN_DATE IS NULL AND START_DISMOUNT_TXN_DATE IS NULL AND
                                             END_DISMOUNT_TXN_DATE IS NULL THEN
                                         'AMHS_RETRIEVAL'
                                        ELSE
                                         NULL
                                      END AS AMHS_ESTIMATE,
                                      CASE
                                        WHEN RUN_TXN_DATE IS NULL AND FIRST_WAFER_START_TIME IS NULL AND
                                             LAST_WAFER_END_TIME IS NULL AND END_TXN_DATE IS NULL AND ABORT_TXN_DATE IS NULL AND
                                             START_DISMOUNT_TXN_DATE IS NULL AND END_DISMOUNT_TXN_DATE IS NULL THEN
                                         'POST_DELIVERY_DELAY'
                                        ELSE
                                         NULL
                                      END AS POST_DELIVERY_DELAY,
                                      CASE
                                        WHEN FIRST_WAFER_START_TIME IS NULL AND LAST_WAFER_END_TIME IS NULL AND
                                             END_TXN_DATE IS NULL AND ABORT_TXN_DATE IS NULL AND START_DISMOUNT_TXN_DATE IS NULL AND
                                             END_DISMOUNT_TXN_DATE IS NULL THEN
                                         'RUN TO START'
                                        ELSE
                                         NULL
                                      END AS RUN_TO_START_ESTIMATE,
                                      CASE
                                        WHEN LAST_WAFER_END_TIME IS NULL AND END_TXN_DATE IS NULL AND ABORT_TXN_DATE IS NULL AND
                                             START_DISMOUNT_TXN_DATE IS NULL AND END_DISMOUNT_TXN_DATE IS NULL THEN
                                         'WAFER PROCESS'
                                        ELSE
                                         NULL
                                      END AS WAFER_PROCESS_ESTIMATE,
                                      -- ALWAYS ned a moveout delay, if it's not at the next op, then it hasnt left this one yet and will need that delay
                                   CASE
                                     WHEN END_TXN_DATE IS NULL AND ABORT_TXN_DATE IS NULL AND START_DISMOUNT_TXN_DATE IS NULL AND
                                          END_DISMOUNT_TXN_DATE IS NULL THEN
                                      'MOVEOUT DELAY'
                                     ELSE
                                      'MOVEOUT DELAY'
                                   END AS MOVEOUT_DELAY_ESTIMATE
                            
                            
                            
                            FROM                        
                            (SELECT 
                            FACILITY,
                            LOT,
                            PRODUCT,
                            PROCESS,
                            OWNER,
                            ROUTE,
                            WAFERS,
                            OPERATION,
                            NTSC_ENTITY,
                            QUEUED_ENTITY,
                            PREVOUT_DATE,
                            MOQ_DATE,
                            INTRODUCE_TXN_DATE,
                            BEGINMOUNT_TXN_DATE,
                             ENDMOUNT_TXN_DATE,
                             IN_DATE,
                             RUN_TXN_DATE,
                             FIRST_WAFER_START_TIME,
                             LAST_WAFER_END_TIME,
                             END_TXN_DATE,
                             ABORT_TXN_DATE,
                             START_DISMOUNT_TXN_DATE,
                             END_DISMOUNT_TXN_DATE,
                             OUT_DATE,
                             RUNID,
                             QUEUEORDER,
                             LOTPOSITION,
                             LOADPORT_QTY,
                             WATERMARK,
                             LOCATION,
                             LAST_UPDATE_DATE

                             FROM (
                             SELECT LS2.*,
                              MAX(PREFERRED) OVER (PARTITION BY LOT, OPERATION, PREVOUT_DATE) as MAX_PREF 
                              FROM (
                              SELECT LS1.*,
                               CASE
                                  WHEN ABORT_TXN_DATE is null THEN 2
                                  WHEN ABORT_TXN_DATE = MAX_ABORT then 1
                                  ELSE 0
                               END AS PREFERRED
                               FROM (
                               SELECT LS.*,
                                      MAX(ABORT_TXN_DATE) OVER (PARTITION BY LOT, OPERATION, PREVOUT_DATE) as MAX_ABORT
                                      FROM HBLP_LOT_EVENT_STATUS LS
                                      ) LS1
                                      ) LS2
                                      ) LS3
                            WHERE PREFERRED = MAX_PREF
                            ) LS
                            
                            LEFT JOIN AMHS_STATUS AMHS
                            ON AMHS.LOT = LS.LOT
                            AND AMHS.TXNDATE > LS.PREVOUT_DATE - 5 / (24 * 60)
                            LEFT JOIN (SELECT WH2.FACILITY,
                                             WH2.OPERATION,
                                             AVG(WH2.TOTAL_WAFERS) AS AVG_INV
                                      FROM (SELECT WH.FACILITY,
                                                   WH.TOOLSET,
                                                   WH.OPERATION,
                                                   SUM(WH.QTY_INV + WH.QTY_INV_RWK) OVER(PARTITION BY WH.TOOLSET) AS TOTAL_WAFERS
                                            FROM HBLP_WIP_STATUS WH) WH2
                                      GROUP BY FACILITY,
                                               OPERATION) INV
                            ON LS.OPERATION = INV.OPERATION) LS2
                      -- Response 
                      -- we shuold always have an inventory, so only problem is missing operations from table
                      LEFT JOIN HBLP_MODEL_DELAY D1
                      ON LS2.OPERATION = D1.OPERATION
                      AND LS2.PROCESS = D1.PROCESS
                      AND D1.MODEL_TYPE = 'RESPONSE_TIME'
                      -- Queue to mount
                      LEFT JOIN HBLP_MODEL_DELAY D2
                      ON (SUBSTR(LS2.QUEUED_ENTITY, 1, 3) = D2.TOOLTYPE)
                      AND D2.MODEL_TYPE = 'QUEUE_TO_MOUNT'
                      AND D2.WATERMARK_TYPE = CASE
                           WHEN LS2.QUEUEORDER > LS2.WATERMARK THEN
                            'OVER'
                           ELSE
                            'UNDER'
                         END
                      -- get an average for operation regardless of toolset
                      LEFT JOIN HBLP_MODEL_DELAY D2A
                      ON D2A.OPERATION = LS2.OPERATION
                      AND D2A.TOOLTYPE = '*'
                      AND D2A.MODEL_TYPE = 'QUEUE_TO_MOUNT'
                      -- AMHS by op
                      -- need a clean pair by op, not toolset since we dont know toolset yet
                      LEFT JOIN HBLP_MODEL_DELIVERY D3
                      ON D3.OPERATION = LS2.OPERATION
                      -- AMHS by loc (we know tool, but not delivered yet)
                      LEFT JOIN HBLP_MODEL_DELIVERY D4
                      ON D4.DELIVERY_COMPLETE_LOCATION = LS2.QUEUED_ENTITY
                      AND D4.DELIVERY_REQUEST_LOCATION = LS2.STORED_LOC
                      -- Post Delivery Delay, by op and op/toolset
                      LEFT JOIN HBLP_MODEL_POST_DELIVERY D5
                      ON D5.OPERATION = LS2.OPERATION
                      AND D5.TOOLTYPE = SUBSTR(LS2.QUEUED_ENTITY, 1, 3)
                      LEFT JOIN HBLP_MODEL_POST_DELIVERY D5A
                      ON D5A.OPERATION = LS2.OPERATION
                      AND D5A.TOOLTYPE = '*'
                      -- Run Delay
                      LEFT JOIN HBLP_MODEL_DELAY D6
                      ON D6.MODEL_TYPE = 'RUN_DELAY'
                      AND D6.TOOLTYPE = SUBSTR(LS2.QUEUED_ENTITY, 1, 3)
                      LEFT JOIN HBLP_MODEL_DELAY D6A
                      ON D6A.MODEL_TYPE = 'RUN_DELAY'
                      AND D6A.OPERATION = LS2.OPERATION
                      AND D6A.TOOLTYPE = '*'
                      -- Process Time
                      LEFT JOIN HBLP_MODEL_DELAY D7
                      ON D7.MODEL_TYPE = 'LOT_PT'
                      AND D7.OPERATION = LS2.OPERATION
                      AND D7.TOOLTYPE = SUBSTR(LS2.QUEUED_ENTITY, 1, 3)
                      AND D7.PROCESS = LS2.PROCESS
                      -- Process time by oper avg
                      LEFT JOIN HBLP_MODEL_DELAY D7A
                      ON D7A.MODEL_TYPE = 'LOT_PT'
                      AND D7A.OPERATION = LS2.OPERATION
                      AND D7A.TOOLTYPE = '*'
                      AND D7A.PROCESS = LS2.PROCESS
                      -- Moveout Delay
                      LEFT JOIN HBLP_MODEL_MVOU_DELAY D8
                      ON D8.OPERATION = LS2.OPERATION
                      AND D8.TOOLTYPE = SUBSTR(LS2.QUEUED_ENTITY, 1, 3)
                      LEFT JOIN HBLP_MODEL_MVOU_DELAY D8A
                      ON D8A.OPERATION = LS2.OPERATION
                      AND D8A.TOOLTYPE = '*'
                      -- Fallback Queue time
                      LEFT JOIN HBLP_ACTUAL_QUEUE_TIME_MV QT
                      ON LS2.OPERATION = QT.OPERATION
                      -- Fallback Process Time
                      LEFT JOIN HBLP_ACTUAL_PROCESS_TIME_MV PT
                      ON LS2.OPERATION = PT.OPERATION
                      
                      -- fallback option 2
                      -- Xeta Queue and Process Times
                      LEFT JOIN XETA.I_CTG_FAB CT 
                      ON LS2.OPERATION = CT.OPERATION
                      AND LS2.PROCESS = CT.LOT_PROCESS
                      AND LS2.OWNER = CT.LOT_TYPE
                      AND CT.LOT_QTY = '-1'
                      AND CT.LOT_PRIORITY  = '-1'
                      AND CT.LOT_PRODUCT = '.'
                      --AND REGEXP_LIKE(LS2.WAFER_QTY, REPLACE(CT.LOT_QTY, '-1', '.'))
                      --AND REGEXP_LIKE(LS2.LOT_PRIORITY, REPLACE(CT.LOT_PRIORITY, '-1', '.'))
                      --AND REGEXP_LIKE(REPLACE(LS2.PRODUCT, ' ', ''), CT.LOT_PRODUCT)
                                    
                      -- fallback option 3
                      -- Process Oper UDF Queue and Process Times
                      LEFT JOIN MS_1_F_PROCESS_OPER_UDF POU 
                      ON POU.PROCESS = LS2.PROCESS
                      AND POU.OPERATION = LS2.OPERATION
                      AND POU.WHAT_IF# = 1
                      
                      ) LS3
                --WHERE ABORT_TXN_DATE IS NULL
                ) LS4) LS5 ) LS6 ) LS7;

    v_RowsAdded := SQL%ROWCOUNT;
    COMMIT;


    INSERT INTO HBLP_LOT_MODELED_PT_HIST
      (FACILITY,
       LOT,
       PRODUCT,
       PROCESS,
       OWNER,
       ROUTE,
       WAFERS,
       OPERATION,
       NTSC_ENTITY,
       QUEUED_ENTITY,
       PREVOUT_DATE,
       MOQ_DATE,
       INTRODUCE_TXN_DATE,
       BEGINMOUNT_TXN_DATE,
       ENDMOUNT_TXN_DATE,
       IN_DATE,
       RUN_TXN_DATE,
       FIRST_WAFER_START_TIME,
       LAST_WAFER_END_TIME,
       END_TXN_DATE,
       ABORT_TXN_DATE,
       START_DISMOUNT_TXN_DATE,
       END_DISMOUNT_TXN_DATE,
       OUT_DATE,
       RUNID,
       QUEUEORDER,
       LOTPOSITION,
       LOADPORT_QTY,
       WATERMARK,
       LOCATION,
       LAST_UPDATE_DATE,
       STORED_LOC,
       AVG_INV,
       CURRENT_STEP,
       TIME_IN_CURRENT_STEP,
       RESPONSE_ESTIMATE,
       Q_TO_MNT_ESTIMATE,
       AMHS_ESTIMATE,
       POST_DELIVERY_DELAY,
       RUN_TO_START_ESTIMATE,
       WAFER_PROCESS_ESTIMATE,
       MOVEOUT_DELAY_ESTIMATE,
       RESPONSE_DELAY,
       QUEUE_TO_MOUNT_DELAY,
       AMHS_DELAY,
       POST_DELIVERY_DELAY_TIME,
       RUN_DELAY,
       WAFER_PROCESS_TIME,
       MOVEOUT_DELAY,
       ROUGH_AVG_QT,
       ROUGH_FIT_PT,
       MISSING_DATA,
       QT_INVALID,
       PT_INVALID,
       EFF_RESPONSE_DELAY,
       EFF_QUEUE_TO_MOUNT_DELAY,
       EFF_AMHS_DELAY,
       EFF_POST_DEL_DELAY,
       EFF_RUN_DELAY,
       EFF_PROC_TIME,
       EFF_MOVEOUT_DELAY,
       R0_EST_QT_REMAINING,
       R0_EST_PT_REMAINING,
       R1_EST_QT_REMAINING,
       R1_EST_PT_REMAINING,
       R0_TIME_REMAINING,
       R0A_TIME_REMAINING,
       R1_TIME_REMAINING,
       R2_EST_QT_REMAINING,
       R2_EST_PT_REMAINING,
       R2A_EST_QT_REMAINING,
       R2A_EST_PT_REMAINING,
       R2_TIME_REMAINING,
       R2A_TIME_REMAINING,
       SNAPSHOT_DATE)
      SELECT PTH.*,
             v_StartTime AS SNAPSHOT_DATE
      FROM HBLP_LOT_MODELED_PT PTH;
      
      COMMIT;
  
  -- Write to ExtractMetrics
  SP$LOG_METRICS
    (
        p_ExtractName => c_PROCEDURE_NAME,
        p_ExtractStartDate => v_StartTime,
        p_ExtractEndDate => SYSDATE,
        p_RunStartDate => v_StartTime,
        p_RunEndDate => SYSDATE,
        p_RecordsAdded => v_RowsAdded,
        p_Status => 'SUCCESS'
     );

  -- Write to Logfile
   SP$LOG_ME(c_PROCEDURE_NAME || ': Success with ' || TO_CHAR(v_RowsAdded) || ' Rows added in ' || TO_CHAR(v_ElapsedTime) || ' seconds' );

  EXCEPTION
    WHEN OTHERS
    THEN
      DECLARE
         v_ErrorCode NUMBER := SQLCODE;
         v_ErrorMessage VARCHAR2(300) := SQLERRM;
         v_Comments VARCHAR2(500);
      BEGIN

         ROLLBACK;

         v_COMMENTS := SUBSTR(v_ErrorCode || ' - ' || v_ErrorMessage || ' - ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 0, 500);

        SP$LOG_ME(c_PROCEDURE_NAME || ' - Error: '|| v_Comments);
        SP$LOG_METRICS(c_PROCEDURE_NAME, v_StartTime, SYSDATE, v_StartTime, SYSDATE,0 , 0, 'FAILURE', v_Comments);

   END;

END SP$MODELED_PROCESSTIME;
