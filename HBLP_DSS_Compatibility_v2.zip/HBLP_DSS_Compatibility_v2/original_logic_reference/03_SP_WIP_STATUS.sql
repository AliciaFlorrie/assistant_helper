-- REFERENCE ONLY: exact procedure body excerpt; not a standalone SQL script.
PROCEDURE SP$WIP_STATUS

IS

  c_PROCEDURE_NAME CONSTANT MC_1_F_EXTRACTMETRICS.EXTRACT_NAME%TYPE := 'SP$WIP_STATUS';
  v_RowsAdded      NUMBER;
  v_StartTime      DATE := SYSDATE;
  v_ElapsedTime    NUMBER;
  v_RollupEnd      DATE;
  v_Facility       MC_1_F_FACILITY.FACILITY%TYPE;
  
BEGIN

      --
      -- Get the primariy facility and load date from the Server Desc Table
      --
      SELECT SD.PRIMARY_FACILITY INTO v_Facility FROM MC_1_F_SERVERDESC_M SD;
      SELECT SD.LAST_LOAD_DATE INTO v_RollupEnd FROM MC_1_F_SERVERDESC_M SD;  
      
      -- Step 1: Capture the entities associated with the operation at which the lots will be arriving

      EXECUTE IMMEDIATE ('TRUNCATE TABLE HBLP_WIP_STATUS') ;
      COMMIT;
                  
      INSERT INTO HBLP_WIP_STATUS
        (FACILITY,
         TOOLSET,
         PROCESS,
         OPERATION,
         OWNER,
         LOCATION,
         QTY_LOTS,
         QTY_INV,
         QTY_MOVEDIN,
         QTY_ONHOLD,
         HAO_SUM,
         QTY_LOTS_RWK,
         QTY_INV_RWK,
         QTY_MOVEDIN_RWK,
         QTY_ONHOLD_RWK,
         HAO_SUM_RWK,
         LAST_UPDATE_DATE)
          SELECT WIP.FACILITY,
                 SUBSTR(FEO.ENTITY, 1, 3) AS TOOLSET,
                 WIP.PROCESS,
                 WIP.OPERATION,
                 WIP.OWNER,
                 WIP.LOCATION,
                 SUM(WIP.QTY_LOTS) AS QTY_LOTS,
                 SUM(WIP.QTY_INV) AS QTY_INV,
                 SUM(WIP.QTY_MOVEDIN) AS QTY_MOVEDIN,
                 SUM(WIP.QTY_ONHOLD) AS QTY_ONHOLD,
                 SUM(WIP.HAO_SUM) HAO_SUM,
                 -- REWORK --
                 SUM(WIP.QTY_LOTS_RWK) AS QTY_LOTS_RWK,
                 SUM(WIP.QTY_INV_RWK) AS QTY_INV_RWK,
                 SUM(WIP.QTY_MOVEDIN_RWK) AS QTY_MOVEDIN_RWK,
                 SUM(WIP.QTY_ONHOLD_RWK) AS QTY_ONHOLD_RWK,
                 SUM(WIP.HAO_SUM_RWK) HAO_SUM_RWK,
                 v_RollupEnd AS LAST_UPDATE_DATE
          FROM (
          SELECT T.FACILITY,
                 T.PROCESS,
                 T.OPERATION,
                 T.OWNER,
                 T.LOCATION, 
                 T.QTY_LOTS,
                 T.QTY_INV,
                 T.QTY_MOVEDIN,
                 T.QTY_ONHOLD,
                 T.HAO_SUM,
                 -- REWORK --
                 T.QTY_LOTS_RWK,
                 T.QTY_INV_RWK,
                 T.QTY_MOVEDIN_RWK,
                 T.QTY_ONHOLD_RWK,
                 T.HAO_SUM_RWK,
                 T.END_DATE
          FROM (
               SELECT FACILITY,
                      PROCESS,
                      OPERATION,
                      OWNER,
                      LOCATION,
                      QTY_LOTS,
                      QTY_INV,
                      QTY_MOVEDIN,
                      QTY_ONHOLD,
                      HAO_SUM,
                      -- REWORK --
                      QTY_LOTS_RWK,
                      QTY_INV_RWK,
                      QTY_MOVEDIN_RWK,
                      QTY_ONHOLD_RWK,
                      HAO_SUM_RWK,
                      END_DATE
           from (
                SELECT BOH.FACILITY,
                       NVL(BOH.PROCESS,'?') AS PROCESS,
                       BOH.OPERATION,
                       BOH.OWNER,
                       BOH.LOCATION,
                       SUM(BOH.QTY_LOTS) AS QTY_LOTS,
                       SUM(BOH.QTY_INV) AS QTY_INV,
                       SUM(BOH.QTY_MOVEDIN) AS QTY_MOVEDIN,
                       SUM(BOH.QTY_ONHOLD) AS QTY_ONHOLD,
                       SUM(BOH.HAO_SUM) AS HAO_SUM,
                       -- REWORK --
                       SUM(BOH.QTY_LOTS_RWK) AS QTY_LOTS_RWK,
                       SUM(BOH.QTY_INV_RWK) AS QTY_INV_RWK,
                       SUM(BOH.QTY_MOVEDIN_RWK) AS QTY_MOVEDIN_RWK,
                       SUM(BOH.QTY_ONHOLD_RWK) AS QTY_ONHOLD_RWK,
                       SUM(BOH.HAO_SUM_RWK) AS HAO_SUM_RWK,
                       v_RollupEnd  AS END_DATE
                FROM
                (
                -------------------------------------------------------------------------------------
                -- BOH -- This Query Gets the BOH Inventory numbers for a specified time
                -------------------------------------------------------------------------------------
                SELECT
                  BOH.FACILITY,
                  PRV.PROCESS,
                  BOH.OPERATION,
                  PRV.ROUTE_BASE_NAME AS ROUTE,
                  PRV.ROUTE_TYPE,
                  NVL(BOH.PRODUCT,'?') AS PRODUCT,
                  NVL(BOH.OWNER,'?') AS OWNER,
                  v_Facility AS FAB_SITE_ID,
                  BOH.LOCATION,
                  /* NON-REWORK INV */
                  DECODE(BOH.ONREWORK,'N',1,0) AS QTY_LOTS,
                  DECODE(BOH.ONREWORK,'N',BOH.QTY1,0) AS QTY_INV,
                  DECODE(BOH.ONREWORK,'N',DECODE(BOH.MOVEDIN,'Y',BOH.QTY1,0),0) AS QTY_MOVEDIN,
                  DECODE(BOH.ONREWORK,'N',DECODE(BOH.ONHOLD,'Y',BOH.QTY1,0),0) AS QTY_ONHOLD,
                  DECODE(BOH.ONREWORK,'N',ROUND((v_RollupEnd-BOH.DATE_ENTERED_OPERATION)*24,2),0) AS HAO_SUM,
                  /* REWORK INV */
                  DECODE(BOH.ONREWORK,'Y',1,0) AS QTY_LOTS_RWK,
                  DECODE(BOH.ONREWORK,'Y',BOH.QTY1,0) AS QTY_INV_RWK,
                  DECODE(BOH.ONREWORK,'Y',DECODE(BOH.MOVEDIN,'Y',BOH.QTY1,0),0) AS QTY_MOVEDIN_RWK,
                  DECODE(BOH.ONREWORK,'Y',DECODE(BOH.ONHOLD,'Y',BOH.QTY1,0),0) AS QTY_ONHOLD_RWK,
                  DECODE(BOH.ONREWORK,'Y',ROUND((v_RollupEnd-BOH.DATE_ENTERED_OPERATION)*24,2),0) AS HAO_SUM_RWK
                FROM
                  (
                  ---------------------------------------------------------------------------
                  -- LOTS WITH NO TRANSACTIONS -- TRANSACTIONS SUCH AS DLLH ARE NOT LOGGED IN F_LOTTXNHIST
                  -- USE DATA FROM F_LOT
                  ---------------------------------------------------------------------------
                  SELECT
                    FL.FACILITY,
                    FL.LOT,
                    FL.OPERATION,
                    FL.ROUTE,
                    FL.PRODUCT,
                    FL.OWNER,
                    v_Facility AS FAB_SITE_ID,
                    FL.QTY1,
                    FL.MOVEDIN,
                    FL.ONHOLD,
                    FL.ONREWORK,
                    FL.DATE_ENTERED_OPERATION,
                    FL.CURRENT_LOCATION AS LOCATION,
                    'NO TRANSACTION' AS SOURCE
                  FROM
                    MC_1_F_LOT FL
                  WHERE
                    FL.FACILITY = v_Facility
                    AND FL.OWNER != 'EMPTYFOUP'
                    AND FL.CREATION_DATE <= v_RollupEnd
                    AND FL.TERMINATED = 'N'
                    AND FL.SRC_ERASE_DATE IS NULL
                    AND FL.ATSTORES = 'N'
                    -- ONLY SELECT LOTS THAT HAVE HAD NO TRANSACTIONS
                    AND FL.LOT NOT IN
                      (
                      SELECT DISTINCT FLTH.LOT
                      FROM MC_1_F_LOTTXNHIST FLTH
                      -- Do Not Filter on Facility
                      -- This would prevent lots that were created in another facility 
                      -- before the specified time from showing up
                      WHERE FLTH.TXN_DATE >= v_RollupEnd
                      AND FLTH.OWNER_OLD != 'EMPTYFOUP'
                      AND FLTH.HISTORY_DELETED_FLAG = 'N'
                      AND FLTH.OCCURS_BETWEEN_TXN_AND_UNDO = 'N')
                  ---------------------------------------------------------------------------
                  UNION ALL
                  ---------------------------------------------------------------------------
                  -- LOTS WITH A TRANSACTION
                  ---------------------------------------------------------------------------
                  SELECT
                    FLTH.FACILITY_OLD AS FACILITY,
                    FLTH.LOT,
                    FLTH.OPERATION_OLD AS OPERATION,
                    FLTH.ROUTE_OLD AS ROUTE,
                    FLTH.PRODUCT_OLD AS PRODUCT,
                    FLTH.OWNER_OLD AS OWNER,
                    v_Facility AS FAB_SITE_ID,
                    DECODE(TM.TRANSACTION,'MRLT',MIN(FLTH.OLDQTY1),'SPLT',MAX(FLTH.OLDQTY1),SUM(FLTH.OLDQTY1)) AS QTY1,
                    DECODE(TM.TXN_TYPE,'MVIN','N','MVOU','Y',FLTH.MOVEIN_PERFORMED) AS MOVEDIN,
                    FLTH.HOLD_OLD AS ONHOLD,
                    FLTH.REWORK_OLD AS ONREWORK,
                    FLTH.PREVOUT_DATE AS DATE_ENTERED_OPERATION,
                    FLTH.LOCATION_OLD AS LOCATION,
                    'TRANSACTION' AS SOURCE
                  FROM
                    MC_1_F_LOTTXNHIST FLTH,
                    (SELECT SEARCH_VALUE,TRANSACTION,TXN_TYPE FROM MS_1_F_SD_TXN_MAP_V) TM,
                    (SELECT --/*+ INDEX(FLTH XPKF_LOTTXNHIST) */
                      FLTH.FACILITY_OLD,
                      FLTH.LOT,
                      FLTH.LOCATION_OLD AS LOCATION,
                      MIN(FLTH.TXN_DATE) AS TXN_DATE
                    FROM MC_1_F_LOTTXNHIST FLTH
                    WHERE FLTH.FACILITY_OLD = v_Facility
                    AND FLTH.TXN_DATE >= v_RollupEnd
                    AND FLTH.PREVOUT_DATE < v_RollupEnd
                    AND FLTH.OWNER_OLD != 'EMPTYFOUP'
                    AND FLTH.HISTORY_DELETED_FLAG = 'N'
                    AND FLTH.OCCURS_BETWEEN_TXN_AND_UNDO = 'N'
                    AND FLTH.STORES_CATEGORY_OLD IS NULL
                    AND NVL(UPPER(FLTH.LOT_STATE_OLD),' ') != 'TERMINATED'
                    AND FLTH.TRANSACTION NOT IN ('TRLT','FromStores')
                    AND FLTH.ROUTE_OLD IS NOT NULL
                    GROUP BY FLTH.FACILITY_OLD,
                             FLTH.LOT,
                             FLTH.LOCATION_OLD
                    ) TXN
                  WHERE FLTH.FACILITY_OLD = TXN.FACILITY_OLD
                  AND FLTH.LOT = TXN.LOT
                  AND FLTH.TXN_DATE = TXN.TXN_DATE
                  AND FLTH.LOCATION_OLD = TXN.LOCATION
                  AND FLTH.TRANSACTION = TM.SEARCH_VALUE (+)
                  GROUP BY FLTH.FACILITY_OLD,
                           FLTH.LOT,
                           FLTH.OPERATION_OLD,
                          FLTH.ROUTE_OLD,
                         FLTH.PRODUCT_OLD,
                         FLTH.OWNER_OLD,
                         FLTH.LOCATION_OLD,
                         v_Facility,
                          FLTH.TRANSACTION,
                          FLTH.MOVEIN_PERFORMED,
                          FLTH.HOLD_OLD,
                          FLTH.REWORK_OLD,
                          FLTH.PREVOUT_DATE,
                          TM.TRANSACTION,
                          TM.TXN_TYPE
                ) BOH,
                MS_1_F_SD_PROCESS_ROUTE_V PRV
                WHERE
                  BOH.FACILITY = PRV.FACILITY (+)
                  AND BOH.ROUTE = PRV.ROUTE (+)
                -------------------------------------------------------------------------------------
                -- END- BOH -- This Query Gets the BOH Inventory numbers for a specified time
                -------------------------------------------------------------------------------------
                ) BOH,
                MS_1_F_SD_PROCESS_OPER SPO
              WHERE
                BOH.FACILITY = v_Facility
                AND BOH.FACILITY = SPO.FACILITY
                AND BOH.OPERATION = SPO.OPERATION
                AND BOH.PROCESS = SPO.PROCESS
                AND SPO.GROUPING IN ('CORE','?')
                AND SPO.ACTIVE_WIP_FLAG = 'Y'
              GROUP BY
                BOH.FACILITY,
                BOH.PROCESS,
                BOH.OPERATION,
                BOH.OWNER,
                BOH.LOCATION
              ) T
              ) T
              )  WIP,
              MC_1_F_ENTITYOPER FEO
          WHERE FEO.FACILITY = WIP.FACILITY     
          AND FEO.OPERATION = WIP.OPERATION
          GROUP BY WIP.FACILITY,
                 SUBSTR(FEO.ENTITY, 1, 3),
                 WIP.PROCESS,
                 WIP.OPERATION,
                 WIP.OWNER,
                 WIP.LOCATION;

      v_RowsAdded := SQL%ROWCOUNT;

      COMMIT;
      
  v_ElapsedTime := ROUND((SYSDATE - v_StartTime) * 24 * 60 *60);

  -- Write to ExtractMetrics
  SP$LOG_METRICS
    (
        p_ExtractName => c_PROCEDURE_NAME,
        p_ExtractStartDate => v_StartTime,
        p_ExtractEndDate => SYSDATE,
        p_RunStartDate => v_StartTime,
        p_RunEndDate => SYSDATE,
        p_RecordsAdded => v_RowsAdded,
        p_Status => 'SUCCESS'
     );

  -- Write to Logfile
   SP$LOG_ME(c_PROCEDURE_NAME || ': Success with ' || TO_CHAR(v_RowsAdded) || ' Rows added in ' || TO_CHAR(v_ElapsedTime) || ' seconds' );

  EXCEPTION
    WHEN OTHERS
    THEN
      DECLARE
         v_ErrorCode NUMBER := SQLCODE;
         v_ErrorMessage VARCHAR2(300) := SQLERRM;
         v_Comments VARCHAR2(500);
      BEGIN

         ROLLBACK;

         v_COMMENTS := SUBSTR(v_ErrorCode || ' - ' || v_ErrorMessage || ' - ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 0, 500);

        SP$LOG_ME(c_PROCEDURE_NAME || ' - Error: '|| v_Comments);
        SP$LOG_METRICS(c_PROCEDURE_NAME, v_StartTime, SYSDATE, v_StartTime, SYSDATE,0 , 0, 'FAILURE', v_Comments);

   END;

END SP$WIP_STATUS;
