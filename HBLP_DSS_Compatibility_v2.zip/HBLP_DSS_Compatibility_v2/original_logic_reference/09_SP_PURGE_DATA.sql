-- REFERENCE ONLY: exact procedure body excerpt; not a standalone SQL script.
PROCEDURE SP$PURGE_DATA

IS

  c_PROCEDURE_NAME CONSTANT MC_1_F_EXTRACTMETRICS.EXTRACT_NAME%TYPE := 'SP$PURGE_DATA';

  v_DaysHistory NUMBER;
  v_RollupDate DATE;
  v_StartTime DATE := SYSDATE;


BEGIN

  -- Determine the latest Rollup Date
  SELECT MAX(SNAPSHOT_DATE) INTO v_RollupDate FROM HBLP_LOT_TOOL_HIST;

  --
  -- Purge Detail Table
  --
  v_DaysHistory := FN$GET_META_VALUE('DAYS_SNAPSHOT_HIST');

  DELETE
    FROM HBLP_LOT_TOOL_HIST
  WHERE SNAPSHOT_DATE < (v_RollupDate - v_DaysHistory);

   g_RowsRemoved :=  SQL%ROWCOUNT;
   COMMIT;


  --Clean up lot flow hist table (debug)
  DELETE
    FROM HBLP_LOT_FLOW_HIST_S
  WHERE SNAPSHOT_DATE < (v_RollupDate - 2);

  COMMIT;
   
   
  --Clean up flow context hist table (debug)
  DELETE
    FROM HBLP_FLOW_CONTEXT_HIST_S
  WHERE SNAPSHOT_DATE < (v_RollupDate - 2);

   COMMIT;
      
  --Clean up flow context hist table (debug)
  DELETE
    FROM HBLP_LOT_PROCESSTIME_HIST_S
  WHERE SNAPSHOT_DATE < (v_RollupDate - 2);

  COMMIT;
  
  
  
   --  New Model testing tables 
  DELETE
    FROM HBLP_LOT_TOOL_HIST2
   WHERE SNAPSHOT_DATE < (v_RollupDate - v_DaysHistory);

  COMMIT;   
    
  DELETE
    FROM HBLP_LOT_PROCESSTIME_HIST_S2
  WHERE SNAPSHOT_DATE < (v_RollupDate - 2);

  COMMIT;
   
  DELETE
    FROM HBLP_LOT_MODELED_PT_HIST
  WHERE SNAPSHOT_DATE < (v_RollupDate - 7);

  COMMIT;   
   
  
  sp$log_me(to_char(g_RowsRemoved) || ' rows purged');

  SP$LOG_METRICS
  (
       p_ExtractName => c_PROCEDURE_NAME,
       p_ExtractStartDate => v_StartTime ,
       p_ExtractEndDate => SYSDATE,
       p_RunStartDate => v_StartTime,
       p_RunEndDate => SYSDATE,
       p_RecordsDeleted => g_RowsRemoved,
       p_Status => 'SUCCESS'
   );

END SP$PURGE_DATA;
