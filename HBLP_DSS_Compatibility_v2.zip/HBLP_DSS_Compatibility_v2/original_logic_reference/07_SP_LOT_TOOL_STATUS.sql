-- REFERENCE ONLY: exact procedure body excerpt; not a standalone SQL script.
PROCEDURE SP$LOT_TOOL_STATUS

IS

  c_PROCEDURE_NAME CONSTANT MC_1_F_EXTRACTMETRICS.EXTRACT_NAME%TYPE := 'SP$LOT_TOOL_STATUS';
  v_RowsAdded NUMBER;
  v_StartTime DATE := SYSDATE;
  v_ElapsedTime NUMBER;
  v_StagingCount NUMBER;
  v_StagingCount2 NUMBER;
  
BEGIN
      -- START:: Production version (Testing parallel new prediction below)
      -- Step 1: Capture the entities associated with the operation at which the lots will be arriving

      EXECUTE IMMEDIATE ('TRUNCATE TABLE HBLP_LOT_TOOL_STATUS_S') ;
      COMMIT;      
      
      INSERT INTO HBLP_LOT_TOOL_STATUS_S
      (FACILITY,
       LOT,
       PRODUCT,
       ROUTE,
       FLOWPLAN,
       FLOW_CONTEXT,
       ROUTE_BASE_NAME,
       OPERATION,
       OPERATION_VERSION,
       ENTITY,
       OWNER,
       LOT_PRIORITY,
       HOTLOT,
       LOT_STATE,
       PROCESS,
       DOTPROCESS,
       WAFER_QTY,
       DELTA_TO_ETA,
       ETA,
       EXEC_SEQ,
       ENTITYOPER_VALID,
       TOOL_QUALIFICATION,
       TOOL_UP,
       TOOL_BUSY,
       FSUI_PRIORITY,
       LAST_LOAD_DATE,
       DBSD_FLAG,
       DBSD_RW_FLAG,
       LCA_FLAG,
       LITHO_L2L_FLAG,
       LITHO_RW_FLAG,
       RETICLE_FLAG,
       RESIST_FLAG,
       SIF_FLAG,
       MOQRESTRICT_FLAG,
       EXCLUDETOOL_FLAG,
       PROCPEND_FLAG,
       DIFF_BLOCK_FLAG,
       PM_OVERDUE_FLAG,
       LEVELID)
      SELECT DISTINCT 
             PT.FACILITY,
             PT.LOT,
             PT.PRODUCT,
             PT.ROUTE,
             PT.FLOWPLAN,
             PT.FLOW_CONTEXT,
             PT.ROUTE_BASE_NAME,
             PT.OPERATION,
             PT.OPERATION_VERSION,
             FE.PARENT_ENTITY AS ENTITY,
             PT.OWNER,
             PT.LOT_PRIORITY,
             PT.HOTLOT,
             PT.LOT_STATE,
             PT.PROCESS,
             PT.DOTPROCESS,
             PT.WAFER_QTY,
             PT.ADJ_CUM_PROCESS_TIME AS DELTA_TO_ETA,
             PT.ETA,
             PT.EXEC_SEQ,
             'Y' AS ENTITYOPER_VALID,
             'N' AS TOOL_QUALIFICATION,
             'Y' AS TOOL_UP,
             'N' AS TOOL_BUSY,
             100 AS FSUI_PRIORITY,
             SYSDATE AS LAST_LOAD_DATE,
             'N' AS DBSD_FLAG,
             'N' AS DBSD_RW_FLAG,
             'N' AS LCA_FLAG,
             'N' AS LITHO_L2L_FLAG,
             'N' AS LITHO_RW_FLAG,
             'N' AS RETICLE_FLAG,
             'N' AS RESIST_FLAG,--
             'N' AS SIF_FLAG,
             'N' AS MOQRESTRICT_FLAG,
             'N' AS EXCLUDETOOL_FLAG,
             'N' AS PROCPEND_FLAG,
             'N' AS DIFF_BLOCK_FLAG,
             'N' AS PM_OVERDUE_FLAG,
             0 AS LEVELID
      -- GET THE VALID ENTITY OPER COMBINATIONS
      FROM HBLP_LOT_PROCESSTIME_S PT
      LEFT JOIN MC_1_F_ENTITYOPER FEO
      ON PT.FACILITY = FEO.FACILITY
      AND PT.OPERATION = FEO.OPERATION
      -- BRING BACK ON PARENT ENTITIES
      LEFT JOIN MC_1_F_ENTITY FE
      ON FEO.FACILITY = FE.FACILITY
      AND FEO.ENTITY = FE.PARENT_ENTITY
      WHERE FEO.SRC_ERASE_DATE IS NULL
      ORDER BY PT.LOT,
               PT.EXEC_SEQ;
      
      v_RowsAdded := SQL%ROWCOUNT;

      COMMIT;
      

      SELECT COUNT(1) INTO v_StagingCount FROM HBLP_LOT_TOOL_STATUS_S;
      
      
      IF v_StagingCount > 0 THEN

      DELETE FROM HBLP_LOT_TOOL_STATUS;

      INSERT INTO HBLP_LOT_TOOL_STATUS
        (FACILITY,
         LOT,
         PRODUCT,
         ROUTE,
         FLOWPLAN,
         FLOW_CONTEXT,
         ROUTE_BASE_NAME,
         OPERATION,
         OPERATION_VERSION,
         ENTITY,
         OWNER,
         LOT_PRIORITY,
         HOTLOT,
         LOT_STATE,
         PROCESS,
         DOTPROCESS,
         WAFER_QTY,
         DELTA_TO_ETA,
         ETA,
         EXEC_SEQ,
         ENTITYOPER_VALID,
         TOOL_QUALIFICATION,
         TOOL_UP,
         TOOL_BUSY,
         FSUI_PRIORITY,
         VALID_TOOL_FLAG,
         RN,
         LAST_LOAD_DATE)

      SELECT FACILITY,
             LOT,
             PRODUCT,
             ROUTE,
             FLOWPLAN,
             FLOW_CONTEXT,
             ROUTE_BASE_NAME,
             OPERATION,
             OPERATION_VERSION,
             ENTITY,
             OWNER,
             LOT_PRIORITY,
             HOTLOT,
             LOT_STATE,
             PROCESS,
             DOTPROCESS,
             WAFER_QTY,
             DELTA_TO_ETA,
             ETA,
             EXEC_SEQ,
             ENTITYOPER_VALID,
             TOOL_QUALIFICATION,
             TOOL_UP,
             TOOL_BUSY,
             FSUI_PRIORITY,
             VALID_TOOL_FLAG,
             RN,
             LAST_LOAD_DATE
      FROM
      (
      SELECT T.FACILITY,
             T.LOT,
             T.PRODUCT,
             T.ROUTE,
             T.FLOWPLAN,
             T.FLOW_CONTEXT,
             T.ROUTE_BASE_NAME,
             T.OPERATION,
             T.OPERATION_VERSION,
             T.ENTITY,
             T.OWNER,
             T.LOT_PRIORITY,
             T.HOTLOT,
             T.LOT_STATE,
             T.PROCESS,
             T.DOTPROCESS,
             T.WAFER_QTY,
             T.DELTA_TO_ETA,
             T.ETA,
             T.EXEC_SEQ,
             T.ENTITYOPER_VALID,
             T.TOOL_QUALIFICATION,
             T.TOOL_UP,
             T.TOOL_BUSY,
             T.FSUI_PRIORITY,
             T.VALID_TOOL_FLAG,
             ROW_NUMBER() OVER (PARTITION BY LOT, OPERATION, EXEC_SEQ ORDER BY LOT, EXEC_SEQ, VALID_TOOL_FLAG DESC, FSUI_PRIORITY, ENTITY) AS RN,
             T.LAST_LOAD_DATE
      FROM
      (SELECT FACILITY,
             LOT,
             PRODUCT,
             ROUTE,
             FLOWPLAN,
             FLOW_CONTEXT,
             ROUTE_BASE_NAME,
             OPERATION,
             OPERATION_VERSION,
             NVL(ENTITY,'NA') AS ENTITY,
             OWNER,
             LOT_PRIORITY,
             HOTLOT,
             LOT_STATE,
             PROCESS,
             DOTPROCESS,
             WAFER_QTY,
             DELTA_TO_ETA,
             ETA,
             EXEC_SEQ,
             ENTITYOPER_VALID,
             TOOL_QUALIFICATION,
             TOOL_UP,
             TOOL_BUSY,
             FSUI_PRIORITY,
             CASE
               WHEN ENTITYOPER_VALID = 'Y' AND TOOL_QUALIFICATION = 'Y' AND TOOL_UP = 'Y' AND TOOL_BUSY = 'N' AND ENTITY IS NOT NULL THEN 'Y'
               ELSE 'N'
             END AS VALID_TOOL_FLAG,
             LAST_LOAD_DATE
      FROM HBLP_LOT_TOOL_STATUS_S
      ) T
      ) T2
      ORDER BY LOT, EXEC_SEQ, VALID_TOOL_FLAG DESC, FSUI_PRIORITY, ENTITY;
      
      COMMIT;
       
      END IF;
      -- END:: Production version (Testing parallel new prediction below)      
  


      -- START:: Testing version (Testing parallel new prediction below)
      -- Step 1: Capture the entities associated with the operation at which the lots will be arriving

      EXECUTE IMMEDIATE ('TRUNCATE TABLE HBLP_LOT_TOOL_STATUS_S2') ;
      COMMIT;      
      
      INSERT INTO HBLP_LOT_TOOL_STATUS_S2
      (FACILITY,
       LOT,
       PRODUCT,
       ROUTE,
       FLOWPLAN,
       FLOW_CONTEXT,
       ROUTE_BASE_NAME,
       OPERATION,
       OPERATION_VERSION,
       ENTITY,
       OWNER,
       LOT_PRIORITY,
       HOTLOT,
       LOT_STATE,
       PROCESS,
       DOTPROCESS,
       WAFER_QTY,
       DELTA_TO_ETA,
       ETA,
       EXEC_SEQ,
       ENTITYOPER_VALID,
       TOOL_QUALIFICATION,
       TOOL_UP,
       TOOL_BUSY,
       FSUI_PRIORITY,
       LAST_LOAD_DATE,
       DBSD_FLAG,
       DBSD_RW_FLAG,
       LCA_FLAG,
       LITHO_L2L_FLAG,
       LITHO_RW_FLAG,
       RETICLE_FLAG,
       RESIST_FLAG,
       SIF_FLAG,
       MOQRESTRICT_FLAG,
       EXCLUDETOOL_FLAG,
       PROCPEND_FLAG,
       DIFF_BLOCK_FLAG,
       PM_OVERDUE_FLAG,
       LEVELID)
      SELECT DISTINCT 
             PT.FACILITY,
             PT.LOT,
             PT.PRODUCT,
             PT.ROUTE,
             PT.FLOWPLAN,
             PT.FLOW_CONTEXT,
             PT.ROUTE_BASE_NAME,
             PT.OPERATION,
             PT.OPERATION_VERSION,
             FE.PARENT_ENTITY AS ENTITY,
             PT.OWNER,
             PT.LOT_PRIORITY,
             PT.HOTLOT,
             PT.LOT_STATE,
             PT.PROCESS,
             PT.DOTPROCESS,
             PT.WAFER_QTY,
             PT.ADJ_CUM_PROCESS_TIME AS DELTA_TO_ETA,
             PT.ETA,
             PT.EXEC_SEQ,
             'Y' AS ENTITYOPER_VALID,
             'N' AS TOOL_QUALIFICATION,
             'Y' AS TOOL_UP,
             'N' AS TOOL_BUSY,
             100 AS FSUI_PRIORITY,
             SYSDATE AS LAST_LOAD_DATE,
             'N' AS DBSD_FLAG,
             'N' AS DBSD_RW_FLAG,
             'N' AS LCA_FLAG,
             'N' AS LITHO_L2L_FLAG,
             'N' AS LITHO_RW_FLAG,
             'N' AS RETICLE_FLAG,
             'N' AS RESIST_FLAG,--
             'N' AS SIF_FLAG,
             'N' AS MOQRESTRICT_FLAG,
             'N' AS EXCLUDETOOL_FLAG,
             'N' AS PROCPEND_FLAG,
             'N' AS DIFF_BLOCK_FLAG,
             'N' AS PM_OVERDUE_FLAG,
             0 AS LEVELID
      -- GET THE VALID ENTITY OPER COMBINATIONS
      FROM HBLP_LOT_PROCESSTIME_S2 PT
      LEFT JOIN MC_1_F_ENTITYOPER FEO
      ON PT.FACILITY = FEO.FACILITY
      AND PT.OPERATION = FEO.OPERATION
      -- BRING BACK ON PARENT ENTITIES
      LEFT JOIN MC_1_F_ENTITY FE
      ON FEO.FACILITY = FE.FACILITY
      AND FEO.ENTITY = FE.PARENT_ENTITY
      WHERE FEO.SRC_ERASE_DATE IS NULL
      ORDER BY PT.LOT,
               PT.EXEC_SEQ;
      
      COMMIT;
      

      SELECT COUNT(1) INTO v_StagingCount2 FROM HBLP_LOT_TOOL_STATUS_S2;
      
      
      IF v_StagingCount2 > 0 THEN

      DELETE FROM HBLP_LOT_TOOL_STATUS2;

      INSERT INTO HBLP_LOT_TOOL_STATUS2
        (FACILITY,
         LOT,
         PRODUCT,
         ROUTE,
         FLOWPLAN,
         FLOW_CONTEXT,
         ROUTE_BASE_NAME,
         OPERATION,
         OPERATION_VERSION,
         ENTITY,
         OWNER,
         LOT_PRIORITY,
         HOTLOT,
         LOT_STATE,
         PROCESS,
         DOTPROCESS,
         WAFER_QTY,
         DELTA_TO_ETA,
         ETA,
         EXEC_SEQ,
         ENTITYOPER_VALID,
         TOOL_QUALIFICATION,
         TOOL_UP,
         TOOL_BUSY,
         FSUI_PRIORITY,
         VALID_TOOL_FLAG,
         RN,
         LAST_LOAD_DATE)

      SELECT FACILITY,
             LOT,
             PRODUCT,
             ROUTE,
             FLOWPLAN,
             FLOW_CONTEXT,
             ROUTE_BASE_NAME,
             OPERATION,
             OPERATION_VERSION,
             ENTITY,
             OWNER,
             LOT_PRIORITY,
             HOTLOT,
             LOT_STATE,
             PROCESS,
             DOTPROCESS,
             WAFER_QTY,
             DELTA_TO_ETA,
             ETA,
             EXEC_SEQ,
             ENTITYOPER_VALID,
             TOOL_QUALIFICATION,
             TOOL_UP,
             TOOL_BUSY,
             FSUI_PRIORITY,
             VALID_TOOL_FLAG,
             RN,
             LAST_LOAD_DATE
      FROM
      (
      SELECT T.FACILITY,
             T.LOT,
             T.PRODUCT,
             T.ROUTE,
             T.FLOWPLAN,
             T.FLOW_CONTEXT,
             T.ROUTE_BASE_NAME,
             T.OPERATION,
             T.OPERATION_VERSION,
             T.ENTITY,
             T.OWNER,
             T.LOT_PRIORITY,
             T.HOTLOT,
             T.LOT_STATE,
             T.PROCESS,
             T.DOTPROCESS,
             T.WAFER_QTY,
             T.DELTA_TO_ETA,
             T.ETA,
             T.EXEC_SEQ,
             T.ENTITYOPER_VALID,
             T.TOOL_QUALIFICATION,
             T.TOOL_UP,
             T.TOOL_BUSY,
             T.FSUI_PRIORITY,
             T.VALID_TOOL_FLAG,
             ROW_NUMBER() OVER (PARTITION BY LOT, OPERATION, EXEC_SEQ ORDER BY LOT, EXEC_SEQ, VALID_TOOL_FLAG DESC, FSUI_PRIORITY, ENTITY) AS RN,
             T.LAST_LOAD_DATE
      FROM
      (SELECT FACILITY,
             LOT,
             PRODUCT,
             ROUTE,
             FLOWPLAN,
             FLOW_CONTEXT,
             ROUTE_BASE_NAME,
             OPERATION,
             OPERATION_VERSION,
             NVL(ENTITY,'NA') AS ENTITY,
             OWNER,
             LOT_PRIORITY,
             HOTLOT,
             LOT_STATE,
             PROCESS,
             DOTPROCESS,
             WAFER_QTY,
             DELTA_TO_ETA,
             ETA,
             EXEC_SEQ,
             ENTITYOPER_VALID,
             TOOL_QUALIFICATION,
             TOOL_UP,
             TOOL_BUSY,
             FSUI_PRIORITY,
             CASE
               WHEN ENTITYOPER_VALID = 'Y' AND TOOL_QUALIFICATION = 'Y' AND TOOL_UP = 'Y' AND TOOL_BUSY = 'N' AND ENTITY IS NOT NULL THEN 'Y'
               ELSE 'N'
             END AS VALID_TOOL_FLAG,
             LAST_LOAD_DATE
      FROM HBLP_LOT_TOOL_STATUS_S2
      ) T
      ) T2
      ORDER BY LOT, EXEC_SEQ, VALID_TOOL_FLAG DESC, FSUI_PRIORITY, ENTITY;
      
      COMMIT;
       
      END IF;
      -- END:: Testing version (Testing parallel new prediction below)    
      
      
       
  v_ElapsedTime := ROUND((SYSDATE - v_StartTime) * 24 * 60 *60);

  -- Write to ExtractMetrics
  SP$LOG_METRICS
    (
        p_ExtractName => c_PROCEDURE_NAME,
        p_ExtractStartDate => v_StartTime,
        p_ExtractEndDate => SYSDATE,
        p_RunStartDate => v_StartTime,
        p_RunEndDate => SYSDATE,
        p_RecordsAdded => v_RowsAdded,
        p_Status => 'SUCCESS'
     );

  -- Write to Logfile
   SP$LOG_ME(c_PROCEDURE_NAME || ': Success with ' || TO_CHAR(v_RowsAdded) || ' Rows added in ' || TO_CHAR(v_ElapsedTime) || ' seconds' );

  EXCEPTION
    WHEN OTHERS
    THEN
      DECLARE
         v_ErrorCode NUMBER := SQLCODE;
         v_ErrorMessage VARCHAR2(300) := SQLERRM;
         v_Comments VARCHAR2(500);
      BEGIN

         ROLLBACK;

         v_COMMENTS := SUBSTR(v_ErrorCode || ' - ' || v_ErrorMessage || ' - ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 0, 500);

        SP$LOG_ME(c_PROCEDURE_NAME || ' - Error: '|| v_Comments);
        SP$LOG_METRICS(c_PROCEDURE_NAME, v_StartTime, SYSDATE, v_StartTime, SYSDATE,0 , 0, 'FAILURE', v_Comments);

   END;

END SP$LOT_TOOL_STATUS;
