-- REFERENCE ONLY: exact procedure body excerpt; not a standalone SQL script.
PROCEDURE SP$LOTFLOW_PROCESSTIME

IS

  c_PROCEDURE_NAME CONSTANT MC_1_F_EXTRACTMETRICS.EXTRACT_NAME%TYPE := 'SP$LOTFLOW_PROCESSTIME';
  v_RowsAdded NUMBER;
  v_StartTime DATE := SYSDATE;
  v_ElapsedTime NUMBER;
  v_LeadProcessTime NUMBER; 
  v_FallbackQueueTime NUMBER; 
  v_FallbackCycleTime NUMBER;
  
BEGIN
  
     v_LeadProcessTime := FN$GET_META_VALUE('LEAD_PROCESS_TIME'); --typically 8 hours 
     v_FallbackQueueTime := FN$GET_META_VALUE('HOTLOT_QUEUE_TIME'); --typically 5 minutes 
     v_FallbackCycleTime := FN$GET_META_VALUE('HOTLOT_CYCLE_TIME'); -- typically 1 hour

     -- Start :: Primary PT - production version (testing version is below)
      EXECUTE IMMEDIATE ('TRUNCATE TABLE HBLP_LOT_PROCESSTIME_S2') ;
      COMMIT;
            
      INSERT INTO HBLP_LOT_PROCESSTIME_S2
        (FACILITY,
         LOT,
         PRODUCT,
         ROUTE,
         FLOWPLAN,
         ROUTE_BASE_NAME,
         OPERATION,
         OPERATION_VERSION,
         CURR_OPER_FLAG,
         FLOW_CONTEXT,
         OWNER,
         LOT_PRIORITY,
         HOTLOT,
         LOT_STATE,
         PROCESS,
         DOTPROCESS,
         WAFER_QTY,
         MOVEIN_DATE,
         DATE_ENTERED_OPERATION,
         PLAN_CYCLE_TIME,
         PLAN_QUEUE_TIME,
         HOTLOT_QUEUE_TIME,
         PLAN_PT_TIME,
         HOTLOT_CYCLE_TIME,
         ADJUSTED_CYCLE_TIME,
         EXEC_SEQ,
         CUM_PROCESS_TIME,
         ADJ_CUM_PROCESS_TIME,
         LEAD_PROCESS_TIME,
         ORIGINAL_ETA,
         ETA)
      SELECT       PT4.FACILITY,
             PT4.LOT,
             PT4.PRODUCT,
             PT4.ROUTE,
             PT4.FLOWPLAN,
             PT4.ROUTE_BASE_NAME,
             PT4.OPERATION,
             PT4.OPERATION_VERSION,
             PT4.CURR_OPER_FLAG,
             PT4.FLOW_CONTEXT,
             PT4.OWNER,
             PT4.LOT_PRIORITY,
             PT4.HOTLOT,
             PT4.LOT_STATE,
             PT4.PROCESS,
             PT4.DOTPROCESS,
             PT4.WAFER_QTY,
             PT4.MOVEIN_DATE,
             PT4.DATE_ENTERED_OPERATION,
             PT4.PLAN_CYCLE_TIME,
             PT4.PLAN_QUEUE_TIME,
             PT4.HOTLOT_QUEUE_TIME,
             PT4.PLAN_PT_TIME,
             PT4.HOTLOT_CYCLE_TIME,
             PT4.ADJUSTED_CYCLE_TIME,
             PT4.EXEC_SEQ,
             PT4.CUM_PROCESS_TIME,
             PT4.PREV_ADJ_CUM_PROCESS_TIME AS ADJ_CUM_PROCESS_TIME,
             PT4.LEAD_PROCESS_TIME,
             PT4.PREV_CUM_PROCESS_TIME + PT4.DATE_ENTERED_OPERATION AS ORIGINAL_ETA,
             PT4.PREV_ADJ_CUM_PROCESS_TIME + PT4.DATE_ENTERED_OPERATION as ETA
      FROM
      (
      SELECT PT3.FACILITY,
             PT3.LOT,
             PT3.PRODUCT,
             PT3.ROUTE,
             PT3.FLOWPLAN,
             PT3.ROUTE_BASE_NAME,
             PT3.OPERATION,
             PT3.OPERATION_VERSION,
             PT3.CURR_OPER_FLAG,
             PT3.FLOW_CONTEXT,
             PT3.OWNER,
             PT3.LOT_PRIORITY,
             PT3.HOTLOT,
             PT3.LOT_STATE,
             PT3.PROCESS,
             PT3.DOTPROCESS,
             PT3.WAFER_QTY,
             PT3.MOVEIN_DATE,
             PT3.DATE_ENTERED_OPERATION,
             PT3.PLAN_CYCLE_TIME,
             PT3.PLAN_QUEUE_TIME,
             PT3.HOTLOT_QUEUE_TIME,
             PT3.PLAN_PT_TIME,
             PT3.HOTLOT_CYCLE_TIME,
             PT3.ADJUSTED_CYCLE_TIME,
             PT3.EXEC_SEQ,
             PT3.CUM_PROCESS_TIME,
             PT3.ADJ_CUM_PROCESS_TIME,
             LAG(PT3.CUM_PROCESS_TIME) OVER (PARTITION BY PT3.LOT ORDER BY PT3.LOT, PT3.EXEC_SEQ) AS PREV_CUM_PROCESS_TIME,
             
             -- catch this in case of timing issues 
             CASE
               WHEN LAG(PT3.ADJ_CUM_PROCESS_TIME) OVER (PARTITION BY PT3.LOT ORDER BY PT3.LOT, PT3.EXEC_SEQ) IS NULL THEN 0
               ELSE LAG(PT3.ADJ_CUM_PROCESS_TIME) OVER (PARTITION BY PT3.LOT ORDER BY PT3.LOT, PT3.EXEC_SEQ)
             END AS PREV_ADJ_CUM_PROCESS_TIME,
             
             --LAG(PT3.ADJ_CUM_PROCESS_TIME) OVER (PARTITION BY PT3.LOT ORDER BY PT3.LOT, PT3.EXEC_SEQ) AS PREV_ADJ_CUM_PROCESS_TIME,
             PT3.LEAD_PROCESS_TIME
      FROM
      (
      SELECT PT2.CUM_PROCESS_TIME,
             PT2.ADJ_CUM_PROCESS_TIME,
             LAG(PT2.CUM_PROCESS_TIME) OVER (PARTITION BY PT2.LOT ORDER BY PT2.LOT, PT2.EXEC_SEQ) AS LEAD_PROCESS_TIME, -- we still want to use this (not adjusted), to look ahead 3 hours of ops from NOW (not from op arrivla time)
             PT2.FACILITY,
             PT2.LOT,
             PT2.PRODUCT,
             PT2.ROUTE,
             PT2.FLOWPLAN,
             PT2.ROUTE_BASE_NAME,
             PT2.OPERATION,
             PT2.OPERATION_VERSION,
             PT2.Flow_Context,
             PT2.CURR_OPER_FLAG,
             PT2.OWNER,
             PT2.LOT_PRIORITY,
             PT2.HOTLOT,
             PT2.LOT_STATE,
             PT2.PROCESS,
             PT2.DOTPROCESS,
             PT2.WAFER_QTY,
             PT2.MOVEIN_DATE,
             PT2.DATE_ENTERED_OPERATION,
             PT2.PLAN_CYCLE_TIME,
             PT2.PLAN_QUEUE_TIME,
             PT2.HOTLOT_QUEUE_TIME,
             PT2.PLAN_PT_TIME,
             PT2.HOTLOT_CYCLE_TIME,
             PT2.ADJUSTED_CYCLE_TIME,
             PT2.EXEC_SEQ
      FROM 
      (
      SELECT SUM(PT.HOTLOT_CYCLE_TIME) OVER (PARTITION BY PT.LOT ORDER BY PT.LOT, PT.EXEC_SEQ) AS CUM_PROCESS_TIME,
             SUM(PT.ADJUSTED_CYCLE_TIME) OVER (PARTITION BY PT.LOT ORDER BY PT.LOT, PT.EXEC_SEQ) AS ADJ_CUM_PROCESS_TIME, -- adjusted time
             PT.FACILITY,
             PT.LOT,
             PT.PRODUCT,
             PT.ROUTE,
             PT.FLOWPLAN,
             PT.ROUTE_BASE_NAME,
             PT.OPERATION,
             PT.OPERATION_VERSION,
             PT.Flow_Context,
             PT.CURR_OPER_FLAG,
             PT.OWNER,
             PT.LOT_PRIORITY,
             PT.HOTLOT,
             PT.LOT_STATE,
             PT.PROCESS,
             PT.DOTPROCESS,
             PT.WAFER_QTY,
             PT.MOVEIN_DATE,
             PT.DATE_ENTERED_OPERATION,
             PT.PLAN_CYCLE_TIME,
             PT.PLAN_QUEUE_TIME,
             PT.HOTLOT_QUEUE_TIME,
             PT.PLAN_PT_TIME,
             PT.HOTLOT_CYCLE_TIME,
             PT.ADJUSTED_CYCLE_TIME, 
             PT.EXEC_SEQ
      FROM        
      (
      SELECT LF.FACILITY,
             LF.LOT,
             LF.PRODUCT,
             LF.ROUTE,
             LF.FLOWPLAN,
             LF.ROUTE_BASE_NAME,
             LF.OPERATION,
             LF.OPERATION_VERSION,
             LF.FLOW_CONTEXT,
             LF.CURR_OPER_FLAG,
             LF.OWNER,
             LF.LOT_PRIORITY,
             LF.HOTLOT,
             LF.LOT_STATE,
             LF.PROCESS,
             LF.DOTPROCESS,
             LF.WAFER_QTY,
             LF.MOVEIN_DATE,
             LF.DATE_ENTERED_OPERATION,
             LF.PLAN_CYCLE_TIME,
             LF.PLAN_QUEUE_TIME,
             LF.PLAN_QUEUE_TIME AS HOTLOT_QUEUE_TIME,
             LF.PLAN_PROCESS_TIME AS PLAN_PT_TIME,
             LF.PLAN_QUEUE_TIME + LF.PLAN_PROCESS_TIME  AS HOTLOT_CYCLE_TIME,           
             -- For the first step, if the starting time + cycle time is < sysdate (that means it is still in that op when it shuoldnt be)
             -- then use sysdate - entered operation as the defacto cycle time to prevent subsequent ops from showing ETAs in the past
             -- for other steps, just use regular hotlot cycle time
             CASE
               WHEN (LF.EXEC_SEQ = 1 AND DATE_ENTERED_OPERATION + LF.PLAN_QUEUE_TIME + LF.PLAN_PROCESS_TIME  < sysdate) THEN sysdate - DATE_ENTERED_OPERATION
               ELSE LF.PLAN_QUEUE_TIME + LF.PLAN_PROCESS_TIME
             END AS ADJUSTED_CYCLE_TIME,             
             LF.EXEC_SEQ,
             PRIO_RANK,
             PROD_RANK,
             QTY_RANK,
             MASTER_RANK,
             ROW_NUMBER() OVER (PARTITION BY FACILITY, LOT, OPERATION, PRODUCT, FLOW_CONTEXT, EXEC_SEQ ORDER BY FACILITY, LOT, OPERATION, PRODUCT, FLOW_CONTEXT, EXEC_SEQ, MASTER_RANK DESC) AS RN
      FROM (  
      SELECT LF0.FACILITY,
                   LF0.LOT,
                   LF0.PRODUCT,
                   LF0.ROUTE,
                   LF0.FLOWPLAN,
                   LF0.ROUTE_BASE_NAME,
                   LF0.OPERATION,
                   LF0.OPERATION_VERSION,
                   LF0.FLOW_CONTEXT,
                   CASE
                     WHEN LF0.CURRENT_OPERATION = LF0.OPERATION THEN 'Y'
                     ELSE 'N'
                   END AS CURR_OPER_FLAG,
                   LF0.OWNER,
                   LF0.LOT_PRIORITY,
                   LF0.HOTLOT,
                   LF0.LOT_STATE,
                   LF0.PROCESS,
                   LF0.DOTPROCESS,
                   LF0.WAFER_QTY,
                   LF0.MOVEIN_DATE,
                   LF0.DATE_ENTERED_OPERATION,
                   CASE
                     WHEN LF0.SKIP_RESULT = 'skip' then 0
                     WHEN LF0.SKIP_RESULT is not NULL then NVL(NVL(CT.CTG_DAYS, (POU.PLAN_CYCLE_TIME)), v_FallbackCycleTime / (24*60))
                     WHEN LF0.PREDICTED_SKIP_RESULT = 'skip' then 0 
                     ELSE NVL(NVL(CT.CTG_DAYS, POU.PLAN_CYCLE_TIME), v_FallbackCycleTime / (24*60))-- use POU when Xeta doesn't ahve a value. Ignore anything without an estimate
                   END as PLAN_CYCLE_TIME,  -- May not be trustworthy
                   CASE
                     WHEN LF0.SKIP_RESULT = 'skip' then 0
                     WHEN LF0.SKIP_RESULT is not NULL then NVL(NVL(NVL(PT.OVERHEAD_TIME + PT.TIME_PER_WAFER*LF0.WAFER_QTY, CT.PTG_DAYS), (POU.PLAN_CYCLE_TIME - POU.PLAN_QUEUE_TIME)), ( v_FallbackCycleTime - v_FallbackQueueTime) / (24*60))
                     WHEN LF0.PREDICTED_SKIP_RESULT = 'skip' then 0 
                     ELSE NVL(NVL(NVL(PT.OVERHEAD_TIME + PT.TIME_PER_WAFER*LF0.WAFER_QTY, CT.PTG_DAYS), (POU.PLAN_CYCLE_TIME - POU.PLAN_QUEUE_TIME)), ( v_FallbackCycleTime - v_FallbackQueueTime) / (24*60))-- use POU when Xeta doesn't ahve a value. Ignore anything without an estimate
                   END as PLAN_PROCESS_TIME,
                   CASE
                     WHEN LF0.SKIP_RESULT = 'skip' then 0
                     WHEN LF0.SKIP_RESULT is not NULL then NVL(NVL(NVL(QT.AVG_QUEUE_TIME_DAYS, CT.QTG_DAYS), POU.PLAN_QUEUE_TIME), v_FallbackQueueTime / (24 * 60))
                     WHEN LF0.PREDICTED_SKIP_RESULT = 'skip' then 0 
                     ELSE NVL(NVL(NVL(QT.AVG_QUEUE_TIME_DAYS, CT.QTG_DAYS), POU.PLAN_QUEUE_TIME), v_FallbackQueueTime / (24 * 60))-- use POU when Xeta doesn't ahve a value. Ignore anything without an estimate
                   END as PLAN_QUEUE_TIME,
                   LF0.EXEC_SEQ,
                   -- Xeta Matching Scoring
                   CASE
                     WHEN LF0.WAFER_QTY = CT.LOT_QTY THEN 4
                     ELSE 0
                   END AS QTY_RANK,                   
                   CASE
                     WHEN REPLACE(LF0.PRODUCT, ' ', '') = CT.LOT_PRODUCT THEN 2
                     ELSE 0
                   END AS PROD_RANK,
                   CASE
                     WHEN LF0.LOT_PRIORITY = CT.LOT_PRIORITY THEN 1
                     ELSE 0
                   END AS PRIO_RANK,
                   (
                   -- Wafer Qty has a higher value = 4
                     (CASE
                       WHEN LF0.WAFER_QTY = CT.LOT_QTY THEN 4
                       ELSE 0
                     END) +
                     -- Product has a higher value = 2
                     (CASE
                       WHEN REPLACE(LF0.PRODUCT, ' ','') = CT.LOT_PRODUCT THEN 2
                       ELSE 0
                     END)  +
                     -- Lot Priority has a lowest value = 1
                     (CASE
                         WHEN LF0.LOT_PRIORITY = CT.LOT_PRIORITY THEN 1
                         ELSE 0
                       END)
                   ) AS MASTER_RANK                   
      FROM(
      SELECT L.*,
             SK.SKIP_RESULT as PREDICTED_SKIP_RESULT
      FROM HBLP_LOT_FLOW_S L
      LEFT JOIN hblp_skiprate_summary_mv SK
      ON L.OPERATION = SK.OPERATION
      AND L.PRODUCT = SK.PRODUCT
      )LF0 
      LEFT JOIN
      hblp_actual_queue_time_MV QT  -- most trusted queue time
      ON QT.OPERATION = LF0.OPERATION
      LEFT JOIN hblp_actual_process_time_mv PT  -- most trusted process time
      ON PT.OPERATION = LF0.OPERATION
      LEFT JOIN XETA.I_CTG_FAB CT    -- fallback option 1
      ON LF0.OPERATION = CT.OPERATION
      AND LF0.PROCESS = CT.LOT_PROCESS
      AND LF0.OWNER = CT.LOT_TYPE
      AND REGEXP_LIKE(LF0.WAFER_QTY, REPLACE(CT.LOT_QTY, '-1', '.'))
      AND REGEXP_LIKE(LF0.LOT_PRIORITY, REPLACE(CT.LOT_PRIORITY, '-1', '.'))
      AND REGEXP_LIKE(REPLACE(LF0.PRODUCT, ' ', ''), CT.LOT_PRODUCT)      
      LEFT JOIN MS_1_F_PROCESS_OPER_UDF POU  -- fallback option 2
      ON POU.PROCESS = LF0.PROCESS
      AND POU.OPERATION = LF0.OPERATION 
      AND POU.WHAT_IF# = 1
      ORDER BY LF0.LOT,
               LF0.EXEC_SEQ
      ) LF      
      ORDER BY LF.LOT,
               LF.EXEC_SEQ
      ) PT
      WHERE PT.RN = 1  
      ) PT2
      ) PT3
      ) PT4
      WHERE PT4.LEAD_PROCESS_TIME <= v_LeadProcessTime /24;
      
      v_RowsAdded := SQL%ROWCOUNT;
      COMMIT;


      INSERT INTO HBLP_LOT_PROCESSTIME_HIST_S2
        (FACILITY,
         LOT,
         PRODUCT,
         ROUTE,
         FLOWPLAN,
         ROUTE_BASE_NAME,
         OPERATION,
         OPERATION_VERSION,
         CURR_OPER_FLAG,
         FLOW_CONTEXT,
         OWNER,
         LOT_PRIORITY,
         HOTLOT,
         LOT_STATE,
         PROCESS,
         DOTPROCESS,
         WAFER_QTY,
         MOVEIN_DATE,
         DATE_ENTERED_OPERATION,
         PLAN_CYCLE_TIME,
         PLAN_QUEUE_TIME,
         HOTLOT_QUEUE_TIME,
         PLAN_PT_TIME,
         HOTLOT_CYCLE_TIME,
         ADJUSTED_CYCLE_TIME,
         EXEC_SEQ,
         CUM_PROCESS_TIME,
         ADJ_CUM_PROCESS_TIME,
         LEAD_PROCESS_TIME,
         ORIGINAL_ETA,
         ETA,
         SNAPSHOT_DATE
         )
      SELECT FACILITY,
         LOT,
         PRODUCT,
         ROUTE,
         FLOWPLAN,
         ROUTE_BASE_NAME,
         OPERATION,
         OPERATION_VERSION,
         CURR_OPER_FLAG,
         FLOW_CONTEXT,
         OWNER,
         LOT_PRIORITY,
         HOTLOT,
         LOT_STATE,
         PROCESS,
         DOTPROCESS,
         WAFER_QTY,
         MOVEIN_DATE,
         DATE_ENTERED_OPERATION,
         PLAN_CYCLE_TIME,
         PLAN_QUEUE_TIME,
         HOTLOT_QUEUE_TIME,
         PLAN_PT_TIME,
         HOTLOT_CYCLE_TIME,
         ADJUSTED_CYCLE_TIME,
         EXEC_SEQ,
         CUM_PROCESS_TIME,
         ADJ_CUM_PROCESS_TIME,
         LEAD_PROCESS_TIME,
         ORIGINAL_ETA,
         ETA,
         v_StartTime AS SNAPSHOT_DATE
      FROM HBLP_LOT_PROCESSTIME_S2;

      COMMIT;
      -- End :: Primary PT - production version (testing version is below)


     -- Start :: Testing PT - production version (testing version is below)
      EXECUTE IMMEDIATE ('TRUNCATE TABLE HBLP_LOT_PROCESSTIME_S') ;
      COMMIT;
                  
      INSERT INTO HBLP_LOT_PROCESSTIME_S
        (FACILITY,
         LOT,
         PRODUCT,
         ROUTE,
         FLOWPLAN,
         ROUTE_BASE_NAME,
         OPERATION,
         OPERATION_VERSION,
         CURR_OPER_FLAG,
         FLOW_CONTEXT,
         OWNER,
         LOT_PRIORITY,
         HOTLOT,
         LOT_STATE,
         PROCESS,
         DOTPROCESS,
         WAFER_QTY,
         MOVEIN_DATE,
         DATE_ENTERED_OPERATION,
         PLAN_CYCLE_TIME,
         PLAN_QUEUE_TIME,
         HOTLOT_QUEUE_TIME,
         PLAN_PT_TIME,
         HOTLOT_CYCLE_TIME,
         ADJUSTED_CYCLE_TIME,
         EXEC_SEQ,
         CUM_PROCESS_TIME,
         ADJ_CUM_PROCESS_TIME,
         LEAD_PROCESS_TIME,
         ORIGINAL_ETA,
         ETA)
      SELECT PT4.FACILITY,
             PT4.LOT,
             PT4.PRODUCT,
             PT4.ROUTE,
             PT4.FLOWPLAN,
             PT4.ROUTE_BASE_NAME,
             PT4.OPERATION,
             PT4.OPERATION_VERSION,
             PT4.CURR_OPER_FLAG,
             PT4.FLOW_CONTEXT,
             PT4.OWNER,
             PT4.LOT_PRIORITY,
             PT4.HOTLOT,
             PT4.LOT_STATE,
             PT4.PROCESS,
             PT4.DOTPROCESS,
             PT4.WAFER_QTY,
             PT4.MOVEIN_DATE,
             PT4.DATE_ENTERED_OPERATION,
             PT4.PLAN_CYCLE_TIME,
             PT4.PLAN_QUEUE_TIME,
             PT4.HOTLOT_QUEUE_TIME,
             PT4.PLAN_PT_TIME,
             PT4.HOTLOT_CYCLE_TIME,
             PT4.ADJUSTED_CYCLE_TIME,
             PT4.EXEC_SEQ,
             PT4.CUM_PROCESS_TIME,
             PT4.PREV_ADJ_CUM_PROCESS_TIME AS ADJ_CUM_PROCESS_TIME,
             PT4.LEAD_PROCESS_TIME,
             PT4.PREV_CUM_PROCESS_TIME + PT4.DATE_ENTERED_OPERATION AS ORIGINAL_ETA,
             PT4.PREV_ADJ_CUM_PROCESS_TIME + PT4.DATE_ENTERED_OPERATION AS ETA
      FROM (SELECT PT3.FACILITY,
                    PT3.LOT,
                    PT3.PRODUCT,
                    PT3.ROUTE,
                    PT3.FLOWPLAN,
                    PT3.ROUTE_BASE_NAME,
                    PT3.OPERATION,
                    PT3.OPERATION_VERSION,
                    PT3.CURR_OPER_FLAG,
                    PT3.FLOW_CONTEXT,
                    PT3.OWNER,
                    PT3.LOT_PRIORITY,
                    PT3.HOTLOT,
                    PT3.LOT_STATE,
                    PT3.PROCESS,
                    PT3.DOTPROCESS,
                    PT3.WAFER_QTY,
                    PT3.MOVEIN_DATE,
                    PT3.DATE_ENTERED_OPERATION,
                    PT3.PLAN_CYCLE_TIME,
                    PT3.PLAN_QUEUE_TIME,
                    PT3.HOTLOT_QUEUE_TIME,
                    PT3.PLAN_PT_TIME,
                    PT3.HOTLOT_CYCLE_TIME,
                    PT3.ADJUSTED_CYCLE_TIME,
                    PT3.EXEC_SEQ,
                    PT3.CUM_PROCESS_TIME,
                    PT3.ADJ_CUM_PROCESS_TIME,
                    LAG(PT3.CUM_PROCESS_TIME) OVER(PARTITION BY PT3.LOT ORDER BY PT3.LOT, PT3.EXEC_SEQ) AS PREV_CUM_PROCESS_TIME,
                    LAG(PT3.ADJ_CUM_PROCESS_TIME) OVER(PARTITION BY PT3.LOT ORDER BY PT3.LOT, PT3.EXEC_SEQ) AS PREV_ADJ_CUM_PROCESS_TIME,
                    PT3.LEAD_PROCESS_TIME
             FROM (SELECT PT2.CUM_PROCESS_TIME,
                           PT2.ADJ_CUM_PROCESS_TIME,
                           LAG(PT2.CUM_PROCESS_TIME) OVER(PARTITION BY PT2.LOT ORDER BY PT2.LOT, PT2.EXEC_SEQ) AS LEAD_PROCESS_TIME, -- we still want to use this (not adjusted), to look ahead 3 hours of ops from NOW (not from op arrivla time)
                           PT2.FACILITY,
                           PT2.LOT,
                           PT2.PRODUCT,
                           PT2.ROUTE,
                           PT2.FLOWPLAN,
                           PT2.ROUTE_BASE_NAME,
                           PT2.OPERATION,
                           PT2.OPERATION_VERSION,
                           PT2.FLOW_CONTEXT,
                           PT2.CURR_OPER_FLAG,
                           PT2.OWNER,
                           PT2.LOT_PRIORITY,
                           PT2.HOTLOT,
                           PT2.LOT_STATE,
                           PT2.PROCESS,
                           PT2.DOTPROCESS,
                           PT2.WAFER_QTY,
                           PT2.MOVEIN_DATE,
                           PT2.DATE_ENTERED_OPERATION,
                           PT2.PLAN_CYCLE_TIME,
                           PT2.PLAN_QUEUE_TIME,
                           PT2.HOTLOT_QUEUE_TIME,
                           PT2.PLAN_PT_TIME,
                           PT2.HOTLOT_CYCLE_TIME,
                           PT2.ADJUSTED_CYCLE_TIME,
                           PT2.EXEC_SEQ
                    FROM (SELECT SUM(PT.HOTLOT_CYCLE_TIME) OVER(PARTITION BY PT.LOT ORDER BY PT.LOT, PT.EXEC_SEQ) AS CUM_PROCESS_TIME,
                                  SUM(PT.ADJUSTED_CYCLE_TIME) OVER(PARTITION BY PT.LOT ORDER BY PT.LOT, PT.EXEC_SEQ) AS ADJ_CUM_PROCESS_TIME, -- adjusted time
                                  PT.FACILITY,
                                  PT.LOT,
                                  PT.PRODUCT,
                                  PT.ROUTE,
                                  PT.FLOWPLAN,
                                  PT.ROUTE_BASE_NAME,
                                  PT.OPERATION,
                                  PT.OPERATION_VERSION,
                                  PT.FLOW_CONTEXT,
                                  PT.CURR_OPER_FLAG,
                                  PT.OWNER,
                                  PT.LOT_PRIORITY,
                                  PT.HOTLOT,
                                  PT.LOT_STATE,
                                  PT.PROCESS,
                                  PT.DOTPROCESS,
                                  PT.WAFER_QTY,
                                  PT.MOVEIN_DATE,
                                  PT.DATE_ENTERED_OPERATION,
                                  PT.PLAN_CYCLE_TIME,
                                  PT.PLAN_QUEUE_TIME,
                                  PT.HOTLOT_QUEUE_TIME,
                                  PT.PLAN_PT_TIME,
                                  PT.HOTLOT_CYCLE_TIME,
                                  PT.ADJUSTED_CYCLE_TIME,
                                  PT.EXEC_SEQ
                           FROM (SELECT LF.FACILITY,
                                         LF.LOT,
                                         LF.PRODUCT,
                                         LF.ROUTE,
                                         LF.FLOWPLAN,
                                         LF.ROUTE_BASE_NAME,
                                         LF.OPERATION,
                                         LF.OPERATION_VERSION,
                                         LF.FLOW_CONTEXT,
                                         LF.CURR_OPER_FLAG,
                                         LF.OWNER,
                                         LF.LOT_PRIORITY,
                                         LF.HOTLOT,
                                         LF.LOT_STATE,
                                         LF.PROCESS,
                                         LF.DOTPROCESS,
                                         LF.WAFER_QTY,
                                         LF.MOVEIN_DATE,
                                         LF.DATE_ENTERED_OPERATION,
                                         LF.PLAN_CYCLE_TIME,
                                         LF.PLAN_QUEUE_TIME,
                                         LF.PLAN_QUEUE_TIME AS HOTLOT_QUEUE_TIME,
                                         LF.PLAN_PROCESS_TIME AS PLAN_PT_TIME,
                                         LF.PLAN_QUEUE_TIME + LF.PLAN_PROCESS_TIME AS HOTLOT_CYCLE_TIME,
                                         -- For the first step, if the starting time + cycle time is < sysdate (that means it is still in that op when it shuoldnt be)
                                         -- then use sysdate - entered operation as the defacto cycle time to prevent subsequent ops from showing ETAs in the past
                                         -- for other steps, just use regular hotlot cycle time
                                         CASE  --TIME_REMAINING
                                           WHEN LF.EXEC_SEQ = MIN(EXEC_SEQ) OVER (PARTITION BY LF.LOT) THEN SYSDATE - DATE_ENTERED_OPERATION + LF.TIME_REMAINING
                                             
                                          -- SYDATE - TIME ENTERED OP + remiaining
                                          -- WHEN (LF.EXEC_SEQ = 1 AND DATE_ENTERED_OPERATION + LF.PLAN_QUEUE_TIME + LF.PLAN_PROCESS_TIME  < sysdate) THEN sysdate - DATE_ENTERED_OPERATION
                                           ELSE LF.PLAN_QUEUE_TIME + LF.PLAN_PROCESS_TIME
                                         END AS ADJUSTED_CYCLE_TIME,
                                         LF.EXEC_SEQ,
                                         PRIO_RANK,
                                         PROD_RANK,
                                         QTY_RANK,
                                         MASTER_RANK,
                                         ROW_NUMBER() OVER(PARTITION BY FACILITY, LOT, OPERATION, PRODUCT, FLOW_CONTEXT, EXEC_SEQ ORDER BY FACILITY, LOT, OPERATION, PRODUCT, FLOW_CONTEXT, EXEC_SEQ, MASTER_RANK DESC) AS RN
                                  FROM (SELECT LF0.FACILITY,
                                                LF0.LOT,
                                                LF0.PRODUCT,
                                                LF0.ROUTE,
                                                LF0.FLOWPLAN,
                                                LF0.ROUTE_BASE_NAME,
                                                LF0.OPERATION,
                                                LF0.OPERATION_VERSION,
                                                LF0.FLOW_CONTEXT,
                                                CASE
                                                  WHEN LF0.CURRENT_OPERATION = LF0.OPERATION THEN 'Y'
                                                  ELSE 'N'
                                                END AS CURR_OPER_FLAG,
                                                LF0.OWNER,
                                                LF0.LOT_PRIORITY,
                                                LF0.HOTLOT,
                                                LF0.LOT_STATE,
                                                LF0.PROCESS,
                                                LF0.DOTPROCESS,
                                                LF0.WAFER_QTY,
                                                LF0.MOVEIN_DATE,
                                                LF0.DATE_ENTERED_OPERATION,
                                                CASE
                                                   WHEN LF0.SKIP_RESULT = 'skip' THEN
                                                    0
                                                   WHEN LF0.SKIP_RESULT IS NOT NULL THEN
                                                    NVL(NVL(CT.CTG_DAYS, (POU.PLAN_CYCLE_TIME)), v_FALLBACKCYCLETIME / (24 * 60))
                                                   WHEN LF0.PREDICTED_SKIP_RESULT = 'skip' THEN
                                                    0
                                                   ELSE
                                                    NVL(NVL(CT.CTG_DAYS, POU.PLAN_CYCLE_TIME), v_FALLBACKCYCLETIME / (24 * 60)) -- use POU when Xeta doesn't ahve a value. Ignore anything without an estimate
                                           END AS PLAN_CYCLE_TIME, -- May not be trustworthy
                                           CASE
                                              WHEN LF0.SKIP_RESULT = 'skip' THEN
                                               0
                                              WHEN LF0.SKIP_RESULT IS NOT NULL THEN
                                               NVL(NVL(NVL(PT.OVERHEAD_TIME + PT.TIME_PER_WAFER * LF0.WAFER_QTY, CT.PTG_DAYS), (POU.PLAN_CYCLE_TIME -
                                                        POU.PLAN_QUEUE_TIME)),  (v_FALLBACKCYCLETIME - v_FALLBACKQUEUETIME) / (24 * 60))
                                              WHEN LF0.PREDICTED_SKIP_RESULT = 'skip' THEN
                                               0
                                              ELSE
                                               NVL(NVL(NVL(PT.OVERHEAD_TIME + PT.TIME_PER_WAFER * LF0.WAFER_QTY, CT.PTG_DAYS), (POU.PLAN_CYCLE_TIME -
                                                        POU.PLAN_QUEUE_TIME)), (v_FALLBACKCYCLETIME - v_FALLBACKQUEUETIME) / (24 * 60)) -- use POU when Xeta doesn't ahve a value. Ignore anything without an estimate
                                                END AS PLAN_PROCESS_TIME,
                                                CASE
                                                   WHEN LF0.SKIP_RESULT = 'skip' THEN
                                                    0
                                                   WHEN LF0.SKIP_RESULT IS NOT NULL THEN
                                                    NVL(NVL(NVL(QT.AVG_QUEUE_TIME_DAYS, CT.QTG_DAYS), POU.PLAN_QUEUE_TIME), v_FALLBACKQUEUETIME /
                                                         (24 * 60))
                                                   WHEN LF0.PREDICTED_SKIP_RESULT = 'skip' THEN
                                                    0
                                                   ELSE
                                                    NVL(NVL(NVL(QT.AVG_QUEUE_TIME_DAYS, CT.QTG_DAYS), POU.PLAN_QUEUE_TIME), v_FALLBACKQUEUETIME /
                                                         (24 * 60)) -- use POU when Xeta doesn't ahve a value. Ignore anything without an estimate
                                           END AS PLAN_QUEUE_TIME,
                                           LF0.EXEC_SEQ,
                                           -- Xeta Matching Scoring
                                           CASE
                                             WHEN LF0.WAFER_QTY = CT.LOT_QTY THEN
                                              4
                                             ELSE
                                              0
                                           END AS QTY_RANK,
                                           CASE
                                             WHEN REPLACE(LF0.PRODUCT, ' ', '') = CT.LOT_PRODUCT THEN
                                              2
                                             ELSE
                                              0
                                           END AS PROD_RANK,
                                           CASE
                                             WHEN LF0.LOT_PRIORITY = CT.LOT_PRIORITY THEN
                                              1
                                             ELSE
                                              0
                                           END AS PRIO_RANK,
                                           (
                                           -- Wafer Qty has a higher value = 4
                                            (CASE
                                              WHEN LF0.WAFER_QTY = CT.LOT_QTY THEN
                                               4
                                              ELSE
                                               0
                                            END) +
                                           -- Product has a higher value = 2
                                            (CASE
                                              WHEN REPLACE(LF0.PRODUCT, ' ', '') = CT.LOT_PRODUCT THEN
                                               2
                                              ELSE
                                               0
                                            END) +
                                           -- Lot Priority has a lowest value = 1
                                            (CASE
                                              WHEN LF0.LOT_PRIORITY = CT.LOT_PRIORITY THEN
                                               1
                                              ELSE
                                               0
                                            END)) AS MASTER_RANK,
                                            CO.R2A_TIME_REMAINING/(24*60) AS TIME_REMAINING   -- Model used - cahnge here when Model changes
                                    FROM (SELECT L.*,
                                                 SK.SKIP_RESULT AS PREDICTED_SKIP_RESULT
                                          FROM HBLP_LOT_FLOW_S L
                                          LEFT JOIN HBLP_SKIPRATE_SUMMARY_MV SK
                                          ON L.OPERATION = SK.OPERATION
                                          AND L.PRODUCT = SK.PRODUCT) LF0
                                          
                                    -- Current Opeartion Queue and Process Time
                                    LEFT JOIN HBLP_LOT_MODELED_PT CO 
                                    ON CO.LOT = LF0.LOT
                                    AND CO.OPERATION = LF0.OPERATION
                                    
                                    -- fallback option 1
                                    -- Actual Hot Lot Queue Times     
                                    LEFT JOIN HBLP_ACTUAL_QUEUE_TIME_MV QT 
                                    ON QT.OPERATION = LF0.OPERATION
                                    
                                    -- fallback option 1
                                    -- Actual Hot Lot Process Times 
                                    LEFT JOIN HBLP_ACTUAL_PROCESS_TIME_MV PT 
                                    ON PT.OPERATION = LF0.OPERATION
                                    
                                    -- fallback option 2
                                    -- Xeta Queue and Process Times
                                    LEFT JOIN XETA.I_CTG_FAB CT 
                                    ON LF0.OPERATION = CT.OPERATION
                                    AND LF0.PROCESS = CT.LOT_PROCESS
                                    AND LF0.OWNER = CT.LOT_TYPE
                                    AND REGEXP_LIKE(LF0.WAFER_QTY, REPLACE(CT.LOT_QTY, '-1', '.'))
                                    AND REGEXP_LIKE(LF0.LOT_PRIORITY, REPLACE(CT.LOT_PRIORITY, '-1', '.'))
                                    AND REGEXP_LIKE(REPLACE(LF0.PRODUCT, ' ', ''), CT.LOT_PRODUCT)
                                    
                                    -- fallback option 3
                                    -- Process Oper UDF Queue and Process Times
                                    LEFT JOIN MS_1_F_PROCESS_OPER_UDF POU 
                                    ON POU.PROCESS = LF0.PROCESS
                                    AND POU.OPERATION = LF0.OPERATION
                                    AND POU.WHAT_IF# = 1
                                    ORDER BY LF0.LOT,
                                             LF0.EXEC_SEQ) LF
                              ORDER BY LF.LOT,
                                       LF.EXEC_SEQ) PT
                        WHERE PT.RN = 1) PT2) PT3) PT4
                        WHERE PT4.LEAD_PROCESS_TIME <= v_LEADPROCESSTIME / 24;
      
      COMMIT;


      INSERT INTO HBLP_LOT_PROCESSTIME_HIST_S
        (FACILITY,
         LOT,
         PRODUCT,
         ROUTE,
         FLOWPLAN,
         ROUTE_BASE_NAME,
         OPERATION,
         OPERATION_VERSION,
         CURR_OPER_FLAG,
         FLOW_CONTEXT,
         OWNER,
         LOT_PRIORITY,
         HOTLOT,
         LOT_STATE,
         PROCESS,
         DOTPROCESS,
         WAFER_QTY,
         MOVEIN_DATE,
         DATE_ENTERED_OPERATION,
         PLAN_CYCLE_TIME,
         PLAN_QUEUE_TIME,
         HOTLOT_QUEUE_TIME,
         PLAN_PT_TIME,
         HOTLOT_CYCLE_TIME,
         ADJUSTED_CYCLE_TIME,
         EXEC_SEQ,
         CUM_PROCESS_TIME,
         ADJ_CUM_PROCESS_TIME,
         LEAD_PROCESS_TIME,
         ORIGINAL_ETA,
         ETA,
         SNAPSHOT_DATE
         )
      SELECT FACILITY,
         LOT,
         PRODUCT,
         ROUTE,
         FLOWPLAN,
         ROUTE_BASE_NAME,
         OPERATION,
         OPERATION_VERSION,
         CURR_OPER_FLAG,
         FLOW_CONTEXT,
         OWNER,
         LOT_PRIORITY,
         HOTLOT,
         LOT_STATE,
         PROCESS,
         DOTPROCESS,
         WAFER_QTY,
         MOVEIN_DATE,
         DATE_ENTERED_OPERATION,
         PLAN_CYCLE_TIME,
         PLAN_QUEUE_TIME,
         HOTLOT_QUEUE_TIME,
         PLAN_PT_TIME,
         HOTLOT_CYCLE_TIME,
         ADJUSTED_CYCLE_TIME,
         EXEC_SEQ,
         CUM_PROCESS_TIME,
         ADJ_CUM_PROCESS_TIME,
         LEAD_PROCESS_TIME,
         ORIGINAL_ETA,
         ETA,
         v_StartTime AS SNAPSHOT_DATE
      FROM HBLP_LOT_PROCESSTIME_S;

      COMMIT;
      -- End :: Testing PT - production version (testing version is below)
      
  v_ElapsedTime := ROUND((SYSDATE - v_StartTime) * 24 * 60 *60);      
  -- Write to ExtractMetrics
  SP$LOG_METRICS
    (
        p_ExtractName => c_PROCEDURE_NAME,
        p_ExtractStartDate => v_StartTime,
        p_ExtractEndDate => SYSDATE,
        p_RunStartDate => v_StartTime,
        p_RunEndDate => SYSDATE,
        p_RecordsAdded => v_RowsAdded,
        p_Status => 'SUCCESS'
     );

  -- Write to Logfile
   SP$LOG_ME(c_PROCEDURE_NAME || ': Success with ' || TO_CHAR(v_RowsAdded) || ' Rows added in ' || TO_CHAR(v_ElapsedTime) || ' seconds' );

  EXCEPTION
    WHEN OTHERS
    THEN
      DECLARE
         v_ErrorCode NUMBER := SQLCODE;
         v_ErrorMessage VARCHAR2(300) := SQLERRM;
         v_Comments VARCHAR2(500);
      BEGIN

         ROLLBACK;

         v_COMMENTS := SUBSTR(v_ErrorCode || ' - ' || v_ErrorMessage || ' - ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 0, 500);

        SP$LOG_ME(c_PROCEDURE_NAME || ' - Error: '|| v_Comments);
        SP$LOG_METRICS(c_PROCEDURE_NAME, v_StartTime, SYSDATE, v_StartTime, SYSDATE,0 , 0, 'FAILURE', v_Comments);

   END;

END SP$LOTFLOW_PROCESSTIME;
