-- REFERENCE ONLY: exact procedure body excerpt; not a standalone SQL script.
PROCEDURE SP$LOT_EVENT_STATUS

IS

  c_PROCEDURE_NAME CONSTANT MC_1_F_EXTRACTMETRICS.EXTRACT_NAME%TYPE := 'SP$LOT_EVENT_STATUS';
  v_RowsAdded NUMBER;
  v_StartTime DATE := SYSDATE;
  v_ElapsedTime NUMBER;
  v_RollupStart DATE;
  v_RollupEnd DATE;
  
BEGIN

      v_RollupEnd := FN$GET_LH_LAST_LOAD_DATE;  -- Capture the latest Well Load for the NTSC tables
      v_RollupStart := v_RollupEnd - 1/2;
      
      -- Step 1: Capture the entities associated with the operation at which the lots will be arriving

      EXECUTE IMMEDIATE ('TRUNCATE TABLE HBLP_LOT_EVENT_STATUS') ;
      COMMIT;      

      INSERT INTO HBLP_LOT_EVENT_STATUS
        (FACILITY,
         LOT,
         PRODUCT,
         PROCESS,
         OWNER,
         ROUTE,
         WAFERS,
         OPERATION,
         NTSC_ENTITY,
         QUEUED_ENTITY,
         PREVOUT_DATE,
         MOQ_DATE,
         INTRODUCE_TXN_DATE,
         BEGINMOUNT_TXN_DATE,
         ENDMOUNT_TXN_DATE,
         IN_DATE,
         RUN_TXN_DATE,
         FIRST_WAFER_START_TIME,
         LAST_WAFER_END_TIME,
         END_TXN_DATE,
         ABORT_TXN_DATE,
         START_DISMOUNT_TXN_DATE,
         END_DISMOUNT_TXN_DATE,
         OUT_DATE,
         RUNID,
         QUEUEORDER,
         LOTPOSITION,
         LOADPORT_QTY,
         WATERMARK,
         LOCATION,
         LAST_UPDATE_DATE)
         
       WITH ENT_OPER_ASSOC AS 
(
  SELECT /*+ px_join_filter(EO) */ OP.*,
         ENT.ENTITY
  FROM (SELECT OPERATION FROM HBLP_FLOW_CONTEXT_S GROUP BY OPERATION) OP
  LEFT JOIN MC_1_F_ENTITYOPER EO
  ON OP.OPERATION = EO.OPERATION
  AND EO.SRC_ERASE_DATE IS NULL
  LEFT JOIN MC_1_F_ENTITY ENT
  ON EO.ENTITY = ENT.ENTITY
  AND ENT.ENTITY = ENT.PARENT_ENTITY
  WHERE ENT.ENTITY IS NOT NULL
),

LH3 AS 
(
SELECT LH2.*
             FROM (SELECT  LH.FACILITY,
                           LH.LOT,
                           LH.PRODUCT,
                           LH.OWNER,
                           LH.ROUTE,
                           LH.OLDQTY1 AS WAFERS,
                           SUBSTR(LH.DOTPROCESS, 1, 4) AS PROCESS,
                           LH.OPERATION,
                           LH.PREVOUT_DATE,
                           LH.IN_DATE,
                           LH.OUT_DATE,
                           MAX(LH.PREVOUT_DATE) OVER(PARTITION BY LH.FACILITY, LH.LOT) AS LATEST_PREVOUT,
                           LH.LOCATION_OLD AS LOCATION
                    FROM MC_1_F_LOTHIST LH
                    INNER JOIN HBLP_FLOW_CONTEXT_S FC
                    ON LH.LOT = FC.LOT 
                    AND LH.OPERATION = FC.OPERATION
                    WHERE LH.HISTORY_DELETED_FLAG != 'Y'
              ) LH2
              WHERE LH2.PREVOUT_DATE = LH2.LATEST_PREVOUT
),

LOT_NTSC_STATUS AS 
(
SELECT LH2.*
                   FROM (SELECT LH1.FACILITY,
                                LH1.ENTITY,
                                LH1.LOT,
                                LH1.OPERATION,
                                LH1.PREVOUT_DATE,
                                MIN(LH1.INTRODUCE_TXN_DATE) AS INTRODUCE_TXN_DATE,
                                MIN(LH1.BEGINMOUNT_TXN_DATE) AS BEGINMOUNT_TXN_DATE,
                                MAX(LH1.ENDMOUNT_TXN_DATE) AS ENDMOUNT_TXN_DATE,
                                MIN(LH1.RUN_TXN_DATE) AS RUN_TXN_DATE,
                                MAX(LH1.END_TXN_DATE) AS END_TXN_DATE,
                                MAX(LH1.ABORT_TXN_DATE) AS ABORT_TXN_DATE,
                                MIN(LH1.START_DISMOUNT_TXN_DATE) AS START_DISMOUNT_TXN_DATE,
                                MAX(LH1.END_DISMOUNT_TXN_DATE) AS END_DISMOUNT_TXN_DATE,
                                LH1.RUNID,
                                MAX(PREVOUT_DATE) OVER(PARTITION BY FACILITY, LOT) AS LATEST_PREVOUT
                         FROM (SELECT /*+PARALLEL(4) LEADING(FC,EOA,NLH) USE_NL(EOA,NLH) INDEX(NLH,XIE10F_NTSC_LOTHIST)*/ FC.FACILITY,
                                      NLH.ENTITY,
                                      NLH.LOT,
                                      NLH.OPERATION,
                                      NLH.PREVOUT_DATE,
                                      NLH.TXN_DATE,
                                      DECODE(NLH.STATE, 'INTRODUCE', NLH.TXN_DATE, NULL) AS INTRODUCE_TXN_DATE,
                                       DECODE(NLH.STATE, 'BEGIN-MOUNT', NLH.TXN_DATE, NULL) AS BEGINMOUNT_TXN_DATE,
                                       DECODE(NLH.STATE, 'END-MOUNT', NLH.TXN_DATE, NULL) AS ENDMOUNT_TXN_DATE,
                                       DECODE(NLH.STATE, 'END', NLH.TXN_DATE, NULL) AS END_TXN_DATE,
                                       DECODE(NLH.STATE, 'RUN', NLH.TXN_DATE, NULL) AS RUN_TXN_DATE,
                                       DECODE(NLH.STATE, 'ABORT', NLH.TXN_DATE, NULL) AS ABORT_TXN_DATE,
                                       DECODE(NLH.STATE, 'START-DISMOUNT', NLH.TXN_DATE, NULL) AS START_DISMOUNT_TXN_DATE,
                                       DECODE(NLH.STATE, 'END-DISMOUNT', NLH.TXN_DATE, NULL) AS END_DISMOUNT_TXN_DATE,
                                      NLH.STATE,
                                      NLH.PORT,
                                      NLH.RUNID
                               FROM MC_1_F_NTSC_LOTHIST NLH,
                                    HBLP_FLOW_CONTEXT_S FC,
                                    ENT_OPER_ASSOC EOA
                               WHERE NLH.LOT = FC.LOT
                               AND TXN_DATE < v_RollupEnd  -- ENsures we do not pickup events taht have not been processed by WELL
                              -- AND NEXT_TXN_DATE IS NULL --next txn null means it is in the current state
                               AND (NEXT_TXN_DATE >= v_RollupStart OR NEXT_TXN_DATE IS NULL) 
                               AND STATE IN ('INTRODUCE', 'BEGIN-MOUNT', 'END-MOUNT', 'RUN', 'END', 'ABORT', 'START-DISMOUNT', 'END-DISMOUNT')
                               AND PREVOUT_DATE IS NOT NULL
                               AND EOA.OPERATION = NLH.OPERATION
                               AND EOA.ENTITY = NLH.ENTITY
                               ) LH1
                         GROUP BY LH1.FACILITY,
                                  LH1.ENTITY,
                                  LH1.LOT,
                                  LH1.OPERATION,
                                  LH1.PREVOUT_DATE,
                                  LH1.RUNID) LH2
                                  WHERE ABORT_TXN_DATE is null
),

WAFER_PROC_STATUS AS 
(SELECT WH2.ENTITY,
                          WH2.LOT,
                          WH2.OPERATION,
                          WH2.LOTRUNID,
                          PREVOUT_DATE,
                          FIRST_WAFER_START_TIME,
                          CASE
                            WHEN CHAMBER_PROCESS_CHECK = 'Processing' THEN NULL
                            WHEN LOT_PROCESSING = 'Y' THEN NULL
                            WHEN WAFERS_SEEN < WAFER_QTY THEN NULL
                            ELSE LAST_WAFER_END_TIME
                          END AS LAST_WAFER_END_TIME
                   FROM (
                         SELECT WH.ENTITY,
                                WH.LOT,
                                WH.OPERATION,
                                WH.LOTRUNID,
                                CAST(WH.PREVOUT_DATE AS DATE) AS PREVOUT_DATE,
                                CAST(MIN(TXN_DATE) AS DATE) AS FIRST_WAFER_START_TIME,
                                -- now that we are looking at complete events, we can't use next txn date
                                CAST(MAX(TXN_DATE) AS DATE) AS LAST_WAFER_END_TIME,
                                MAX(PREVOUT_DATE) OVER(PARTITION BY LOT) AS LATEST_LOT_PREVOUT,
                                MAX(WAFER_PROCESSING) AS LOT_PROCESSING,
                                COUNT(distinct waferslotnum) as WAFERS_SEEN,
                                MAX(MIN_STATE) AS CHAMBER_PROCESS_CHECK,
                                MAX(WAFER_QTY) AS WAFER_QTY
                         FROM (
                         SELECT /*+ INDEX(WH0 XIE2F_NTSC_WAFERHIST)*/
                                WH0.*,
                                MIN(WH0.STATE) OVER (PARTITION BY WH0.ENTITY, WH0.LOT, WH0.OPERATION, WH0.PREVOUT_DATE, WH0.LOTRUNID, CHAMBER) AS MIN_STATE,
                                CASE
                                  WHEN WH0.STATE = 'Processing' AND WH0.NEXT_TXN_DATE IS NULL THEN 'Y'
                                  ELSE NULL
                                END AS WAFER_PROCESSING,
                                LH3.WAFERS AS WAFER_QTY
                               FROM MC_1_F_NTSC_WAFERHIST WH0,
                                    LH3,
                                    ENT_OPER_ASSOC EOA
                               WHERE WH0.TXN_DATE < v_RollupEnd 
                               AND (WH0.NEXT_TXN_DATE >= v_RollupStart OR WH0.NEXT_TXN_DATE IS NULL)
                               AND WH0.LOT = LH3.LOT
                               AND WH0.OPERATION = LH3.OPERATION
                               AND WH0.PREVOUT_DATE = LH3.PREVOUT_DATE 
                               AND EOA.OPERATION = WH0.OPERATION
                               AND EOA.ENTITY = WH0.ENTITY 
                               ) WH
                         GROUP BY WH.ENTITY,
                                  WH.LOT,
                                  WH.OPERATION,
                                  WH.PREVOUT_DATE,
                                  WH.LOTRUNID
                                  ) WH2
                   WHERE LATEST_LOT_PREVOUT = PREVOUT_DATE
),

MOQ AS 
(
          SELECT /*+INDEX(M XPKF_ENTITY_MOQ)*/
                 M.ENTITY,
                 M.LOT,
                 M.OPERATION,
                 MAX(NVL(REPLACE(M.QUEUEORDER,' ', ''),0)) AS QUEUEORDER,
                 MAX(NVL(REPLACE(M.LOTPOSITION,' ', ''),0)) AS LOTPOSITION,
                 MAX(M.CREATION_DATE) AS CREATION_DATE
          FROM MS_1_F_ENTITY_MOQ M,
               HBLP_FLOW_CONTEXT_S FC
          WHERE M.LOT = FC.LOT
          GROUP BY M.ENTITY,
                   M.LOT,
                   M.OPERATION
),

WM AS 
( SELECT DISTINCT 
                   --FE.FACILITY,
                   MOQ.ENTITY AS ENTITY,
                   NVL(REPLACE(LP.ATTRIBUTE_VALUE,' ', ''),0) AS LOADPORT_QTY,
                   NVL(REPLACE(WM.ATTRIBUTE_VALUE,' ', ''),0) AS WATERMARK
            FROM MC_1_F_ENTITYATTRIBUTEVALUE LP,
                 MC_1_F_ENTITYATTRIBUTEVALUE WM,
                 MOQ
            WHERE MOQ.ENTITY = LP.ENTITY
            AND  MOQ.ENTITY = WM.ENTITY
            AND WM.ATTRIBUTE_NAME = 'EMOQWaterMarkForL8'
            AND LP.ATTRIBUTE_NAME = 'NumLoadPorts'
)


       SELECT  LH3.FACILITY,
               LH3.LOT,
               LH3.PRODUCT,
               LH3.PROCESS,
               LH3.OWNER,
               LH3.ROUTE,
               LH3.WAFERS,
               LH3.OPERATION,
               NTSC.ENTITY as NTSC_ENTITY,
               MOQ.ENTITY as QUEUED_ENTITY,
               LH3.PREVOUT_DATE,
               MOQ.CREATION_DATE as MOQ_DATE,
               NTSC.INTRODUCE_TXN_DATE,
               NTSC.BEGINMOUNT_TXN_DATE,
               NTSC.ENDMOUNT_TXN_DATE,
               LH3.IN_DATE,
               NTSC.RUN_TXN_DATE,
               WH3.FIRST_WAFER_START_TIME,
               WH3.LAST_WAFER_END_TIME,
               NTSC.END_TXN_DATE,
               NTSC.ABORT_TXN_DATE,
               NTSC.START_DISMOUNT_TXN_DATE,
               NTSC.END_DISMOUNT_TXN_DATE,
               LH3.OUT_DATE,
               NTSC.RUNID,
               MOQ.QUEUEORDER,
               MOQ.LOTPOSITION,
               WM.LOADPORT_QTY,
               WM.WATERMARK,
               LH3.LOCATION,
               SYSDATE AS LAST_UPDATE_DATE
        FROM LH3
        LEFT JOIN LOT_NTSC_STATUS NTSC
        ON LH3.FACILITY = NTSC.FACILITY
        AND LH3.LOT = NTSC.LOT
        AND LH3.OPERATION = NTSC.OPERATION
        AND (LH3.PREVOUT_DATE = NTSC.PREVOUT_DATE OR NTSC.INTRODUCE_TXN_DATE > LH3.PREVOUT_DATE)
        
        -- LAST WAFER END TIME
        LEFT JOIN WAFER_PROC_STATUS WH3
        ON LH3.LOT = WH3.LOT
        AND LH3.OPERATION = WH3.OPERATION
        AND LH3.PREVOUT_DATE = WH3.PREVOUT_DATE
        AND NTSC.ENTITY = WH3.ENTITY
        AND NTSC.RUNID = WH3.LOTRUNID
        
        -- Get MOQ data
        LEFT JOIN MOQ
        ON LH3.LOT = MOQ.LOT
        AND (NTSC.ENTITY = MOQ.ENTITY OR NTSC.ENTITY IS NULL)
        AND LH3.OPERATION = MOQ.OPERATION
        AND MOQ.CREATION_DATE > LH3.PREVOUT_DATE - 5/(24* 60)
        
        -- GET WATERMARK AND LOADPORT DATA
        LEFT JOIN WM
        ON MOQ.ENTITY = WM.ENTITY;


      v_RowsAdded := SQL%ROWCOUNT;

      COMMIT;
      
      
      
  v_ElapsedTime := ROUND((SYSDATE - v_StartTime) * 24 * 60 *60);

  -- Write to ExtractMetrics
  SP$LOG_METRICS
    (
        p_ExtractName => c_PROCEDURE_NAME,
        p_ExtractStartDate => v_StartTime,
        p_ExtractEndDate => SYSDATE,
        p_RunStartDate => v_StartTime,
        p_RunEndDate => SYSDATE,
        p_RecordsAdded => v_RowsAdded,
        p_Status => 'SUCCESS'
     );

  -- Write to Logfile
   SP$LOG_ME(c_PROCEDURE_NAME || ': Success with ' || TO_CHAR(v_RowsAdded) || ' Rows added in ' || TO_CHAR(v_ElapsedTime) || ' seconds' );

  EXCEPTION
    WHEN OTHERS
    THEN
      DECLARE
         v_ErrorCode NUMBER := SQLCODE;
         v_ErrorMessage VARCHAR2(300) := SQLERRM;
         v_Comments VARCHAR2(500);
      BEGIN

         ROLLBACK;

         v_COMMENTS := SUBSTR(v_ErrorCode || ' - ' || v_ErrorMessage || ' - ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 0, 500);

        SP$LOG_ME(c_PROCEDURE_NAME || ' - Error: '|| v_Comments);
        SP$LOG_METRICS(c_PROCEDURE_NAME, v_StartTime, SYSDATE, v_StartTime, SYSDATE,0 , 0, 'FAILURE', v_Comments);

   END;

END SP$LOT_EVENT_STATUS;
