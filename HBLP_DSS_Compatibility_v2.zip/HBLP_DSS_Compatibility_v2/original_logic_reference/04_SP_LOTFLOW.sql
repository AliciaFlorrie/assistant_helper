-- REFERENCE ONLY: exact procedure body excerpt; not a standalone SQL script.
PROCEDURE SP$LOTFLOW

IS

  c_PROCEDURE_NAME CONSTANT MC_1_F_EXTRACTMETRICS.EXTRACT_NAME%TYPE := 'SP$LOTFLOW';
  v_RowsAdded NUMBER;
  v_StartTime DATE := SYSDATE;
  v_ElapsedTime NUMBER;
  
BEGIN

      EXECUTE IMMEDIATE ('TRUNCATE TABLE HBLP_LOT_FLOW_S') ;
      COMMIT;

      --Lot Flow (based on flow context)
      INSERT INTO HBLP_LOT_FLOW_S
        (FACILITY,
         LOT,
         PRODUCT,
         FLOWPLAN,
         FLOWPLAN_VERSION,
         ROUTE,
         ROUTE_BASE_NAME,
         ROUTE_VERSION,
         CURRENT_OPERATION,
         OPERATION,
         ROUTEOPER_SEQNO,
         OPERATION_VERSION,
         FLOW_CONTEXT,
         REWORK_RETURN_CONTEXT,
         OWNER,
         LOT_PRIORITY,
         ONHOLD,
         ONREWORK,
         TERMINATED,
         HOTLOT,
         LOT_STATE,
         PROCESS,
         DOTPROCESS,
         WAFER_QTY,
         MOVEIN_DATE,
         DATE_ENTERED_OPERATION,
         FRO_FLOW_CONTEXT,
         FRO_PLAN_SEQUENCE,
         FRO_FLOWPLAN,
         FRO_FLOWPLAN_VERSION,
         FLOW_ALGORITHM,
         SKIP_RESULT,
         EXEC_SEQ)


SELECT  LF1.FACILITY,
        LF1.LOT,
        LF1.PRODUCT,
        LF1.FLOWPLAN,
        LF1.FLOWPLAN_VERSION,
        LF1.ROUTE,
        LF1.ROUTE_BASE_NAME,
        LF1.ROUTE_VERSION,
        LF1.OPERATION AS CURRENT_OPERATION,
        LF1.OPERATION,
        LF1.ROUTEOPER_SEQNO,
        LF1.OPERATION_VERSION,
        LF1.FLOW_CONTEXT,
        LF1.REWORK_RETURN_CONTEXT,
        LF1.OWNER,
        LF1.LOT_PRIORITY,
        LF1.ONHOLD,
        LF1.ONREWORK,
        LF1.TERMINATED,
        LF1.HOTLOT,
        LF1.LOT_STATE,
        LF1.PROCESS,
        LF1.DOTPROCESS,
        LF1.WAFER_QTY,
        LF1.MOVEIN_DATE,
        LF1.DATE_ENTERED_OPERATION,
        LF1.FRO_FLOW_CONTEXT,
        LF1.FRO_PLAN_SEQUENCE,
        LF1.FRO_FLOWPLAN,
        LF1.FRO_FLOWPLAN_VERSION,
        LF1.FLOW_ALGORITHM,
        S.RESULT as SKIP_RESULT,
        LF1.EXEC_SEQ

      -- Get the Flow when the Lot is on a Rework Route 
FROM(SELECT LF.FACILITY,
             LF.LOT,
             LF.PRODUCT,
             LF.FLOWPLAN,
             LF.FLOWPLAN_VERSION,
             LF.ROUTE,
             LF.ROUTE_BASE_NAME,
             LF.ROUTE_VERSION,
             LF.OPERATION AS CURRENT_OPERATION,
             RO.OPERATION,
             NULL AS ROUTEOPER_SEQNO,
             LF.OPERATION_VERSION,
             LF.FLOW_CONTEXT,
             LF.REWORK_RETURN_CONTEXT,
             LF.OWNER,
             LF.LOT_PRIORITY,
             LF.ONHOLD,
             LF.ONREWORK,
             LF.TERMINATED,
             LF.HOTLOT,
             LF.LOT_STATE,
             LF.PROCESS,
             LF.DOTPROCESS,
             LF.WAFER_QTY,
             LF.MOVEIN_DATE,
             LF.DATE_ENTERED_OPERATION,
             LF.FRO_FLOW_CONTEXT,
             LF.FRO_PLAN_SEQUENCE,
             LF.FRO_FLOWPLAN,
             LF.FRO_FLOWPLAN_VERSION,
             LF.FLOW_ALGORITHM,
             ROW_NUMBER() OVER(PARTITION BY LF.LOT ORDER BY RO.ROUTEOPER_SEQNO) / 100 AS EXEC_SEQ
      FROM HBLP_FLOW_CONTEXT_S LF,
           MC_1_F_ROUTEOPER RO
      WHERE LF.FACILITY = RO.FACILITY
      AND LF.ROUTE = RO.ROUTE
      AND LF.ROUTE_VERSION = RO.ROUTE_VERSION
      AND RO.ROUTEOPER_SEQNO >= LF.FRO_CUR_SEQ  
      AND LF.ROUTE LIKE 'RW%'
      AND LF.FLOWPLAN IS NULL


       UNION ALL

      -- Get the Flow when the Lot returns to a Main Route 
      SELECT LF.FACILITY,
             LF.LOT,
             LF.PRODUCT,
             LF.FLOWPLAN,
             LF.FLOWPLAN_VERSION,
             LF.ROUTE,
             LF.ROUTE_BASE_NAME,
             LF.ROUTE_VERSION,
             LF.OPERATION AS CURRENT_OPERATION,
             FPRO.OPERATION,
             FPRO.ROUTEOPER_SEQNO,
             LF.OPERATION_VERSION,
             LF.FLOW_CONTEXT,
             LF.REWORK_RETURN_CONTEXT,
             LF.OWNER,
             LF.LOT_PRIORITY,
             LF.ONHOLD,
             LF.ONREWORK,
             LF.TERMINATED,
             LF.HOTLOT,
             LF.LOT_STATE,
             LF.PROCESS,
             LF.DOTPROCESS,
             LF.WAFER_QTY,
             LF.MOVEIN_DATE,
             LF.DATE_ENTERED_OPERATION,
             LF.FRO_FLOW_CONTEXT,
             LF.FRO_PLAN_SEQUENCE,
             LF.FRO_FLOWPLAN,
             LF.FRO_FLOWPLAN_VERSION,
             LF.FLOW_ALGORITHM,
             ROW_NUMBER() OVER(PARTITION BY LF.LOT ORDER BY FPRO.PLAN_SEQUENCE) AS EXEC_SEQ
      FROM HBLP_FLOW_CONTEXT_S      LF,
           MC_1_F_FLOWPLANROUTEOPER FPRO
      WHERE LF.FACILITY = FPRO.FACILITY
      AND LF.FRO_FLOWPLAN = FPRO.FLOWPLAN
      AND LF.FRO_FLOWPLAN_VERSION = FPRO.FLOWPLAN_VERSION
      AND FPRO.PLAN_SEQUENCE >= LF.FRO_PLAN_SEQUENCE
) LF1
      LEFT JOIN mc_1_f_am_history_skiplot S
      ON LF1.LOT = S.LOT
      AND LF1.OPERATION = S.OPERATION

      LEFT JOIN mc_1_f_operation OP
      ON LF1.OPERATION = OP.OPERATION
      WHERE OP.OPERGROUP1 != 'SORT';

      v_RowsAdded := SQL%ROWCOUNT;
      COMMIT;

      INSERT INTO HBLP_LOT_FLOW_HIST_S
        (FACILITY,
         LOT,
         PRODUCT,
         FLOWPLAN,
         FLOWPLAN_VERSION,
         ROUTE,
         ROUTE_BASE_NAME,
         ROUTE_VERSION,
         CURRENT_OPERATION,
         OPERATION,
         ROUTEOPER_SEQNO,
         OPERATION_VERSION,
         FLOW_CONTEXT,
         REWORK_RETURN_CONTEXT,
         OWNER,
         LOT_PRIORITY,
         ONHOLD,
         ONREWORK,
         TERMINATED,
         HOTLOT,
         LOT_STATE,
         PROCESS,
         DOTPROCESS,
         WAFER_QTY,
         MOVEIN_DATE,
         DATE_ENTERED_OPERATION,
         FRO_FLOW_CONTEXT,
         FRO_PLAN_SEQUENCE,
         FRO_FLOWPLAN,
         FRO_FLOWPLAN_VERSION,
         FLOW_ALGORITHM,
         SKIP_RESULT,
         EXEC_SEQ,
         SNAPSHOT_DATE)

      SELECT FACILITY,
             LOT,
             PRODUCT,
             FLOWPLAN,
             FLOWPLAN_VERSION,
             ROUTE,
             ROUTE_BASE_NAME,
             ROUTE_VERSION,
             CURRENT_OPERATION,
             OPERATION,
             ROUTEOPER_SEQNO,
             OPERATION_VERSION,
             FLOW_CONTEXT,
             REWORK_RETURN_CONTEXT,
             OWNER,
             LOT_PRIORITY,
             ONHOLD,
             ONREWORK,
             TERMINATED,
             HOTLOT,
             LOT_STATE,
             PROCESS,
             DOTPROCESS,
             WAFER_QTY,
             MOVEIN_DATE,
             DATE_ENTERED_OPERATION,
             FRO_FLOW_CONTEXT,
             FRO_PLAN_SEQUENCE,
             FRO_FLOWPLAN,
             FRO_FLOWPLAN_VERSION,
             FLOW_ALGORITHM,
             SKIP_RESULT,
             EXEC_SEQ,
             v_StartTime AS SNAPSHOT_DATE
      FROM HBLP_LOT_FLOW_S;
      
      COMMIT;


  v_ElapsedTime := ROUND((SYSDATE - v_StartTime) * 24 * 60 *60);

  -- Write to ExtractMetrics
  SP$LOG_METRICS
    (
        p_ExtractName => c_PROCEDURE_NAME,
        p_ExtractStartDate => v_StartTime,
        p_ExtractEndDate => SYSDATE,
        p_RunStartDate => v_StartTime,
        p_RunEndDate => SYSDATE,
        p_RecordsAdded => v_RowsAdded,
        p_Status => 'SUCCESS'
     );

  -- Write to Logfile
   SP$LOG_ME(c_PROCEDURE_NAME || ': Success with ' || TO_CHAR(v_RowsAdded) || ' Rows added in ' || TO_CHAR(v_ElapsedTime) || ' seconds' );

  EXCEPTION
    WHEN OTHERS
    THEN
      DECLARE
         v_ErrorCode NUMBER := SQLCODE;
         v_ErrorMessage VARCHAR2(300) := SQLERRM;
         v_Comments VARCHAR2(500);
      BEGIN

         ROLLBACK;

         v_COMMENTS := SUBSTR(v_ErrorCode || ' - ' || v_ErrorMessage || ' - ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 0, 500);

        SP$LOG_ME(c_PROCEDURE_NAME || ' - Error: '|| v_Comments);
        SP$LOG_METRICS(c_PROCEDURE_NAME, v_StartTime, SYSDATE, v_StartTime, SYSDATE,0 , 0, 'FAILURE', v_Comments);

   END;

END SP$LOTFLOW;
