-- REFERENCE ONLY: exact procedure body excerpt; not a standalone SQL script.
PROCEDURE SP$FLOWCONTEXT

IS

  c_PROCEDURE_NAME CONSTANT MC_1_F_EXTRACTMETRICS.EXTRACT_NAME%TYPE := 'SP$FLOWCONTEXT';
  v_RowsAdded NUMBER;
  v_ElapsedTime NUMBER;
  v_StartTime DATE := SYSDATE;
  
BEGIN

      --EXECUTE IMMEDIATE ('TRUNCATE TABLE HBLP_FLOW_CONTEXT_S') ;
      DELETE FROM HBLP_FLOW_CONTEXT_S;
      
      INSERT INTO HBLP_FLOW_CONTEXT_S
        (FACILITY,
         LOT,
         PRODUCT,
         FLOWPLAN,
         FLOWPLAN_VERSION,
         ROUTE,
         ROUTE_BASE_NAME,
         ROUTE_VERSION,
         OPERATION,
         OPERATION_VERSION,
         FLOW_CONTEXT,
         REWORK_RETURN_CONTEXT,
         OWNER,
         LOT_PRIORITY,
         ONHOLD,
         ONREWORK,
         TERMINATED,
         HOTLOT,
         LOT_STATE,
         PROCESS,
         DOTPROCESS,
         WAFER_QTY,
         MOVEIN_DATE,
         DATE_ENTERED_OPERATION,
         FRO_FLOW_CONTEXT,
         FRO_PLAN_SEQUENCE,
         FRO_CUR_SEQ,
         FRO_FLOWPLAN,
         FRO_FLOWPLAN_VERSION,
         FLOW_ALGORITHM)
      (
      -- HAPPY PATH FLOW
      SELECT FL.FACILITY,
             FL.LOT,
             FL.PRODUCT,
             FL.FLOWPLAN,
             FL.FLOWPLAN_VERSION,
             FL.ROUTE,
             FR.ROUTE_BASE_NAME,
             FL.ROUTE_VERSION,
             FL.OPERATION,
             FL.OPERATION_VERSION,
             FL.FLOW_CONTEXT,
             FL.REWORK_RETURN_CONTEXT,
             FL.OWNER,
             FL.LOT_PRIORITY,
             FL.ONHOLD,
             FL.ONREWORK,
             FL.TERMINATED,
             FL.HOTLOT,
             FL.LOT_STATE,
             SUBSTR(FL.DOTPROCESS,1,4) AS PROCESS,
             FL.DOTPROCESS,
             FL.WAFER_QTY,
             FL.MOVEIN_DATE,
             FL.DATE_ENTERED_OPERATION,
             
             CASE 
               WHEN FL.FLOWPLAN IS NOT NULL AND FL.FLOW_CONTEXT NOT LIKE '%,%' AND FC.FLOW_CONTEXT IS NOT NULL THEN FC.FLOW_CONTEXT  -- HAPPY PATH
               WHEN FL.FLOWPLAN IS NULL AND FL.ROUTE LIKE 'RW%' THEN RW.FLOW_CONTEXT -- REWORK
               WHEN FL.FLOWPLAN IS NOT NULL AND RW.FLOW_CONTEXT LIKE '%,%' AND FRO.FLOW_CONTEXT IS NOT NULL THEN FRO.FLOW_CONTEXT-- FLOW LOOKUP
               ELSE NULL
             END AS FRO_FLOW_CONTEXT,
             CASE 
               WHEN FL.FLOWPLAN IS NOT NULL AND FL.FLOW_CONTEXT NOT LIKE '%,%' AND FC.FLOW_CONTEXT IS NOT NULL THEN FC.PLAN_SEQUENCE  -- HAPPY PATH
               WHEN FL.FLOWPLAN IS NULL AND FL.ROUTE LIKE 'RW%' THEN RW.PLAN_SEQUENCE -- REWORK
               WHEN FL.FLOWPLAN IS NOT NULL AND RW.FLOW_CONTEXT LIKE '%,%' AND FRO.FLOW_CONTEXT IS NOT NULL THEN FRO.PLAN_SEQUENCE-- FLOW LOOKUP
               ELSE -1
             END AS FRO_PLAN_SEQUENCE,
             
             CASE 
               WHEN FL.FLOWPLAN IS NOT NULL AND FL.FLOW_CONTEXT NOT LIKE '%,%' AND FC.FLOW_CONTEXT IS NOT NULL THEN FC.Routeoper_Seqno  -- HAPPY PATH
               WHEN FL.FLOWPLAN IS NULL AND FL.ROUTE LIKE 'RW%' THEN RO.Routeoper_Seqno -- REWORK
               WHEN FL.FLOWPLAN IS NOT NULL AND RW.FLOW_CONTEXT LIKE '%,%' AND FRO.FLOW_CONTEXT IS NOT NULL THEN FRO.Routeoper_Seqno-- FLOW LOOKUP
               ELSE -1
             END AS FRO_CUR_SEQ,
             
             CASE 
               WHEN FL.FLOWPLAN IS NOT NULL AND FL.FLOW_CONTEXT NOT LIKE '%,%' AND FC.FLOW_CONTEXT IS NOT NULL THEN FC.FLOWPLAN  -- HAPPY PATH
               WHEN FL.FLOWPLAN IS NULL AND FL.ROUTE LIKE 'RW%' THEN RW.FLOWPLAN -- REWORK
               WHEN FL.FLOWPLAN IS NOT NULL AND RW.FLOW_CONTEXT LIKE '%,%' AND FRO.FLOW_CONTEXT IS NOT NULL THEN FRO.FLOWPLAN-- FLOW LOOKUP
               ELSE NULL
             END AS FRO_FLOWPLAN,
             CASE 
               WHEN FL.FLOWPLAN IS NOT NULL AND FL.FLOW_CONTEXT NOT LIKE '%,%' AND FC.FLOW_CONTEXT IS NOT NULL THEN FC.FLOWPLAN_VERSION  -- HAPPY PATH
               WHEN FL.FLOWPLAN IS NULL AND FL.ROUTE LIKE 'RW%' THEN RW.FLOWPLAN_VERSION -- REWORK
               WHEN FL.FLOWPLAN IS NOT NULL AND RW.FLOW_CONTEXT LIKE '%,%' AND FRO.FLOW_CONTEXT IS NOT NULL THEN FRO.FLOWPLAN_VERSION-- FLOW LOOKUP
               ELSE -1
             END AS FRO_FLOWPLAN_VERSION,
             CASE  
               WHEN FL.FLOWPLAN IS NOT NULL AND FL.FLOW_CONTEXT NOT LIKE '%,%' AND FC.FLOW_CONTEXT IS NOT NULL THEN 'HAPPY_PATH'  -- HAPPY PATH
               WHEN FL.FLOWPLAN IS NULL AND FL.ROUTE LIKE 'RW%' THEN 'REWORK' -- REWORK
               WHEN FL.FLOWPLAN IS NOT NULL AND RW.FLOW_CONTEXT LIKE '%,%' AND FRO.FLOW_CONTEXT IS NOT NULL THEN 'FLOW_LOOKUP'  -- FLOW LOOKUP
               ELSE NULL
             END AS FLOW_ALGORITHM
      FROM MC_1_F_LOT FL
      JOIN MC_1_F_ROUTE FR 
      ON FL.FACILITY = FR.FACILITY
      AND FL.ROUTE = FR.ROUTE
      AND FL.ROUTE_VERSION = FR.ROUTE_VERSION

      -- HAPPY PATH JOIN
      LEFT JOIN MC_1_F_FLOWPLANROUTEOPER FC  
      ON FL.FLOW_CONTEXT = FC.FLOW_CONTEXT  
      AND FL.FLOWPLAN IS NOT NULL 
      AND FL.FLOW_CONTEXT NOT LIKE '%,%'  
      AND FC.SRC_ERASE_DATE IS NULL

      -- REWORK PATH
      LEFT JOIN MC_1_F_FLOWPLANROUTEOPER RW  
      ON FL.REWORK_RETURN_CONTEXT = RW.FLOW_CONTEXT 
      AND FL.ROUTE LIKE 'RW%'
      AND FL.FLOWPLAN IS NULL 
      AND RW.SRC_ERASE_DATE IS NULL

      -- GET REWORK ROUTE SEQUENCE NUMBERS
      LEFT JOIN MC_1_F_ROUTEOPER RO
      ON FL.FACILITY = RO.FACILITY
      AND FL.ROUTE = RO.ROUTE 
      AND FL.ROUTE_VERSION = RO.ROUTE_VERSION
      AND FL.OPERATION = RO.OPERATION
      AND RO.OPERATION_VERSION IN (FL.OPERATION_VERSION , -1)
      AND FL.FLOW_CONTEXT = RO.OBJECT_ID
      AND FL.ROUTE LIKE 'RW%'
      AND FL.FLOWPLAN IS NULL 
      AND RO.SRC_ERASE_DATE IS NULL

      -- FLOWPLAN PATH
      LEFT JOIN MC_1_F_FLOWPLANROUTEOPER FRO
      ON FL.FACILITY = FRO.FACILITY
      AND fL.flowplan = FRO.flowplan
      AND fL.flowplan_version = FRO.flowplan_version
      AND fL.route = FRO.route
      AND fL.route_version = FRO.route_version
      AND fL.operation = FRO.operation
      AND FRO.operation_version IN (FL.operation_version, -1)
      AND FL.flowplan IS NOT NULL 
      AND FL.flow_context LIKE '%,%'
      AND FRO.SRC_ERASE_DATE IS NULL
      WHERE FL.OWNER IN (SELECT META_VALUE FROM HBLP_METADATA WHERE META_TYPE = 'OWNER')
      AND FL.HOTLOT = 'Y'
      AND FL.LOT_PRIORITY IN (SELECT META_VALUE FROM HBLP_METADATA WHERE META_TYPE = 'LOT_PRIORITY')
      AND FL.TERMINATED = 'N'
      AND FL.SRC_ERASE_DATE IS NULL
      AND FL.LOT_STATE = 'Active'
      AND FL.ONHOLD = 'N'
      AND FL.WAFER_QTY > 0);

      v_RowsAdded := SQL%ROWCOUNT;
      COMMIT;


      -- Store a snapshot of the flow context for debugging purposes
      INSERT INTO HBLP_FLOW_CONTEXT_HIST_S
      (FACILITY,
       LOT,
       PRODUCT,
       FLOWPLAN,
       FLOWPLAN_VERSION,
       ROUTE,
       ROUTE_BASE_NAME,
       ROUTE_VERSION,
       OPERATION,
       OPERATION_VERSION,
       FLOW_CONTEXT,
       REWORK_RETURN_CONTEXT,
       OWNER,
       LOT_PRIORITY,
       ONHOLD,
       ONREWORK,
       TERMINATED,
       HOTLOT,
       LOT_STATE,
       PROCESS,
       DOTPROCESS,
       WAFER_QTY,
       MOVEIN_DATE,
       DATE_ENTERED_OPERATION,
       FRO_FLOW_CONTEXT,
       FRO_PLAN_SEQUENCE,
       FRO_CUR_SEQ,
       FRO_FLOWPLAN,
       FRO_FLOWPLAN_VERSION,
       FLOW_ALGORITHM,
       SNAPSHOT_DATE)
      SELECT FACILITY,
             LOT,
             PRODUCT,
             FLOWPLAN,
             FLOWPLAN_VERSION,
             ROUTE,
             ROUTE_BASE_NAME,
             ROUTE_VERSION,
             OPERATION,
             OPERATION_VERSION,
             FLOW_CONTEXT,
             REWORK_RETURN_CONTEXT,
             OWNER,
             LOT_PRIORITY,
             ONHOLD,
             ONREWORK,
             TERMINATED,
             HOTLOT,
             LOT_STATE,
             PROCESS,
             DOTPROCESS,
             WAFER_QTY,
             MOVEIN_DATE,
             DATE_ENTERED_OPERATION,
             FRO_FLOW_CONTEXT,
             FRO_PLAN_SEQUENCE,
             FRO_CUR_SEQ,
             FRO_FLOWPLAN,
             FRO_FLOWPLAN_VERSION,
             FLOW_ALGORITHM,
             v_StartTime AS SNAPSHOT_DATE
      FROM HBLP_FLOW_CONTEXT_S;

      COMMIT;


  v_ElapsedTime := ROUND((SYSDATE - v_StartTime) * 24 * 60 *60);

  -- Write to ExtractMetrics
  SP$LOG_METRICS
    (
        p_ExtractName => c_PROCEDURE_NAME,
        p_ExtractStartDate => v_StartTime,
        p_ExtractEndDate => SYSDATE,
        p_RunStartDate => v_StartTime,
        p_RunEndDate => SYSDATE,
        p_RecordsAdded => v_RowsAdded,
        p_Status => 'SUCCESS'
     );

  -- Write to Logfile
   SP$LOG_ME(c_PROCEDURE_NAME || ': Success with ' || TO_CHAR(v_RowsAdded) || ' Rows added in ' || TO_CHAR(v_ElapsedTime) || ' seconds' );

  EXCEPTION
    WHEN OTHERS
    THEN
      DECLARE
         v_ErrorCode NUMBER := SQLCODE;
         v_ErrorMessage VARCHAR2(300) := SQLERRM;
         v_Comments VARCHAR2(500);
      BEGIN

         ROLLBACK;

         v_COMMENTS := SUBSTR(v_ErrorCode || ' - ' || v_ErrorMessage || ' - ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 0, 500);

        SP$LOG_ME(c_PROCEDURE_NAME || ' - Error: '|| v_Comments);
        SP$LOG_METRICS(c_PROCEDURE_NAME, v_StartTime, SYSDATE, v_StartTime, SYSDATE,0 , 0, 'FAILURE', v_Comments);

   END;

END SP$FLOWCONTEXT;
