-- REFERENCE ONLY: exact procedure body excerpt; not a standalone SQL script.
PROCEDURE SP$ASSESSMENT_HIST

IS

  c_PROCEDURE_NAME CONSTANT MC_1_F_EXTRACTMETRICS.EXTRACT_NAME%TYPE := 'SP$ASSESSMENT_HIST';
  v_StartTime DATE := SYSDATE;
  v_ElapsedTime NUMBER;
  v_RowsAdded    NUMBER := 0;
  v_RunCounter NUMBER;
  v_RunInterval NUMBER;

  
  
BEGIN

    -- Start: Snapshot of the assesment - typically run 1 per day
    SP$LOG_ME(c_PROCEDURE_NAME || ' Begins');

    --
    -- Only run at the specified interval as defined in metadata
    --  This allows site to control how often the RCT logic runs due
    --  to performance issues
    --
    v_RunCounter := FN$GET_META_VALUE('HIST_RUN_COUNTER');
    v_RunInterval := FN$GET_META_VALUE('HIST_RUN_INTERVAL');

 IF (v_RunCounter = v_RunInterval)
 THEN    
        
      INSERT INTO HBLP_PREDICTION_HIST
        (PRED_METHOD,
         TOOLSET,
         RESV_DELTA_MEAN,
         RESV_DELTA_STDDEV,
         RESV_DELTA_COUNT,
         FINAL_DELTA_MEAN,
         FINAL_DELTA_STDDEV,
         FINAL_DELTA_COUNT,
         RESV_MEAN_50P,
         RESV_STDDEV_50P,
         RESV_COUNT_50P,
         RESV_MEAN_95P,
         RESV_STDDEV_95P,
         RESV_COUNT_95P,
         DELTA_MEAN,
         DELTA_STDDEV,
         OVERALL_CORR,
         OVERALL_SAMPLES,
         RESPONSE_CORR,
         RESPONSE_SAMPLES,
         Q_TO_MNT_CORR,
         Q_TO_MNT_SAMPLES,
         AMHS_CORR,
         AMHS_SAMPLES,
         POST_DEL_DELAY_CORR,
         POST_DEL_DELAY_SAMPLES,
         RUN_TO_START_CORR,
         RUN_TO_START_SAMPLES,
         WAFER_PROC_CORR,
         WAFER_PROC_SAMPLES,
         MVOUT_DEL_CORR,
         MVOUT_DEL_SAMPLES,
         SNAPSHOT_DATE)
        SELECT PRED_METHOD,
               TOOLSET,
               RESV_DELTA_MEAN,
               RESV_DELTA_STDDEV,
               RESV_DELTA_COUNT,
               FINAL_DELTA_MEAN,
               FINAL_DELTA_STDDEV,
               FINAL_DELTA_COUNT,
               RESV_MEAN_50P,
               RESV_STDDEV_50P,
               RESV_COUNT_50P,
               RESV_MEAN_95P,
               RESV_STDDEV_95P,
               RESV_COUNT_95P,
               DELTA_MEAN,
               DELTA_STDDEV,
               OVERALL_CORR,
               OVERALL_SAMPLES,
               RESPONSE_CORR,
               RESPONSE_SAMPLES,
               Q_TO_MNT_CORR,
               Q_TO_MNT_SAMPLES,
               AMHS_CORR,
               AMHS_SAMPLES,
               POST_DEL_DELAY_CORR,
               POST_DEL_DELAY_SAMPLES,
               RUN_TO_START_CORR,
               RUN_TO_START_SAMPLES,
               WAFER_PROC_CORR,
               WAFER_PROC_SAMPLES,
               MVOUT_DEL_CORR,
               MVOUT_DEL_SAMPLES,
               SYSDATE AS SNAPSHOT_DATE
        FROM HBLP_PREDICTION_ASSESSMENT_V T;
      
      v_RowsAdded := SQL%ROWCOUNT;
      COMMIT;
      
    END IF; -- If (v_RunCounter = v_RunInterval)
    
    v_RunCounter := v_RunCounter + 1;
    IF v_RunCounter > v_RunInterval THEN
      v_RunCounter := 1;
    END IF;

    UPDATE HBLP_METADATA
     SET META_VALUE = v_RunCounter,
         LAST_UPDATE_DATE = SYSDATE,
         LAST_UPDATE_USER = 'SP'
    WHERE META_TYPE = 'HIST_RUN_COUNTER';
    COMMIT;
    
    
    --
    -- Signal job completion
    --
    SP$LOG_ME(c_PROCEDURE_NAME || ': Success with ' || TO_CHAR(v_RowsAdded) || ' Rows added in ' || TO_CHAR(v_ElapsedTime) || ' seconds' );

      SP$LOG_METRICS
      (
          p_ExtractName => c_PROCEDURE_NAME,
          p_ExtractStartDate => v_StartTime,
          p_ExtractEndDate => SYSDATE,
          p_RunStartDate => v_StartTime,
          p_RunEndDate => SYSDATE,
          p_RecordsAdded => v_RowsAdded,
          p_Status => 'SUCCESS'
       );
    
    EXCEPTION
        WHEN OTHERS
        THEN
          DECLARE
            v_ErrorCode NUMBER := SQLCODE;
            v_ErrorMessage VARCHAR2(300) := SQLERRM;
            v_Comments VARCHAR2(500);

          BEGIN
            v_COMMENTS := SUBSTR(v_ErrorCode || ' - ' || v_ErrorMessage || ' - ' || DBMS_UTILITY.FORMAT_ERROR_BACKTRACE, 0, 500);
            SP$LOG_ME(c_PROCEDURE_NAME || '- Error ' || v_Comments);
         END;


END SP$ASSESSMENT_HIST;
