-- Read-only. Run in the same Oracle database as sql_hblp_1.vbs.
-- These queries do not create, modify or run the HBLP package.
SELECT owner, view_name, text_length, text
FROM all_views
WHERE owner = 'FABEX' AND view_name = 'HBLP_LOT_TOOL_STATUS_V';

SELECT owner, name, type, referenced_owner, referenced_name, referenced_type
FROM all_dependencies
WHERE owner = 'FABEX' AND name = 'HBLP_LOT_TOOL_STATUS_V';

-- Optional DDL alternative; permissions may limit DBMS_METADATA.
-- SELECT DBMS_METADATA.GET_DDL('VIEW','HBLP_LOT_TOOL_STATUS_V','FABEX') FROM dual;
