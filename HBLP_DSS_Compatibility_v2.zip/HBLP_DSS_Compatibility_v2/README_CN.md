# HBLP DSS 接口兼容 rule v2

## 实际完成范围

本包完成的是 APF 原始 DSS 输入到 27 列 DSS 输出的兼容 rule，提供未来 ETA 修改位置。**没有完成把整个 HBLP_PACKAGE 迁入 APF 原生积木。** 原来的路径、事件、库存、R2A、QT/PT 和设备排序仍由上游 Oracle package 和视图计算。

这不能替代用户要求的完整计算迁移版，不能称为所有原业务都已在本 rule 内实现。交付它的目的是把已确定的接口落实为可检查的源码，避免继续使用上一版改变原行为的 5 步/测试 QT 原型。

## 本次材料明确了什么

sql_hblp_1.vbs 的 SQL 直接读取 FABEX.HBLP_LOT_TOOL_STATUS_V：
- ENTITY -> PredictedEntityName；LOT -> LotID；OPERATION -> Oper；OPERATION_VERSION -> OperVersion。
- ROUTE、FLOWPLAN、FLOW_CONTEXT 直接投影。
- ETA 格式为 DD/MM/YY HH24:MI:SS。
- UpdateTime 在 Oracle 导出查询时使用 SYSDATE，不是某条预测的 LAST_LOAD_DATE。
- DeltaToETA_Mins 直接来自视图 DELTA_TO_ETA_MINS；VBS 本身没有乘 1440，也没有按 ETA-现在重新计算。
- 17 个其他字段固定 NULL，包括所有标记、Batch 和 LPOpenField。
- SELECT 没有新增 RN=1 筛选；是否在视图内部筛选、选哪张原预测结果表，需要视图定义确认。

Process_Flow_Parsing_iCTP_UDA_Perf_Yilin - Copy.report 的 Database 使用 `APFREP:WorkStreamClassic:LiveDB`。Resources_SQL 为空；它不是 MARS/FABEX Oracle 连接示例。它补充确认了 WIP_LOT.lot_id、Owner、lot_active_flag 等字段，但没有提供 HBLP_MODEL_*、NTSC 历史、XETA 或原 metadata 的 APF 数据源。

不能将 MC_1_F_LOT 的字段机械改名为 WIP_LOT；尤其 HotLot、Owner 值、删除/终止状态、事件数据、skip 和模型参数尚未建立完整等价关系。路径宏和 LotProcessTime 宏也不等价于原 SQL R2A、QT/PT 回退及返工路径逻辑。

## Rule 结构

`DSS_Original_Input (Import LP_Predictions_DSS)` -> `ETA_Adapter (Function)` -> `DSS_Output (DispatchScreen)`。

ETA_Adapter 当前只做两个恒等赋值：

```text
ETA = ETA
DeltaToETA_Mins = DeltaToETA_Mins
```

没有 WIP_Validate、InputStatus、额外业务筛选、重新排序、去重、固定步数、手工 QT、候选设备重选或额外诊断列。Import 读取既有生产入口文件，不能关闭原来的 package、VBS 导出或复制任务。

数据源路径：`$APFMODELCLASS/LP_Predictions_DSS`。既有复制脚本的目的位置是 `D:\APF\apfhome\models\WorkStreamClassic\class\LP_Predictions_DSS`。它由原 `%FSUI_Root%\DSS\LP_Predictions_DSS.txt` 复制而来。本包不需要上一版 HBLP_TEST_LOTS_V1。

## 文件

- RPT_HBLP_DSS_COMPAT_V2.report：源码 wrapper，使用已能打开的 XMLBlocks 结构；在现场 Editor 编译保存。没有伪造 EngineCode/XMLMD5/Queries。
- RPT_HBLP_DSS_COMPAT_V2.blocks.xml：同一图的可读 XML。
- HBLP_DSS_COMPAT_V2.pl：以用户提供的 LP_Predictions_F68_2.pl 为模板，只改 RuleName 和 OutputFile。输出为 `LP_Predictions_HBLP_RULE_V2`，不会覆盖 LP_Predictions_DSS。
- original_dss_export.sql：从 VBS 原样抽取的 SELECT，包含真正的视图来源和 27 列映射。
- DSS_header.txt / DSS_field_mapping.csv：精确表头、类型和 SQL 来源。
- original_logic_reference/：原 package 各业务过程的逐段原文。仅用于迁移对照，不由 report 执行，不是独立可运行 SQL。
- inspect_view.sql：只读查询，获取关键视图定义和依赖。
- verification.json：明确记录已做/未做的验证。

## 使用步骤

1. 确认既有 `LP_Predictions_DSS` 在当前 Dispatcher 的 class 目录中，并且能够被 Import 预览。
2. 用 Editor 打开 RPT_HBLP_DSS_COMPAT_V2.report，编译并保存，注册为同名可调用 rule。示例中的数据源与当前实例应一致。
3. 预览 DSS_Output，检查 27 列名称、顺序、字段类型。OperVersion 为 Integer，其余均为 String。不要加入新的诊断列。
4. 单独执行 `perl HBLP_DSS_COMPAT_V2.pl`，它沿用已有 CronPorts.cfg、status_tool、rule2flat.pl、archive.bat、Pushfile.bat。当前环境必须已有这些工具。
5. 输出文件是 class 目录下的 LP_Predictions_HBLP_RULE_V2。比较同一输入快照的源文件与新输出，确认空字符串、时间文本、OperVersion、DeltaToETA_Mins 的文本表示符合下游要求。静态检查不能替代 APF 实际导出比较。
6. 只让下游测试副本读取这个输出。源文件和输出必须不同，避免自读自写循环。

该 Perl 继承原脚本的表头/行数检查，不是新增业务判断。它也继承原脚本既有行为和限制，没有现场运行验证。原 VBS 写入的 `MARS_APF_SQL_HBLP_1` extract metric 不由此 Perl 复现；保留原 VBS 任务时原监控继续存在，若未来替换它需同时处理监控依赖。

## 后续 ETA 替换

未来算法接入位置为 ETA_Adapter，但不能把 DeltaToETA_Mins 任意改为 ETA-UpdateTime。先获取视图定义，确定该字段口径。更新 ETA 时是否要更新 UpdateTime，也应按新发布周期明确；本兼容版保持输入 UpdateTime 原样，不制造新的预测更新时间。

## 完整迁移仍缺少的两项

1. FABEX.HBLP_LOT_TOOL_STATUS_V 的视图定义。执行 inspect_view.sql 即可获取可见部分。它决定真正发布的是 _STATUS 还是 _STATUS2、设备筛选规则、DELTA_TO_ETA_MINS 换算和可能的额外关联。
2. APF 对原 package 所需 Oracle 源对象的访问方式：实际 Oracle SQL 数据源积木示例，或这些对象已同步为 LiveDB/class 的映射。现有 LiveDB 示例未包含这部分。

完整原计算流程、历史和清理过程都保存在 original_logic_reference 中；它们没有被我重新解释为近似算法。后续在数据访问确认后，才能逐阶段迁移并比较。预测输出的等价性不自动覆盖原 package 的历史写入、purge、assessment、COMMIT 和日志副作用。

## 验证边界

已检查 XML 往返解析、积木连接、27 列投影与 VBS 对应、ISS 表头与原 dat 一致、样本 14,050 行字段数、ETA 适配为恒等操作。没有 APF 编译器、数据库连接或 Dispatcher，未执行现场编译或结果对比。当前交付不是“完整迁移已完成”的声明。
