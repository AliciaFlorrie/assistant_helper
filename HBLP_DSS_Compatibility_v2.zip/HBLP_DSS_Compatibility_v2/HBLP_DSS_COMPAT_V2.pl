#
# Job Configuration
#

use Sys::Hostname;
$hostname = hostname;
@ahostname = split(/\./, $hostname);
$Facility = $ENV{'APF_FAC'};
$PageList = $ENV{'APF_PAGELIST'};
$MailList = $ENV{'APF_MAILLIST'};
$PageCmd= $ENV{'PAGECMD'};
$MailCmd= $ENV{'MAILCMD'};
$ALERT_SUBJECTTAG = "$Facility:".$ahostname[0];

$RuleName = "RPT_HBLP_DSS_COMPAT_V2";
$ClassDir = "D:\\APF\\apfhome\\models\\WorkStreamClassic\\class";
$OutputFile = "$ClassDir\\LP_Predictions_HBLP_RULE_V2";
$MinimumLines = 2;
$FlatFileConversionCommand = "perl D:\\APF\\tools\\rule2\\rule2flat.pl";

#
#  Site Configuration
#
$PortsFile="D:\\APF\\tools\\cron\\CronPorts.cfg";
$Grep="D:\\Apf\\Tools\\UnixTools\\Grep.exe";
$ArchiveCmd="D:\\APF\\Tools\\W2kSyncClient\\archive.bat";
$PushFileCmd="D:\\APF\\Tools\\W2kSyncClient\\Pushfile.bat";
$Push2ReportCmd="D:\\APF\\Tools\\W2kSyncClient\\Push2Report.bat";
$DispatcherTimeout = 300;

use File::Copy;

sub SendAlert
{
#  open (PageLogfl, ">>$PageLog") || die ("Cannot Open File $PageLog");
#  ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
#  printf PageLogfl "%04d/%02d/%02d %02d:%02d:%02d - @_\n", ,($year+1900),$mon+1,$mday,$hour,$min,$sec;
#  close PageLogfl;
  print"@_ \n";
  if ( ! $PageList eq "")
  {
    printf PageLogfl ("Paging:$PageList @_");
    @PageAddress=split(/\,/, $PageList);
    $i=0;
    foreach (@PageAddress)
    {
      system($PageCmd ." ". @PageAddress[$i++] ." \"". $ALERT_SUBJECTTAG .": APF Alert- $_[0]\"");
    }
  }
  if ( ! $MailList eq "")
  {
    system($MailCmd . "-body \"$_[0]\" -t ". $MailList ." -subject \"". $ALERT_SUBJECTTAG .": APF Alert\"");
  }
}

#
#  Start Main
#

open(PortsFile, "< $PortsFile") || die ("Cannot Open File $PortsFile");
$FoundDispatcher = "False";
while (($Line=<PortsFile>) && ($FoundDispatcher eq "False"))
{
  chomp($Line);
  (@LineSegment) = split (/\|/, $Line);
  $StartTime = time();
  open(STDERR, "/dev/null");
  open (DispatcherCheck, "status_tool -timeout $DispatcherTimeout ".@LineSegment[0]. " " . @LineSegment[1]." status connected" . "|");
  $RESULTS=<DispatcherCheck>;
  close COMMAND;
  close(STDERR);
  if ($RESULTS=~ /true/)
  {
    $FoundDispatcher = "True";
    $DispatcherNode = @LineSegment[0];
    $DispatcherPort = @LineSegment[1];
  }
}


if ($FoundDispatcher eq "False")
{
  SendAlert("A dispatcher Could not be found to generate $OutputFile");
}
else
{
  $HeaderFound = False;
  $InfoFound = False;
  open (OutputFile,">$OutputFile"."_tmp")  || die ("Cannot Open File ".$OutputFile."_tmp");
  $Command="status_tool $DispatcherNode $DispatcherPort dlis Station $RuleName | $FlatFileConversionCommand";
  open (DispatchRequest, "$Command |");
  while($Results=<DispatchRequest>)
  {
    $Lines++;
    if ($Results =~ /^#info/) { $InfoFound = True }
    if ($Results =~ /^#ISS/) { $HeaderFound = True }
    printf OutputFile $Results;
  }
  close OutputFile;
  close DispatchRequest;

  if ($Lines >= $MinimumLines)
  {

    if ( $InfoFound eq "True" && $HeaderFound eq "True" )
    {
      system( "$ArchiveCmd $OutputFile" );
      move ( $OutputFile."_tmp", $OutputFile );
      system( "$PushFileCmd $OutputFile" );
    }
    else
    {
      SendAlert("Dispatcher Results for $OutputFile did not contain Header Information");
    }
  }
  else
  {
    SendAlert("Results for $OutputFile did not contain sufficient Number of Lines");
  }
}

