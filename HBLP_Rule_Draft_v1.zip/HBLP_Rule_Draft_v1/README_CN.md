# HBLP 初版 Rule 源码草稿 v1

这是一份用于 APF Editor 搭建、编译和验证的原始预测 rule 草稿。不是已编译或已上线的完整 HBLP 替代品。编写依据是本次提供的两个宏和之前的 Tuner/report；本地只做了 XML、连接、列结构检查，没有 APF 编译器和 LiveDB，不能保证当前 Editor 直接接受源码 wrapper。

## 交付内容

- `RPT_HBLP_BASELINE_V1_SOURCE.report`：只含 XMLBlocks 的源码 wrapper。尝试用 Editor 打开后编译、另存为测试 rule；没有 EngineCode、Description.Queries 或伪造 XMLMD5。
- `RPT_HBLP_BASELINE_V1.blocks.xml`：同一积木图的纯 XML，便于检查；不要直接将其改后缀冒充已编译 report。
- `block_plan.csv`：64 个积木的名称、类型、上游和完整属性/表达式。Editor 若不接受源码 wrapper，按此表搭建，宏在 Editor 中从已有 repository 重新选择。
- `HBLP_TEST_LOTS_V1`：APF flat-file 格式的测试 lot 输入，示例默认禁用。
- `eta_contract.json`：将来替换 ETA 算法时需要保持的输入/输出约定。
- `validation.json`：本地验证结果及需要在 APF 检查的项目。
- `build_hblp_draft.py`：可复现生成器，用 Python 标准库生成源码草稿。它不是 APF 编译器。

## v1 的工作范围

WIP_LOT 确实是 work-in-process lot 数据对象。草稿用测试清单中的 LotID 查询 LiveDB 中实际 WIP，不从 DSS 文件读取预测结果。

当前不猜测 WIP_LOT 的全表 lot 主键字段、HotLot/Owner/Active 字段及取值。初版通过显式测试清单选取几批经人工确认的 hot lot，利用已在原 Tuner 中验证过的 `WIP_LOT{LotID}.字段` 查询方式读取实时状态。

输入字段：

| 字段 | 类型 | 说明 |
|---|---|---|
| LotID | String | 内网实际存在的 lot |
| Enabled | String | Y 才参与；每个启用 LotID 只能出现一次 |
| QueueMinutes | Real | 用户明确设定的测试用每站 QT，单位分钟；不是历史统计或真实队列预测 |
| CurrentRemainingMinutes | Real | >=0 时为当前站剩余总时间；-1 表示以完整当前站 PT + 测试 QT 近似 |

示例中的 5 分钟不是现场默认配置，只是测试值。建议先填写当前站已知剩余时间，而不是使用 -1。禁用示例 `REPLACE_WITH_REAL_LOT|N|5|-1` 必须替换为真实 lot 后再启用。

v1 排除 hold、rework、无有效当前 operation/context、数量无效和 QT 无效的 lot。返工暂不支持；SQL 原始筛选中的其他条件尚未全部实现。输入诊断输出可检查被上述条件拦下的 lot。重复启用 LotID 会在 Seed_Unique 前排除，需在 Seed_OneRowPerLot 中检查 SeedCount，不会进入输入诊断。

## 积木模块

| 模块 | 关键积木 | 作用 |
|---|---|---|
| 测试输入 | Seed_Import / Seed_Enabled / Seed_OneRowPerLot / Seed_Unique | 明确测试范围，拒绝重复 lot |
| WIP 读取 | WIP_Read / WIP_Validate / WIP_Valid / Context_Seed | 读取当前站、版本、route、flowplan、数量、context |
| 路径展开 | Path_Request_1..5 / Path_UniqueRequest_1..5 / Path_Macro_1..5 / Path_Attach_1..5 | 从同一原始位置分别查询第 1..5 步，再按输入 context 和步数关联回 lot |
| 路径合并 | Path_Step0..5 / Path_Union_1..5 | 当前站为 StepIndex=0，未来站为 1..5；当前站用于计算下一站到达时间 |
| 设备关联 | Entity_Source / Entity_Named / Entity_Candidate / Entity_Attach | 按 operation 取名称最小的候选设备，确定性测试占位，不做最佳设备选择或 qualification |
| 加工时间 | PT_Input / PT_UniqueRequests / PT_Macro / PT_Attach | 调用现有加工时间宏，保留来源；按 lot、oper、route、quantity 关联 |
| 基准特征 | ETA_Features / ETA_Sort / 三个 ETA_Cumulate 积木 | 时长、缺失计数、路径连续性检查 |
| ETA 适配 | ETA_Adapter_Status / ETA_Adapter_Value | 集中生成预测可用性和到站 Instant，后续替换点 |
| 输出 | Output_Fields / Output_Valid / 三个 DispatchScreen | 诊断、输入状态和 27 列测试结果 |

不使用外层 Loop，先显式调用 5 次路径宏，便于逐步检查。相同路径请求先去重，避免不同 lot 共用 context 导致宏输出关联倍增。扩大 horizon 时应在 Editor 中评估执行耗时；不要直接为全厂 WIP 展开数百步。

## 两个宏的准确使用方式

### 路径宏

文件：`get_RT_NextXOper_Func_F68_9_7.report`

输入表 `_PCInput`：Current_FP_RT_rowid、Current_RT_OP_rowid、NextXSteps、OperToSearch，均按 Integer 绑定。

草稿用 `NextXSteps = 1..5`，`OperToSearch = INTEGER ""`（空 Integer）。源码通过 `FULL OperToSearch` 区分按目标 operation 搜索和按步数前进；因此不把整数 0 当成必然等价于空值。原 Tuner 使用 0 的调用场景和本草稿不同，应在 Editor 预览确认空 Integer 的行为。

宏默认 MaxSteps=100，可从其配置路径改变。它输出的是最终位置，不是整个路径列表。主要输出包括 NextXOper_Name、NextXOper_Version、NextXRoute_Name、NextXFlowPlan_Name、两个目标 row id、ActualNextXSteps、FoundOper、EndOfFlow，以及带下划线的原始输入键。

草稿只接受 FoundOper、实际步数等于请求步数、目标有效且不同于当前位置的结果。不单凭 `NOT EndOfFlow` 判断是否有效，因为宏中该标记与搜索终止逻辑交织。到流程结尾、跨 route、单层 flow 的 FoundOper/ActualNextXSteps 行为必须在现场检查。中间路径缺失不能被默认为零耗时。

该宏依赖 `split_FlowBlockObj_Func_VF_8_1.report` 以及 WIP_FLOWBLOCK_CHILD_SEQ、FLOW_BOUNDARY、CUSTOM_OPER 等资源；尚未提供 split 宏源码，请确认它已安装。该路径宏不是完整 MES 动态 skip/返工规则的替代品。

### 加工时间宏

文件：`get_LotProcessTime_Func_VF_7_9.report`

输入表 `GetLotProcessTime`：lot_number(String)、oper(Integer)、route(String)、quantity(Integer)、ClusterName(String)。输出 LotProcessTime(Duration)、SourceOfProcessTime 及 lot_number、oper、route、quantity。

已确认源码处理：
- 首先查 RUN2END_LOT_EST，涉及 lot/oper/route/数量匹配。
- 缺失或非正时，使用 run2end_oper_est / run2end_tw_oper_est 的阶段时间；piece 模式乘 wafer 数量。
- DisableNextSIMPT=Y 时把上述预测时间置 0，转入配置回退。
- 配置回退涉及 LOCAL_OPER_PROCESS_TIMES 和 PROCESS_TIME；LOCAL 配置优先排序，并考虑 route 匹配。
- 宏内部去除 `_SNIP` 后缀用于匹配，并恢复输出原 route。

不要将 LotProcessTime 当成完整 cycle time 或当前站剩余时间。它已是 Duration，不应再整体乘 60。

宏导出不保留 ClusterName；因此 v1 先为每个 operation 选一个候选 cluster 后再调用。未来做多 cluster 预测，必须扩展宏关联键/输出，不能直接把不同 cluster 的结果混到一起。宏含 `$majorValue` / `$ClusterName` 上下文引用，Editor 需要核对参数绑定及 DisableNextSIMPT 实际生效情况。

## ETA 基准与未来替换

内部统一使用 Duration 和 Instant。

StepDuration(0)：若输入了非负 CurrentRemainingMinutes，则为该剩余总时长；否则近似使用完整当前站加工时间 + 测试 QT。

StepDuration(i>0)：LotProcessTime(i) + 测试 QT。

到站 ETA(i) = SnapshotTime + sum(StepDuration(j), 0 <= j < i)。目标站自身加工时间不加入自己的到站 ETA。

例如当前站还剩 20 分钟，下一站 PT=30 分钟、QT=5 分钟，则 Step1 ETA=当前时间+20 分钟，Step2 ETA=当前时间+55 分钟。

缺失 PT 在累计中用零占位，同时累计 StepBad；只要任一上游步骤缺失，目标 ETA_Status=UPSTREAM_TIME_MISSING 且 ETA 为空。目标站自己的 PT 缺失不影响到达它的时间，但会阻断再下一站 ETA。路径计数与 StepIndex 不一致时标记 PATH_GAP。不能将累计用的零占位视为有效的零耗时。

将来新 ETA 方法接入时：
1. 保留 LotID、TargetContext、StepIndex、SnapshotTime，作为预测标识和时间基准。
2. 将新方法结果通过 CrossRef 按完整键接入，检查预测数量唯一和快照时效。
3. 修改 ETA_Adapter_Status 和 ETA_Adapter_Value，输出 ETA_Status 和 ETA_Value(Instant)。新方法无需沿用累计算法；缺失时必须明确选择留空或显式 baseline fallback。
4. 更新 ETA_Method，避免新算法结果仍标记为 baseline。
5. 保留 Output_Fields 后续接口；SnapshotTime 应在一次运行内一致。外部算法需要时间戳/时区约定。

## 输出与下游边界

三个 DispatchScreen：
- HBLP_InputDiagnostics：输入 lot 的 WIP 与筛选状态。
- HBLP_Diagnostics：包括 Step0 在内的路径、PT、累计量、ETA、方法和问题。
- HBLP_DSS_Test：仅未来站、Message 为空的记录，原 DSS 的 27 列顺序。

不要默认 status_tool 自动选中正确屏幕；需在 Editor 中设置导出屏幕为 HBLP_DSS_Test，检查编译后的 Queries/Headings，再使用测试导出器。

27 列形状兼容不表示业务完全等价：
- Route/FlowPlan/FlowContext 暂沿用当前 lot 上下文，目标上下文在诊断和 LPOpenField3。替换原 DSS 前应确认上游导出约定。
- DeltaToETA_Mins 故意留空，避免把“从现在起剩余时间”冒充原 SQL 的累计时间。Tuner 会将空值转 0；因此 v1 只能接隔离的测试 Tuner，测试中禁用 Delta-to-ETA 过滤并明确记录此差异，生产接入前必须完成字段语义映射。
- Split/Hold/Merge/Instruction/SIF 等输出为空不代表已验证没有限制。v1 只按 LiveDB 当前 hold/rework 筛选，仍需要现有 Tuner 的路径标记检查。
- PredictedEntityName 只表示按名称选择的候选，不代表资格、可用性、推荐最优或已预约。
- LPOpenField1..5 为本草稿的诊断用途，上线前确认下游没有占用这些字段。
- 不包含真实 QT 模型、R2A、skip 统计、设备资格、完整返工、batch 预测、历史评估和清理。

## 现场操作顺序

1. 在 APF Editor 建立测试副本 `RPT_HBLP_BASELINE_V1_TEST`，不要覆盖现有 Tuner 或原始 DSS。
2. 尝试打开 SOURCE.report。若提示缺少 XMLMD5、编译数据或格式不支持，停止把它当已编译文件导入：使用 block_plan.csv 在 Editor 新建图，或使用该版本正式支持的 XML 导入方式。不要伪造 MD5，也不要复制旧 EngineCode。Editor 编译和保存负责生成与源码一致的元数据。
3. 宏的路径是 `c/DISPATCHER/c/RULES/d/MacroExport/`。在 Editor 重新选择宏并刷新参数和导出列；确认 split 宏存在。
4. 将 HBLP_TEST_LOTS_V1 放入测试 Dispatcher 的 `$APFMODELCLASS`。既有脚本对应的目录是 `D:\APF\apfhome\models\WorkStreamClassic\class`，以该环境变量实际值为准。
5. 把默认禁用行替换成一条真实、非 hold、非 rework 的测试 Hot Lot，填入当前站剩余时间及明确的测试 QT，Enabled=Y。
6. 检查 Seed_Unique/WIP_Validate，再检查 Path_Attach_1 和 Path_Valid_1；确认第一步确实是下一站，随后再看第 2..5 步。
7. 检查 PT_Macro 对每个请求只返回一条，重点检查 fallback 路径仍返回 quantity。存在多条时先修正关联和去重规则，不要用任意 FIRST 隐藏冲突。
8. 检查 HBLP_Diagnostics 的累计量、方法和 ETA。核对字符 MIN、COUNT、字段大小写、参数类型、日期格式及空值处理在该 Editor 版本能通过编译。
9. 增加边界样本：不同 lot 共用 context、相同 operation 在路径重复出现、跨 route、流程末尾、缺 PT、候选设备缺失、重复测试 lot、hold/rework。后续单站缺时间不能导致更远站 ETA 虚假提前。
10. 验证通过后再输出 `LP_Predictions_APF_Test`，让复制的测试 Tuner 读取它。保持原来的生产文件和任务不变；比较原始 ETA 与 Tuner 修正后的 ETA，不要混为一个指标。

后续全 WIP 化：在 Editor 从 WIP_LOT folder 选择真实的 lot key 字段，并确认 HotLot/Owner/Active/Terminated、hold、priority、数量字段，替换 Seed_Import 与 seed 筛选部分。给 WIP 分配 QueueMinutes/CurrentRemainingMinutes 不是最终方案，应由 QT 和 remaining-time 数据模块提供；后续管道接口保持不变。

## 验证状态

已验证 XML 可解析、SOURCE wrapper 可往返还原 XML、64 个积木名称唯一、上游连接存在、图无环、DSS 输出列数为 27。未验证 APF Editor 打开、编译、宏实际返回和 LiveDB 执行。请优先回传 Editor 首个报错及对应积木，或成功预览的 Path_Attach_1 和 PT_Attach 数据，以便针对现场类型/格式完成下一轮修改。
