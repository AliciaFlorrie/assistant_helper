from pathlib import Path
import xml.etree.ElementTree as E
import csv, json, zipfile

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'HBLP_Rule_Draft_v1'
OUT.mkdir(exist_ok=True)
r=E.Element('blocks'); objects=E.SubElement(r,'objects',linkstatus='correct')
records=[]
def expr(parent,value,name=None):
    return E.SubElement(parent,'expression',expr=value,name=name or value)
def block(name,kind,inputs=(),**attrs):
    i=len(records); x=(i%6)*3500+850; y=(i//6)*1800+850
    o=E.SubElement(objects,'object',name=name,type=kind,left=str(x),right=str(x+850),top=str(y),bottom=str(y+850),selected='0')
    c=E.SubElement(o,'connections')
    for j,n in enumerate(inputs): E.SubElement(c,'connection',block=n,ordinal=str(j))
    p=E.SubElement(o,'persistence',type='xml',model='WorkStreamClassic',repository='LiveDB',comment='',**attrs)
    records.append({'name':name,'type':kind,'inputs':list(inputs),'attrs':attrs,'element':o})
    return p
def fn(name,source,fields):
    p=block(name,'Function',[source]); f=E.SubElement(p,'functions')
    for n,v in fields.items():expr(f,v,n)
    return name
def select(name,source,condition):block(name,'Select',[source],expression=condition);return name
def cross(name,left,right,keys,added):
    p=block(name,'CrossRef',[left,right],non_unique_detection='0');a=E.SubElement(p,'addedcols')
    for n,v in added.items():expr(a,v,n)
    pairs=E.SubElement(p,'crossreflist')
    for l,rr in keys:
        pair=E.SubElement(pairs,'pair');expr(E.SubElement(pair,'left'),l);expr(E.SubElement(pair,'right'),rr)
    return name
def macro(name,source,file,table,parameters,outputs):
    p=block(name,'MacroFunction',[source],macro='c/DISPATCHER/c/RULES/d/MacroExport/'+file,export='MacroExport',macroflags='263936')
    for key in ['cached_columns','inputs_to_macro']:
        a=E.SubElement(p,key)
        for col in outputs:expr(a,'',col)
    c=E.SubElement(p,'table_connection',argument=source,table_name=table)
    for n,v in parameters.items():expr(E.SubElement(E.SubElement(c,'parameter',name=n),'column'),v)
    return name
def compress(name,source,categories,aggregates):
    p=block(name,'Compress',[source]);c=E.SubElement(p,'categories')
    for k in categories:expr(c,k)
    f=E.SubElement(p,'functions')
    for name_,(op,col) in aggregates.items():expr(E.SubElement(E.SubElement(f,'function',function=op,newcolumn=name_),'compresscol'),col)
    return name
def cum(name,source,col,out):
    p=block(name,'Cumulate',[source],newcolumn=out);expr(E.SubElement(p,'cumulate'),col);expr(E.SubElement(p,'categories'),'LotID');return name
def screen(name,source,columns):
    p=block(name,'DispatchScreen',[source],additionalflags='4103',dlis_client='')
    expr(E.SubElement(p,'lot'),'LotID');E.SubElement(p,'batch');expr(E.SubElement(p,'oper'),'Oper');E.SubElement(p,'select')
    cols=E.SubElement(p,'columns')
    for c in columns:expr(E.SubElement(E.SubElement(cols,'dispcolumn',format='',header='',width='12'),'expression'),c)

block('Seed_Import','Import',url='HBLP_TEST_LOTS_V1',import_flags='1549')
select('Seed_Enabled','Seed_Import','Enabled == "Y"')
compress('Seed_OneRowPerLot','Seed_Enabled',['LotID'],{'SeedCount':('COUNT','LotID'),'QueueMinutes':('FIRST','QueueMinutes'),'CurrentRemainingMinutes':('FIRST','CurrentRemainingMinutes')})
select('Seed_Unique','Seed_OneRowPerLot','SeedCount == 1')
fn('WIP_Read','Seed_Unique',{
 'SnapshotTime':'$Now','CurrentOper':'WIP_LOT{LotID}.lfb_oper','CurrentOperVersion':'WIP_LOT{LotID}.lfb_oper_version',
 'CurrentRoute':'WIP_LOT{LotID}.lfb_route','CurrentFlowPlan':'WIP_LOT{LotID}.lfb_flowplan',
 'Current_FP_RT_rowid':'WIP_LOT{LotID}.flowplan_route_row_id','Current_RT_OP_rowid':'WIP_LOT{LotID}.route_oper_row_id',
 'WaferQty':'INTEGER(WIP_LOT{LotID}.lot_same_uom_prim_qty)','LotHold':'WIP_LOT{LotID}.lot_hold_flag','LotRework':'WIP_LOT{LotID}.lot_rework_flag'})
fn('WIP_Validate','WIP_Read',{'InputStatus':'IF NULL(CurrentOper) OR NULL(Current_RT_OP_rowid) OR Current_RT_OP_rowid <= 0 THEN "WIP_NOT_FOUND_OR_CONTEXT_MISSING" ELSE IF LotHold != 0 THEN "HOLD" ELSE IF LotRework != 0 THEN "REWORK_NOT_SUPPORTED_V1" ELSE IF NULL(WaferQty) OR WaferQty <= 0 THEN "INVALID_QTY" ELSE IF NULL(QueueMinutes) OR QueueMinutes < 0 THEN "INVALID_TEST_QT" ELSE "OK"','Oper':'CurrentOper'})
select('WIP_Valid','WIP_Validate','InputStatus == "OK"')
fn('Context_Seed','WIP_Valid',{'OriginalContext':'STRING(Current_FP_RT_rowid)+":"+STRING(Current_RT_OP_rowid)'})
common=['LotID','SnapshotTime','CurrentOper','CurrentRoute','CurrentFlowPlan','OriginalContext','QueueMinutes','CurrentRemainingMinutes','WaferQty','StepIndex','Oper','OperVersion','TargetRoute','TargetFlowPlan','TargetContext']
fn('Path_Step0','Context_Seed',{'StepIndex':'0','Oper':'CurrentOper','OperVersion':'CurrentOperVersion','TargetRoute':'CurrentRoute','TargetFlowPlan':'CurrentFlowPlan','TargetContext':'OriginalContext'})
branches=['Path_Step0']
pathoutputs=['NextX_FP_RT_rowid','NextX_RT_OP_rowid','FoundOper','EndOfFlow','NextXOper_Name','NextXOper_Version','NextXRoute_Name','NextXRoute_Version','NextXFlowPlan_Name','NextXFlowPlan_Version','ActualNextXSteps','_Current_FP_RT_rowid','_Current_RT_OP_rowid','_OperToSearch','_NextXSteps']
for n in range(1,6):
    inp=fn(f'Path_Request_{n}','Context_Seed',{'NextXSteps':str(n),'OperToSearch':'INTEGER ""'})
    req=compress(f'Path_UniqueRequest_{n}',inp,['Current_FP_RT_rowid','Current_RT_OP_rowid','NextXSteps','OperToSearch'],{})
    m=macro(f'Path_Macro_{n}',req,'get_RT_NextXOper_Func_F68_9_7.report','_PCInput',{c:c for c in ['Current_FP_RT_rowid','Current_RT_OP_rowid','NextXSteps','OperToSearch']},pathoutputs)
    cr=cross(f'Path_Attach_{n}',inp,m,[('Current_FP_RT_rowid','_Current_FP_RT_rowid'),('Current_RT_OP_rowid','_Current_RT_OP_rowid'),('NextXSteps','_NextXSteps')],{c:c for c in pathoutputs[:11]})
    valid=select(f'Path_Valid_{n}',cr,f'FoundOper AND FULL(NextXOper_Name) AND FULL(NextX_RT_OP_rowid) AND NextX_RT_OP_rowid > 0 AND ActualNextXSteps == {n} AND (NextX_RT_OP_rowid != Current_RT_OP_rowid OR NextX_FP_RT_rowid != Current_FP_RT_rowid)')
    branches.append(fn(f'Path_Step{n}',valid,{'StepIndex':str(n),'Oper':'NextXOper_Name','OperVersion':'NextXOper_Version','TargetRoute':'NextXRoute_Name','TargetFlowPlan':'NextXFlowPlan_Name','TargetContext':'STRING(NextX_FP_RT_rowid)+":"+STRING(NextX_RT_OP_rowid)'}))
last=branches[0]
for i,b in enumerate(branches[1:],1):
    name=f'Path_Union_{i}';p=block(name,'Union',[last,b],lockedautopair='1',passunpaired='0');u=E.SubElement(p,'unionlist')
    for c in common:
        pair=E.SubElement(u,'pair');expr(E.SubElement(pair,'left'),c);expr(E.SubElement(pair,'right'),c)
    last=name

p=block('Entity_Source','Database',schema='APFREP:WorkStreamClassic:LiveDB',dbflags='1');expr(E.SubElement(p,'folder'),'EMC_ENTITY_SERVICE');cs=E.SubElement(p,'columns')
for c in ['ent_name','service_name']:expr(cs,'__FOLDER__.'+c,c)
select('Entity_Named','Entity_Source','MATCH(ent_name,"[A-Z]*") AND DoesNotContain(ent_name,"_")')
compress('Entity_Candidate','Entity_Named',['service_name'],{'CandidateEntity':('MIN','ent_name')})
cross('Entity_Attach',last,'Entity_Candidate',[('Oper','service_name')],{'PredictedEntityName':'CandidateEntity'})
fn('PT_Input','Entity_Attach',{'lot_number':'LotID','oper':'INTEGER(Oper)','route':'TargetRoute','quantity':'WaferQty','ClusterName':'IF FULL(PredictedEntityName) THEN DFS_ATTRIBUTE_CSIM_ENTITY{"CSIM_ENTITY",EMS_ENTITY{$APF_FAC,PredictedEntityName}.row_id,"ClusterName",0}.attribute_value ELSE ""'})
# The supplied macro drops ClusterName from its export. This version deliberately uses one candidate per operation.
compress('PT_UniqueRequests','PT_Input',['lot_number','oper','route','quantity','ClusterName'],{})
macro('PT_Macro','PT_UniqueRequests','get_LotProcessTime_Func_VF_7_9.report','GetLotProcessTime',{c:c for c in ['lot_number','oper','route','quantity','ClusterName']},['lot_number','oper','route','quantity','LotProcessTime','SourceOfProcessTime'])
cross('PT_Attach','PT_Input','PT_Macro',[('lot_number','lot_number'),('oper','oper'),('route','route'),('quantity','quantity')],{'LotProcessTime':'LotProcessTime','SourceOfProcessTime':'SourceOfProcessTime'})
fn('ETA_Features','PT_Attach',{
 'One':'1',
 'StepBad':'IF StepIndex == 0 AND FULL(CurrentRemainingMinutes) AND CurrentRemainingMinutes >= 0 THEN 0 ELSE IF FULL(LotProcessTime) AND LotProcessTime > DURATION(0) THEN 0 ELSE 1',
 'StepDuration':'IF StepIndex == 0 AND FULL(CurrentRemainingMinutes) AND CurrentRemainingMinutes >= 0 THEN DURATION(CurrentRemainingMinutes * 60) ELSE IF FULL(LotProcessTime) AND LotProcessTime > DURATION(0) THEN LotProcessTime + DURATION(QueueMinutes * 60) ELSE DURATION(0)',
 'ETA_Method':'IF FULL(CurrentRemainingMinutes) AND CurrentRemainingMinutes >= 0 THEN "BASELINE_WITH_MANUAL_CURRENT_REMAINING" ELSE "BASELINE_FULL_CURRENT_PT"'})
p=block('ETA_Sort','Sort',['ETA_Features']);sl=E.SubElement(p,'sortlist')
for c in ['LotID','StepIndex']:expr(E.SubElement(E.SubElement(sl,'item',direction='up'),'sortcol'),c)
cum('ETA_CumulateDuration','ETA_Sort','StepDuration','CumulativeDuration')
cum('ETA_CumulateMissing','ETA_CumulateDuration','StepBad','CumulativeBad')
cum('ETA_CumulateCount','ETA_CumulateMissing','One','CumulativeCount')
fn('ETA_Adapter_Status','ETA_CumulateCount',{'ETA_Status':'IF CumulativeCount != StepIndex + 1 THEN "PATH_GAP" ELSE IF CumulativeBad - StepBad > 0 THEN "UPSTREAM_TIME_MISSING" ELSE "OK"','BaselineOffset':'CumulativeDuration - StepDuration'})
fn('ETA_Adapter_Value','ETA_Adapter_Status',{'ETA_Value':'IF ETA_Status == "OK" THEN SnapshotTime + BaselineOffset ELSE INSTANT("")'})
fn('Output_Fields','ETA_Adapter_Value',{
 'Message':'IF ETA_Status != "OK" THEN ETA_Status ELSE IF NULL(PredictedEntityName) THEN "NO_ENTITY_CANDIDATE" ELSE ""',
 'ETA':'IF FULL(ETA_Value) THEN FORMAT(ETA_Value,"dd/mm/yy hh:mm:ss") ELSE ""',
 'UpdateTime':'FORMAT(SnapshotTime,"dd/mm/yy hh:mm:ss")',
 'Route':'CurrentRoute','FlowPlan':'CurrentFlowPlan','FlowContext':'OriginalContext',
 **{c:'""' for c in ['SplitFlag','HoldFlag','MergeFlag','CommentFlag','InstructionFlag','SIFFlag','SIFDataFlag','SIFTool','BatchRecipe','BatchTool','BatchID','BatchStartTime','DeltaToETA_Mins']},
 'LPOpenField1':'ETA_Method','LPOpenField2':'ETA_Status','LPOpenField3':'TargetContext','LPOpenField4':'STRING(StepIndex)','LPOpenField5':'"DRAFT_ONLY_NOT_QUALIFIED"'})
diag=['LotID','Oper','StepIndex','CurrentOper','TargetRoute','TargetFlowPlan','TargetContext','OriginalContext','PredictedEntityName','ClusterName','LotProcessTime','SourceOfProcessTime','QueueMinutes','CurrentRemainingMinutes','StepDuration','StepBad','CumulativeBad','CumulativeCount','BaselineOffset','ETA','ETA_Status','ETA_Method','Message']
screen('HBLP_Diagnostics','Output_Fields',diag)
screen('HBLP_InputDiagnostics','WIP_Validate',['LotID','Oper','CurrentRoute','CurrentFlowPlan','Current_FP_RT_rowid','Current_RT_OP_rowid','WaferQty','LotHold','LotRework','InputStatus'])
select('Output_Valid','Output_Fields','StepIndex > 0 AND NULL(Message)')
cols='PredictedEntityName LotID Oper OperVersion Route FlowPlan ETA FlowContext SplitFlag HoldFlag MergeFlag CommentFlag InstructionFlag SIFFlag SIFDataFlag SIFTool UpdateTime BatchRecipe BatchTool BatchID BatchStartTime DeltaToETA_Mins LPOpenField1 LPOpenField2 LPOpenField3 LPOpenField4 LPOpenField5'.split()
screen('HBLP_DSS_Test','Output_Valid',cols)
E.SubElement(E.SubElement(r,'additionalobjects'),'groups')
f=E.SubElement(r,'formatter',layout_type='16',model='WorkStreamClassic');d=E.SubElement(f,'documentation');E.SubElement(d,'docentry',key='Status',value='SOURCE DRAFT - COMPILE AND VALIDATE IN APF EDITOR')
E.SubElement(E.SubElement(r,'environments'),'environment',flags='769',name='formatter%5Cformatter.env')
E.indent(r)
xml=E.tostring(r,encoding='unicode')
(OUT/'RPT_HBLP_BASELINE_V1.blocks.xml').write_text(xml,encoding='utf-8')
# Source-only wrapper. Deliberately no stale EngineCode, Description.Queries or invented XMLMD5.
(OUT/'RPT_HBLP_BASELINE_V1_SOURCE.report').write_text('{\n    XMLBlocks: {\n        XML: "'+xml.replace('"','\\"')+'"\n    }\n}\n',encoding='utf-8')
with (OUT/'block_plan.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.writer(f);w.writerow(['block','type','upstream','settings_and_expressions'])
 for b in records:w.writerow([b['name'],b['type'],','.join(b['inputs']),E.tostring(b['element'].find('persistence'),encoding='unicode')])
(OUT/'HBLP_TEST_LOTS_V1').write_text('#ISS\n#info 4 LotID:String Enabled:String QueueMinutes:Real CurrentRemainingMinutes:Real\nREPLACE_WITH_REAL_LOT|N|5|-1\n',encoding='ascii')
(OUT/'eta_contract.json').write_text(json.dumps({'status':'DRAFT_UNCOMPILED','key':['LotID','TargetContext','StepIndex'],'snapshot':'SnapshotTime','replace_blocks':['ETA_Adapter_Status','ETA_Adapter_Value'],'output':{'ETA_Value':'Instant, arrival at target operation','ETA_Status':'OK or explicit unavailable reason','ETA_Method':'algorithm identifier'},'baseline':'SnapshotTime + sum(StepDuration for prior steps)','current_remaining':'manual nonnegative minutes; otherwise full current PT + configured QT, explicitly approximate','DeltaToETA_Mins':'empty in draft; do not enable legacy delta filter until semantic mapping is agreed','route_policy':'raw 27-column interface keeps current Route/FlowPlan/FlowContext; diagnostics retains target values','publication':'test output only; no qualification or automatic production export'},indent=2),encoding='utf-8')
# Structural checks only; these are not APF compiler checks.
names={b['name'] for b in records};assert len(names)==len(records)
for b in records:assert all(x in names for x in b['inputs'])
assert len(cols)==27
seen=set();active=set();by={b['name']:b for b in records}
def visit(n):
 assert n not in active
 if n in seen:return
 active.add(n)
 for x in by[n]['inputs']:visit(x)
 active.remove(n);seen.add(n)
for n in names:visit(n)
E.fromstring(xml)
wrapped=(OUT/'RPT_HBLP_BASELINE_V1_SOURCE.report').read_text();assert E.tostring(E.fromstring(wrapped[wrapped.index('<blocks>'):wrapped.index('</blocks>')+9].replace('\\"','"')))==E.tostring(E.fromstring(xml))
report={'checks':{'xml_well_formed':True,'wrapper_roundtrip':True,'unique_blocks':True,'connections_resolve':True,'acyclic_graph':True,'dss_columns':len(cols)},'block_count':len(records),'apf_compile':'NOT RUN - APF Editor unavailable','live_db_execution':'NOT RUN','known_gates':['Editor source import support','typed macro parameter binding','PT macro request/return uniqueness','Instant format support','MIN on String candidate','COUNT aggregate syntax','LiveDB and class file availability','DeltaToETA_Mins contract']}
(OUT/'validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
