import argparse
import json
from pathlib import Path
from . import datasources, graph_store
from .oracle_tools import sync_schema

def main():
    p=argparse.ArgumentParser(description='SQL Template -> incremental graph knowledge')
    sub=p.add_subparsers(dest='command',required=True)
    imp=sub.add_parser('import-sql'); imp.add_argument('path'); imp.add_argument('--datasource',default='xeus',required=False); imp.add_argument('--id'); imp.add_argument('--title'); imp.add_argument('--description',default='')
    sync=sub.add_parser('sync-schema'); sync.add_argument('--datasource',default='xeus',required=False)
    search=sub.add_parser('search'); search.add_argument('query'); search.add_argument('--datasource')
    path=sub.add_parser('paths'); path.add_argument('--datasource',required=True); path.add_argument('--from-table',required=True); path.add_argument('--to-table',required=True)
    sub.add_parser('datasources')
    a=p.parse_args()
    if a.command=='datasources': result=datasources.directory()
    elif a.command=='sync-schema': result=sync_schema(a.datasource)
    elif a.command=='import-sql':
        ds=datasources.get(a.datasource)
        sql=Path(a.path).read_text(encoding='utf8')
        tables, _ = graph_store.extract(sql, a.datasource)
        allowed_tables = {t.upper() for t in ds['allowed_tables']}
        new_tables = []
        for t in tables:
            table_name = '.'.join(t.split('.')[-1:]).upper()
            if table_name not in allowed_tables:
                datasources.add_allowed_table(a.datasource,table_name)
                allowed_tables.add(table_name)
                new_tables.append(table_name)
        result=graph_store.ingest(a.id or Path(a.path).stem,a.datasource,a.title or Path(a.path).stem,a.description,sql)
        if new_tables:
            result['message'] = ('New table has been added: '+ ', '.join(sorted(new_tables)))
    elif a.command=='search': result={'tables':graph_store.search_tables(a.query,a.datasource),'examples':graph_store.search_examples(a.query,a.datasource)}
    else:
        ds=datasources.get(a.datasource)
        result=graph_store.find_paths(f"{a.datasource}.{a.from_table.upper()}",f"{a.datasource}.{a.to_table.upper()}",a.datasource)
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__': main()
