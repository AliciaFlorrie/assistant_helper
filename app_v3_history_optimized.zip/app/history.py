"""Build a disposable model context without mutating the execution audit."""
import json
import os


def size(value):
    return len(json.dumps(value, ensure_ascii=False, default=str))


def compact_history(history, budget=None):
    budget = int(os.getenv('HISTORY_MAX_CHARS', '60000')) if budget is None else budget
    selected = {}
    for item in history:
        a, args = item['action'], item.get('arguments', {})
        ds = args.get('datasource')
        if a == 'get_table_schema' and not item.get('error'):
            selected.setdefault(ds, set()).add(args.get('table', '').split('.')[-1].upper())
        if a == 'find_join_paths' and not item.get('error'):
            selected.setdefault(ds, set()).update(str(args[k]).split('.')[-1].upper() for k in ('start','end') if k in args)
    last_failure = max((i for i,x in enumerate(history) if x['action']=='query' and (x.get('error') or (isinstance(x.get('result'),dict) and x['result'].get('error')))), default=-1)
    out = []
    for i, item in enumerate(history):
        a = item['action']; args = dict(item.get('arguments', {})); r = item.get('result')
        entry = {'action':a,'arguments':args}
        if 'error' in item:
            entry['error'] = item['error']
        elif a in ('search_tables','get_table_schema') and i < last_failure:
            entry['result'] = 'Omitted after query failure; retrieve again if needed.'
        elif a == 'search_tables' and isinstance(r,list) and i != len(history)-1:
            names = [x['table'] for x in r if isinstance(x,dict) and 'table' in x]
            chosen = [n for n in names if n.split('.')[-1].upper() in selected.get(args.get('datasource'),set())]
            entry['result'] = {'selected_tables':chosen} if chosen else {'candidate_tables':names}
        elif a == 'get_table_schema' and isinstance(r,dict) and 'columns' in r:
            entry['result'] = {'table':r.get('table'), 'fields': ', '.join(str(c.get('name','')) if isinstance(c,dict) else str(c) for c in r['columns'])}
        elif a == 'search_datasources' and isinstance(r,list) and i != len(history)-1:
            entry['result'] = [x.get('datasource') for x in r if isinstance(x,dict)]
        else:
            entry['result'] = r
        out.append(entry)
    # Soft character budget: retain action ledger, full examples and failed SQL.
    # Remove older successful result payloads first, never silently sample the latest result.
    for i, entry in enumerate(out):
        if size(out) <= budget: break
        if i == len(out)-1 or entry['action'] in ('search_examples','query') and (entry['action']=='search_examples' or entry.get('error') or (isinstance(entry.get('result'),dict) and entry['result'].get('error'))): continue
        if 'result' in entry:
            entry['result'] = 'Omitted for context budget; retrieve again if needed.'
    return out
