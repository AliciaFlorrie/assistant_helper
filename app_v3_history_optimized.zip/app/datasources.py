"""Named Oracle database services. Credentials are environment-only."""
import os
from pathlib import Path
import yaml
from . import config

CONFIG_PATH = Path(os.getenv('DATASOURCES_FILE', 'config/datasources.yaml'))

def registry():
    raw = yaml.safe_load(CONFIG_PATH.read_text(encoding='utf8')) or {}
    sources = raw.get('datasources', {})
    result = {}
    for name, item in sources.items():
        if not isinstance(item, dict):
            raise ValueError(f'Invalid datasource {name}')
        result[name] = {**item, 'allowed_tables': [str(t).upper() for t in item.get('allowed_tables', []) if t]}
    return result

def get(name):
    sources = registry()
    if name not in sources:
        raise ValueError(f'Unknown datasource: {name}')
    return sources[name]

def open_connection(name):
    import cx_Oracle
    item = get(name)
    
    conn_env = item.get("conn_env", "ORACLE_CONN")
    conn_str = os.getenv(conn_env)
    if not conn_str:
        raise RuntimeError(f"{conn_env} environment variable is not set")
    return cx_Oracle.connect(conn_str)

def directory():
    return [{'datasource': k, 'description': v.get('description',''),'tables': len(v.get('allowed_tables',[]))} for k,v in registry().items()]

def add_allowed_table(datasource, table_name):
    if not CONFIG_PATH.exists():
        raise RuntimeError("datasources.yaml not found")
    raw = yaml.safe_load(CONFIG_PATH.read_text(encoding='utf8')) or {}
    sources = raw.get('datasources', {})
    if datasource not in sources:
        raise ValueError(f'Unknown datasource: {datasource}')
    table_name = table_name.upper().strip()
    allowed = {str(t).upper().strip() for t in sources[datasource].get('allowed_tables', []) if t}
    if table_name not in allowed:
        allowed.add(table_name)        
        sources[datasource]['allowed_tables'] = sorted(allowed)
        CONFIG_PATH.write_text(yaml.safe_dump(raw,allow_unicode=True,sort_keys=False),encoding='utf8')