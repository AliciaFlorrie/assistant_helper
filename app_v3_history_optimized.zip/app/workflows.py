from datetime import timedelta
from temporalio import workflow
from temporalio.common import RetryPolicy
with workflow.unsafe.imports_passed_through():
    from .activities import load_schema, knowledge_action, model_step, run_query
    from .config import MAX_STEPS

@workflow.defn
class SQLAgentWorkflow:
    @workflow.run
    async def run(self,question:str)->dict:
        directory=await workflow.execute_activity(load_schema,start_to_close_timeout=timedelta(seconds=300))
        history=[]; sql_count=0
        for turn in range(MAX_STEPS*4+1):
            must_finish=turn==MAX_STEPS*4 or sql_count>=MAX_STEPS
            decision=await workflow.execute_activity(model_step,{'question':question,'catalog':directory,'history':history,'max_steps_reached':must_finish},start_to_close_timeout=timedelta(seconds=300),retry_policy=RetryPolicy(maximum_attempts=2))
            if decision['action']=='final': return {'answer':decision['answer'],'steps':history}
            if must_finish: break
            item={'action':decision['action'],'arguments':{k:v for k,v in decision.items() if k!='action'}}
            try:
                if decision['action']=='query':
                    sql_count+=1
                    result=await workflow.execute_activity(run_query,{'datasource':decision['datasource'],'sql':decision['sql'],'params':decision['params']},start_to_close_timeout=timedelta(seconds=300),retry_policy=RetryPolicy(maximum_attempts=1))
                else:
                    result=await workflow.execute_activity(knowledge_action,decision,start_to_close_timeout=timedelta(seconds=300))
                item['result']=result
            except Exception as exc:
                # Temporal wraps Activity errors; retain the underlying Oracle message.
                messages=[]
                cause=exc
                for _ in range(8):
                    if cause is None: break
                    messages.append(str(cause))
                    cause=getattr(cause,'cause',None) or getattr(cause,'__cause__',None)
                item['error']=' | '.join(messages)[:4000]
            history.append(item)
        return {'answer':'Tool budget exhausted; unable to establish a fully supported answer.','steps':history}
