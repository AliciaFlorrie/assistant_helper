from temporalio import activity
from . import datasources, graph_store
from .oracle_tools import schema_catalog, execute_sql
from .agent import decide
import asyncio

@activity.defn
async def load_schema():
    # Only datasource names/descriptions enter the initial prompt.
    return datasources.directory()

@activity.defn
async def knowledge_action(payload:dict):
    def run():
        a=payload['action']
        if a=='search_datasources':
            return datasources.directory()
        ds=payload['datasource']
        item=datasources.get(ds)
        if a=='search_tables':
            return graph_store.search_tables(payload['query'],ds)
        if a=='get_table_schema':
            name=payload['table'].upper()
            if name not in item['allowed_tables']: raise ValueError('Table not allowed')
            result=graph_store.get_table_metadata(ds,name)
            return result or {'table':name,'message':'Metadata unavailable; run sync-schema'}
        if a=='find_join_paths':
            start=payload['start'].upper(); end=payload['end'].upper()
            if start not in item['allowed_tables'] or end not in item['allowed_tables']: raise ValueError('Table not allowed')
            return graph_store.find_paths(graph_store.table_key(ds,start),graph_store.table_key(ds,end),ds)
        if a=='search_examples':
            return graph_store.search_examples(payload['query'],ds)
        raise ValueError('Unknown knowledge action')
    return await asyncio.to_thread(run)

@activity.defn
async def model_step(payload:dict):
    return await asyncio.to_thread(decide,payload['question'],payload['catalog'],payload['history'],payload['max_steps_reached'])

@activity.defn
async def run_query(payload:dict):
    return await asyncio.to_thread(execute_sql,payload['datasource'],payload['sql'],payload['params'])
