import unittest
from app.history import compact_history

class HistoryTest(unittest.TestCase):
    def test_compaction(self):
        h=[{'action':'search_tables','arguments':{'datasource':'mes'},'result':[{'table':'mes.A','description':'long'},{'table':'mes.B'}]}, {'action':'get_table_schema','arguments':{'datasource':'mes','table':'A'},'result':{'table':'mes.A','columns':[{'name':'ID','type':'NUMBER','nullable':False}]}}, {'action':'search_examples','arguments':{},'result':[{'sql':'SELECT ID FROM A'}]}]
        c=compact_history(h)
        self.assertEqual(c[0]['result'],{'selected_tables':['mes.A']})
        self.assertEqual(c[1]['result']['fields'],'ID')
        self.assertEqual(c[2],h[2])
        self.assertIn('type',h[1]['result']['columns'][0])
        h.append({'action':'query','arguments':{'sql':'SELECT X FROM A','params':{}},'error':'ORA-00904'})
        c=compact_history(h,1)
        self.assertEqual(c[-1],h[-1]); self.assertEqual(c[2],h[2]); self.assertEqual(len(c),len(h))
        self.assertIn('Omitted',c[1]['result'])
    def test_latest_candidates(self):
        h=[{'action':'search_tables','arguments':{},'result':[{'table':'A','description':'ID'}]}]
        self.assertEqual(compact_history(h),h)

if __name__=='__main__': unittest.main()
