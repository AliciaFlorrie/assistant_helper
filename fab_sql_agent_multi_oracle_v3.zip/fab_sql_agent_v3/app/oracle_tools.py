"""Oracle query executor: one datasource per query, readonly account mandatory."""
import re
import time
from contextlib import contextmanager
from sqlglot import parse, exp
from . import config, datasources, graph_store

IDENT = re.compile(r'^[A-Z][A-Z0-9_$#]*$')

@contextmanager
def readonly_connection(datasource):
    conn = datasources.open_connection(datasource)
    try:
        conn.call_timeout = config.SQL_TIMEOUT_MS
        with conn.cursor() as cur:
            cur.execute('SET TRANSACTION READ ONLY')
        yield conn
    finally:
        conn.close()

def permitted_tables(datasource):
    ds = datasources.get(datasource)
    allowed = set(ds.get('allowed_tables', []))
    if not allowed:
        # Tables referenced by imported templates are approved only if explicitly enabled.
        raise ValueError(f'{datasource}: configure allowed_tables; do not infer grants from templates')
    return allowed

def validate_sql(datasource, sql, params):
    ds = datasources.get(datasource)
    if not isinstance(sql,str) or len(sql)>12000 or '@' in sql:
        raise ValueError('Invalid SQL length or DB link syntax')
    if not isinstance(params,dict): raise ValueError('params must be object')
    statements = parse(sql, read='oracle')
    if len(statements)!=1 or not isinstance(statements[0],(exp.Select,exp.Union,exp.Intersect,exp.Except)):
        raise ValueError('Only a single SELECT statement is permitted')
    ast = statements[0]
    blocked = (exp.Insert,exp.Update,exp.Delete,exp.Create,exp.Drop,exp.Alter,exp.Command,exp.Merge,exp.Transaction,exp.Into)
    if any(isinstance(node,blocked) for node in ast.walk()): raise ValueError('Mutation prohibited')
    if re.search(r'\bFOR\s+UPDATE\b|\bDBMS_|\bUTL_|\bSYS\.',sql,re.I):
        raise ValueError('Disallowed SQL operation/function')
    ctes={cte.alias.upper() for cte in ast.find_all(exp.CTE) if cte.alias}
    found=set()
    for table in ast.find_all(exp.Table):
        if table.name.upper() in ctes: continue
        owner=(table.db or ds['schema']).upper()
        name=table.name.upper()
        if not IDENT.fullmatch(owner) or not IDENT.fullmatch(name): raise ValueError('Invalid table identifier')
        if owner != ds['schema'] or name not in permitted_tables(datasource):
            raise ValueError(f'Unauthorized object {owner}.{name} on {datasource}')
        found.add(name)
    if not found: raise ValueError('SELECT must reference allowed tables')
    for name,value in params.items():
        if not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*',name): raise ValueError('Invalid bind name')
        if not isinstance(value,(str,int,float,type(None))): raise ValueError('Unsupported bind value')
    placeholders={n.name for n in ast.find_all(exp.Placeholder) if n.name}
    if placeholders != set(params): raise ValueError(f'Bind mismatch {placeholders} vs {set(params)}')
    return sql

def execute_sql(datasource, sql, params):
    validate_sql(datasource,sql,params)
    started=time.monotonic()
    with readonly_connection(datasource) as conn:
        with conn.cursor() as cur:
            cur.execute(sql,params)
            names=[d[0].lower() for d in cur.description]
            rows=cur.fetchmany(config.MAX_ROWS+1)
            def clean(v):
                if v is None or isinstance(v,(str,int,float,bool)): return v
                return str(v)[:300]
            return {'datasource':datasource,'columns':names,'rows':[dict(zip(names,[clean(v) for v in row])) for row in rows[:config.MAX_ROWS]],'truncated':len(rows)>config.MAX_ROWS,'elapsed_ms':round((time.monotonic()-started)*1000)}

def sync_schema(datasource):
    ds=datasources.get(datasource)
    names=sorted(permitted_tables(datasource))
    with readonly_connection(datasource) as conn:
        with conn.cursor() as cur:
            for table in names:
                cur.execute('''SELECT c.column_name,c.data_type,c.nullable,cc.comments
                FROM all_tab_columns c LEFT JOIN all_col_comments cc
                ON c.owner=cc.owner AND c.table_name=cc.table_name AND c.column_name=cc.column_name
                WHERE c.owner=:owner AND c.table_name=:tbl ORDER BY c.column_id''',{'owner':ds['schema'],'tbl':table})
                columns=[{'name':r[0],'type':r[1],'nullable':r[2]=='Y','description':r[3] or ''} for r in cur.fetchall()]
                cur.execute('SELECT comments FROM all_tab_comments WHERE owner=:owner AND table_name=:tbl',{'owner':ds['schema'],'tbl':table})
                row=cur.fetchone()
                graph_store.save_table_metadata(datasource,ds['schema'],table,(row[0] if row and row[0] else ''),columns)
    return {'datasource':datasource,'tables_synced':len(names)}

def schema_catalog(datasource='default'):
    ds=datasources.get(datasource)
    return {name:graph_store.get_table_metadata(datasource,ds['schema'],name) for name in sorted(permitted_tables(datasource))}
