"""Named Oracle database services. Credentials are environment-only."""
import os
from pathlib import Path
import yaml
from . import config

CONFIG_PATH = Path(os.getenv('DATASOURCES_FILE', 'config/datasources.yaml'))

def registry():
    if CONFIG_PATH.exists():
        raw = yaml.safe_load(CONFIG_PATH.read_text(encoding='utf8')) or {}
        sources = raw.get('datasources', {})
    else:
        sources = {'default': {'description': 'Legacy Oracle connection', 'schema': os.getenv('ORACLE_SCHEMA', ''), 'conn_env': 'ORACLE_CONN', 'allowed_tables': os.getenv('ALLOWED_TABLES', '').split(',')}}
    result = {}
    for name, item in sources.items():
        if not isinstance(item, dict) or not item.get('schema'):
            raise ValueError(f'Invalid datasource {name}: schema required')
        result[name] = {**item, 'schema': str(item['schema']).upper(), 'allowed_tables': [str(t).upper() for t in item.get('allowed_tables', []) if t]}
    return result

def get(name):
    sources = registry()
    if name not in sources:
        raise ValueError(f'Unknown datasource: {name}')
    return sources[name]

def open_connection(name):
    item = get(name)
    try:
        import cx_Oracle as oracle
    except ImportError:
        import oracledb as oracle
    conn_env = item.get('conn_env')
    if conn_env and os.getenv(conn_env):
        # ORACLE_CONN is an Oracle Easy Connect / TNS DSN, not a SQL connection object.
        return oracle.connect(user=os.environ[item.get('user_env', 'ORACLE_USER')], password=os.environ[item.get('password_env', 'ORACLE_PASSWORD')], dsn=os.environ[conn_env])
    return oracle.connect(user=os.environ[item.get('user_env', 'ORACLE_USER')], password=os.environ[item.get('password_env', 'ORACLE_PASSWORD')], dsn=os.environ[item.get('dsn_env', 'ORACLE_DSN')])

def directory():
    return [{'datasource': k, 'description': v.get('description',''), 'schema': v['schema']} for k,v in registry().items()]
