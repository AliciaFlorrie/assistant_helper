"""SQLite incremental template knowledge: graph edges retain SQL provenance."""
import json
import os
import sqlite3
from pathlib import Path
from sqlglot import parse_one, exp

DB = Path(os.getenv('KNOWLEDGE_DB', 'data/knowledge.sqlite3'))

def connect():
    DB.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB))
    conn.row_factory = sqlite3.Row
    conn.executescript('''
    CREATE TABLE IF NOT EXISTS templates (
      id TEXT PRIMARY KEY, datasource TEXT NOT NULL, title TEXT NOT NULL,
      description TEXT NOT NULL, sql_text TEXT NOT NULL, tables_json TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS edges (
      template_id TEXT NOT NULL, edge_index INTEGER NOT NULL,
      source_table TEXT NOT NULL, target_table TEXT NOT NULL,
      predicate TEXT NOT NULL, join_kind TEXT NOT NULL,
      PRIMARY KEY (template_id, edge_index)
    );
    CREATE INDEX IF NOT EXISTS idx_edge_src ON edges(source_table);
    CREATE INDEX IF NOT EXISTS idx_edge_dst ON edges(target_table);
    CREATE TABLE IF NOT EXISTS table_metadata (
      datasource TEXT NOT NULL, owner TEXT NOT NULL, table_name TEXT NOT NULL,
      description TEXT NOT NULL DEFAULT '', columns_json TEXT NOT NULL DEFAULT '[]',
      PRIMARY KEY(datasource,owner,table_name)
    );
    ''')
    return conn

def table_key(datasource, owner, table):
    return f'{datasource}.{owner.upper()}.{table.upper()}'

def _tables(ast, datasource, default_schema):
    ctes = {x.alias.upper() for x in ast.find_all(exp.CTE) if x.alias}
    aliases = {}
    for table in ast.find_all(exp.Table):
        if table.name.upper() in ctes:
            continue
        owner = (table.db or default_schema).upper()
        key = table_key(datasource, owner, table.name)
        aliases[(table.alias_or_name or table.name).upper()] = key
    return aliases

def extract(sql, datasource, default_schema):
    ast = parse_one(sql, read='oracle')
    if not isinstance(ast, (exp.Select, exp.Union, exp.Intersect, exp.Except)):
        raise ValueError('Only SELECT templates are supported')
    aliases = _tables(ast, datasource, default_schema)
    edges = []
    # Only explicit JOIN ON predicates. Keep the full ON expression so compound conditions survive.
    for join in ast.find_all(exp.Join):
        on = join.args.get('on')
        if on is None:
            continue
        refs = {aliases.get(c.table.upper()) for c in on.find_all(exp.Column) if c.table}
        refs.discard(None)
        if len(refs) != 2:
            continue  # avoid guessing ambiguous multi-table/CTE lineage
        left, right = sorted(refs)
        edges.append({'source_table': left, 'target_table': right, 'predicate': on.sql(dialect='oracle'), 'join_kind': str(join.args.get('kind') or 'INNER').upper()})
    return sorted(set(aliases.values())), edges

def ingest(template_id, datasource, title, description, sql, schema):
    tables, edges = extract(sql, datasource, schema)
    if not tables:
        raise ValueError('No physical tables found in template')
    with connect() as db:
        db.execute('REPLACE INTO templates VALUES (?,?,?,?,?,?)', (template_id, datasource, title, description, sql, json.dumps(tables)))
        db.execute('DELETE FROM edges WHERE template_id=?', (template_id,))
        for idx, edge in enumerate(edges):
            db.execute('INSERT INTO edges VALUES (?,?,?,?,?,?)', (template_id, idx, edge['source_table'], edge['target_table'], edge['predicate'], edge['join_kind']))
    return {'id': template_id, 'tables': tables, 'edges': edges}

def search_tables(query, datasource=None, limit=8):
    tokens = [t.lower() for t in query.replace('_', ' ').split() if len(t)>1]
    with connect() as db:
        rows = db.execute('SELECT * FROM table_metadata').fetchall()
        templates = db.execute('SELECT * FROM templates').fetchall()
    out = {}
    for row in rows:
        if datasource and row['datasource'] != datasource: continue
        key = table_key(row['datasource'], row['owner'], row['table_name'])
        out[key] = {'table': key, 'description': row['description'], 'columns_count': len(json.loads(row['columns_json']))}
    for row in templates:
        if datasource and row['datasource'] != datasource: continue
        for key in json.loads(row['tables_json']):
            out.setdefault(key, {'table':key, 'description':'', 'columns_count':0})
            out[key]['description'] += ' ' + row['description'][:200]
    for item in out.values():
        hay = (item['table']+' '+item['description']).lower().replace('_',' ')
        item['score'] = sum(1 for token in tokens if token in hay)
    return sorted(out.values(), key=lambda x:(-x['score'],x['table']))[:limit]

def search_examples(query, datasource=None, limit=4):
    with connect() as db: rows = db.execute('SELECT * FROM templates').fetchall()
    tokens = [t.lower() for t in query.replace('_',' ').split() if len(t)>1]
    matches = []
    for row in rows:
        if datasource and row['datasource'] != datasource: continue
        hay = (row['title']+' '+row['description']+' '+row['tables_json']).lower().replace('_',' ')
        score = sum(t in hay for t in tokens)
        matches.append({'id':row['id'], 'datasource':row['datasource'], 'title':row['title'], 'description':row['description'], 'sql':row['sql_text'][:8000], 'score':score})
    return sorted(matches,key=lambda x:(-x['score'],x['id']))[:limit]

def find_paths(start, end, datasource, max_hops=3):
    """Breadth-first graph traversal; returns template-provenance per edge."""
    if not 1 <= max_hops <= 4: raise ValueError('max_hops must be 1..4')
    with connect() as db: rows = db.execute('SELECT * FROM edges').fetchall()
    adjacency = {}
    for r in rows:
        a,b = r['source_table'],r['target_table']
        if not (a.startswith(datasource+'.') and b.startswith(datasource+'.')): continue
        edge = dict(r)
        adjacency.setdefault(a,[]).append((b,edge))
        adjacency.setdefault(b,[]).append((a,edge))
    queue = [(start,[start],[])]
    paths = []
    while queue and len(paths)<5:
        node, visited, edges = queue.pop(0)
        if node == end:
            paths.append({'tables':visited,'joins':edges})
            continue
        if len(edges)>=max_hops: continue
        for nxt, edge in adjacency.get(node,[]):
            if nxt not in visited:
                queue.append((nxt,visited+[nxt],edges+[edge]))
    return paths

def get_table_metadata(datasource, owner, table):
    with connect() as db:
        row = db.execute('SELECT * FROM table_metadata WHERE datasource=? AND owner=? AND table_name=?', (datasource,owner.upper(),table.upper())).fetchone()
    return {'table':table_key(datasource,owner,table), 'description':row['description'], 'columns':json.loads(row['columns_json'])} if row else None

def save_table_metadata(datasource, owner, table, description, columns):
    with connect() as db:
        db.execute('REPLACE INTO table_metadata VALUES (?,?,?,?,?)',(datasource,owner.upper(),table.upper(),description,json.dumps(columns)))
