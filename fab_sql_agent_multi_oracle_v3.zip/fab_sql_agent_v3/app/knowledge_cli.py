import argparse
import json
from pathlib import Path
from . import datasources, graph_store
from .oracle_tools import sync_schema

def main():
    p=argparse.ArgumentParser(description='SQL Template -> incremental graph knowledge')
    sub=p.add_subparsers(dest='command',required=True)
    imp=sub.add_parser('import-sql'); imp.add_argument('path'); imp.add_argument('--datasource',required=True); imp.add_argument('--id'); imp.add_argument('--title'); imp.add_argument('--description',default='')
    sync=sub.add_parser('sync-schema'); sync.add_argument('--datasource',required=True)
    search=sub.add_parser('search'); search.add_argument('query'); search.add_argument('--datasource')
    path=sub.add_parser('paths'); path.add_argument('--datasource',required=True); path.add_argument('--from-table',required=True); path.add_argument('--to-table',required=True)
    sub.add_parser('datasources')
    a=p.parse_args()
    if a.command=='datasources': result=datasources.directory()
    elif a.command=='sync-schema': result=sync_schema(a.datasource)
    elif a.command=='import-sql':
        ds=datasources.get(a.datasource)
        sql=Path(a.path).read_text(encoding='utf8')
        tables, _ = graph_store.extract(sql,a.datasource,ds['schema'])
        forbidden=[t for t in tables if t.split('.')[-1] not in ds['allowed_tables'] or t.split('.')[-2]!=ds['schema']]
        if forbidden:
            raise ValueError('Template contains unauthorized tables: '+str(forbidden))
        result=graph_store.ingest(a.id or Path(a.path).stem,a.datasource,a.title or Path(a.path).stem,a.description,sql,ds['schema'])
    elif a.command=='search': result={'tables':graph_store.search_tables(a.query,a.datasource),'examples':graph_store.search_examples(a.query,a.datasource)}
    else:
        ds=datasources.get(a.datasource)
        result=graph_store.find_paths(graph_store.table_key(a.datasource,ds['schema'],a.from_table),graph_store.table_key(a.datasource,ds['schema'],a.to_table),a.datasource)
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__': main()
