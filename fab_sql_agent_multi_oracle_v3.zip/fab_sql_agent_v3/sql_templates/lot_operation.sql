-- Illustrative example only: replace table and join definitions with validated Oracle SQL.
SELECT l.LOT_ID, o.OPERATION_ID
FROM MES.WIP_LOT l
JOIN MES.LOT_OPERATION o ON l.LOT_ID = o.LOT_ID
WHERE l.LOT_ID = :lot_id
