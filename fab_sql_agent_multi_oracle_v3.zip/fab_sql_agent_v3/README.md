# Fab SQL Agent V3: multi-Oracle routing + incremental SQL graph

## Design

- **One Oracle service per SQL call**. LLM chooses `datasource` from the server-side registry; the backend selects credentials. No cross-DB JOIN in V3.
- **No manual field/mapping YAML**. Oracle dictionary sync populates table/column metadata, including existing Oracle comments. Human only configures datasource/allowlist and imports already-validated SQL templates.
- **SQL template graph**: SQLGlot parses SQL; physical table references and explicit JOIN ON expressions are stored in SQLite, with template provenance. Importing the same template ID replaces its previous graph contribution.
- **Retrieval before SQL**: datasource directory (small) -> table search -> schema -> join path or example -> SQL execution -> iterative model decision.
- **Temporal** orchestrates steps and retries. SQLite is the knowledge store, not the Temporal persistence database.

## Installation

```bash
pip install -r requirements.txt
cp .env.example .env
# Edit .env and config/datasources.yaml
```

`cx_Oracle` requires compatible Oracle Client libraries. If the environment already has cx_Oracle configured, retain that setup. The code falls back to python-oracledb if cx_Oracle is unavailable (install it separately).

## Prepare knowledge

```bash
python -m app.knowledge_cli datasources
python -m app.knowledge_cli sync-schema --datasource mes
python -m app.knowledge_cli sync-schema --datasource equipment
python -m app.knowledge_cli import-sql sql_templates/lot_operation.sql --datasource mes --id lot_operation --description 'Look up lot operation'
python -m app.knowledge_cli search 'lot operation' --datasource mes
python -m app.knowledge_cli paths --datasource mes --from-table WIP_LOT --to-table LOT_OPERATION
```

## Run

```bash
python -m app.worker
# In another shell:
python -m app.cli ask 'Which operation is lot A123 currently at?'
```

## Compatibility

- If `config/datasources.yaml` does not exist, a legacy `default` source is built from `ORACLE_CONN`, `ORACLE_SCHEMA`, `ORACLE_USER`, `ORACLE_PASSWORD`, and `ALLOWED_TABLES`.
- The Temporal Workflow name and task queue stay the same as V2. **Stop old workers before starting V3 workers** on the same task queue, because activity contracts changed.
- SQL templates are stored as text and are **not executed on import**.
- Table names, DSNs and SQL samples are illustrative; replace with actual permitted Oracle objects.

## Security/limitations

- Read-only Oracle users and DB-side least privilege are mandatory. SQLGlot validation is defense-in-depth, not a complete SQL sandbox. `SELECT` can invoke functions or consume expensive resources; production needs DB-side resource limits, sensitive column controls and function policy.
- This version supports tables in each datasource's configured **single default schema**. Multi-schema access within one DB can be added later.
- No cross-database join, DB links, distributed merge, or graph edges across different datasource IDs. A question requiring cross-DB aggregation should receive a limitation response.
- Automatic graph extraction handles **unambiguous explicit JOIN ON expressions**. It intentionally skips joins with more than two distinct physical table references, ambiguous alias lineage, and implicit WHERE joins. CTE/subquery lineage, complex Oracle syntax and composite conditions need further AST refinement. A graph path is a reference, not a guarantee of executable SQL: the original SQL example remains available.
- Template ingestion assumes administrator-provided, validated SQL; it does not prove business correctness.
- Workflow History contains model/tool payloads; avoid sensitive rows and apply Temporal authorization/encryption/retention policies.
- Before production, add tests against actual Oracle SQL examples, data masking, bounded payloads and operational monitoring.
