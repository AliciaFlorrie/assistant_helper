from app.knowledge import extract_candidates, search_tables, get_relationships, search_examples

def test_join_extraction():
    sql='SELECT a.LOT_ID FROM WIP_LOT a JOIN LOT_LOCATION b ON a.LOT_ID=b.LOT_ID'
    result=extract_candidates(sql)
    assert len(result)==1
    assert result[0]['verification_status']=='candidate'

def test_directory_search():
    assert any(x['table']=='ENTITY_STATUS' for x in search_tables('equipment down'))

def test_unverified_not_retrieved():
    assert get_relationships(['WIP_LOT'])==[]
    assert search_examples('lot entity')==[]
