import pytest
from app import datasources
from app.oracle_tools import validate_sql

@pytest.fixture(autouse=True)
def fake_sources(monkeypatch):
    monkeypatch.setattr(datasources,'registry',lambda: {'mes':{'schema':'MES','allowed_tables':['WIP_LOT','LOT_OPERATION']},'equipment':{'schema':'EAP','allowed_tables':['ENTITY_STATUS']}})

def test_good():
    assert validate_sql('mes','SELECT LOT_ID FROM MES.WIP_LOT WHERE LOT_ID=:lot_id',{'lot_id':'A123'})

def test_other_datasource_rejected():
    with pytest.raises(ValueError):
        validate_sql('mes','SELECT STATUS FROM EAP.ENTITY_STATUS',{})

def test_mutation_rejected():
    with pytest.raises(ValueError):
        validate_sql('mes','DELETE FROM MES.WIP_LOT',{})

def test_dblink_rejected():
    with pytest.raises(ValueError):
        validate_sql('mes','SELECT * FROM MES.WIP_LOT@remote',{})
