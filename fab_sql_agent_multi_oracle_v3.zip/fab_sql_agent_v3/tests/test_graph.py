from app import graph_store

def test_incremental_graph(tmp_path,monkeypatch):
    monkeypatch.setattr(graph_store,'DB',tmp_path/'graph.sqlite3')
    sql='SELECT l.LOT_ID FROM MES.WIP_LOT l JOIN MES.LOT_OPERATION o ON l.LOT_ID=o.LOT_ID WHERE l.LOT_ID=:lot_id'
    result=graph_store.ingest('one','mes','Lot Operation','Find operation',sql,'MES')
    assert len(result['edges'])==1
    paths=graph_store.find_paths('mes.MES.WIP_LOT','mes.MES.LOT_OPERATION','mes')
    assert len(paths)==1
    graph_store.ingest('one','mes','Lot Operation','Updated','SELECT LOT_ID FROM MES.WIP_LOT','MES')
    assert graph_store.find_paths('mes.MES.WIP_LOT','mes.MES.LOT_OPERATION','mes')==[]
